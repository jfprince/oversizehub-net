import { openDB } from 'idb';

const DB_NAME = 'oversizeHub';
const MAPS_STORE = 'offlineMaps';
const ROUTES_STORE = 'savedRoutes';

export const initDB = async () => {
  const db = await openDB(DB_NAME, 1, {
    upgrade(db) {
      db.createObjectStore(MAPS_STORE);
      db.createObjectStore(ROUTES_STORE);
    },
  });
  return db;
};

export const saveOfflineMap = async (area: string, data: any) => {
  const db = await initDB();
  await db.put(MAPS_STORE, data, area);
};

export const getOfflineMap = async (area: string) => {
  const db = await initDB();
  return db.get(MAPS_STORE, area);
};

export const saveRoute = async (routeId: string, routeData: any) => {
  const db = await initDB();
  await db.put(ROUTES_STORE, routeData, routeId);
};

export const getRoute = async (routeId: string) => {
  const db = await initDB();
  return db.get(ROUTES_STORE, routeId);
};