export class DatabaseError extends Error {
  constructor(message: string, public code?: string) {
    super(message);
    this.name = 'DatabaseError';
  }
}

export class CollectionError extends DatabaseError {
  constructor(collectionName: string, operation: string, originalError?: Error) {
    super(
      `Failed to ${operation} collection ${collectionName}: ${originalError?.message || 'Unknown error'}`,
      'COLLECTION_ERROR'
    );
    this.name = 'CollectionError';
  }
}

export class DocumentError extends DatabaseError {
  constructor(collectionName: string, documentId: string, operation: string, originalError?: Error) {
    super(
      `Failed to ${operation} document ${documentId} in collection ${collectionName}: ${originalError?.message || 'Unknown error'}`,
      'DOCUMENT_ERROR'
    );
    this.name = 'DocumentError';
  }
}