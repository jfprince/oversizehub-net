import { COLLECTIONS } from './constants';
import { DatabaseError } from './errors';
import type { DatabaseSchema } from './types';
import { verifyCollection, verifyDocument, getDocumentData, batchWrite } from './utils';

export {
  COLLECTIONS,
  DatabaseError,
  verifyCollection,
  verifyDocument,
  getDocumentData,
  batchWrite
};

export type { DatabaseSchema };