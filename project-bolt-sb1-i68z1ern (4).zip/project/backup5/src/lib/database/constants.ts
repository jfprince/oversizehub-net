export const COLLECTIONS = {
  USERS: 'users',
  ROUTES: 'routes',
  SETTINGS: 'settings'
} as const;

export const ADMIN_EMAIL = 'jfprince@soltec.ca';

export type CollectionName = typeof COLLECTIONS[keyof typeof COLLECTIONS];

export const VEHICLE_TYPES = [
  'flatbed',
  'step-deck',
  'rgn',
  'double-drop',
  'lowboy',
  'specialized'
] as const;

export type VehicleType = typeof VEHICLE_TYPES[number];