import { Timestamp } from 'firebase/firestore';

export interface BaseDocument {
  id: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface UserDocument extends BaseDocument {
  email: string;
  displayName?: string;
  accountType: 'personal' | 'business' | 'admin';
  role?: 'user' | 'admin' | 'owner';
  businessId?: string;
  lastLoginAt?: Timestamp;
}

export interface BusinessDocument extends BaseDocument {
  name: string;
  address?: string;
  phone?: string;
  email: string;
  ownerId: string;
  maxUsers: number;
}

export interface RouteDocument extends BaseDocument {
  userId: string;
  name: string;
  description?: string;
  origin: {
    address: string;
    coordinates: [number, number];
  };
  destination: {
    address: string;
    coordinates: [number, number];
  };
  waypoints: Array<{
    address: string;
    coordinates: [number, number];
  }>;
  routeData: any;
  vehicleType: string;
  routeType: string;
}

export interface SystemSettingsDocument extends BaseDocument {
  maxDemoLength: number;
  maxUsersPerBusiness: number;
  maxRoutesPerUser: number;
  requireEmailVerification: boolean;
  allowBusinessRegistration: boolean;
}

export interface DatabaseSchema {
  users: UserDocument;
  businesses: BusinessDocument;
  routes: RouteDocument;
  settings: SystemSettingsDocument;
}