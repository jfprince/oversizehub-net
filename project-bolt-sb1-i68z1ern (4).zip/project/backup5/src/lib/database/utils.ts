import { collection, getDocs, doc, getDoc, writeBatch, DocumentData } from 'firebase/firestore';
import { db } from '../firebase';
import { CollectionError, DocumentError } from './errors';
import type { CollectionName } from './constants';

export const verifyCollection = async (collectionName: CollectionName): Promise<boolean> => {
  try {
    const collectionRef = collection(db, collectionName);
    const snapshot = await getDocs(collectionRef);
    return !snapshot.empty;
  } catch (error) {
    throw new CollectionError(collectionName, 'verify', error as Error);
  }
};

export const verifyDocument = async (
  collectionName: CollectionName,
  documentId: string
): Promise<boolean> => {
  try {
    const docRef = doc(db, collectionName, documentId);
    const snapshot = await getDoc(docRef);
    return snapshot.exists();
  } catch (error) {
    throw new DocumentError(collectionName, documentId, 'verify', error as Error);
  }
};

export const getDocumentData = async <T extends DocumentData>(
  collectionName: CollectionName,
  documentId: string
): Promise<T | null> => {
  try {
    const docRef = doc(db, collectionName, documentId);
    const snapshot = await getDoc(docRef);
    return snapshot.exists() ? snapshot.data() as T : null;
  } catch (error) {
    throw new DocumentError(collectionName, documentId, 'get', error as Error);
  }
};

export const batchWrite = async (
  operations: Array<{
    type: 'set' | 'update' | 'delete';
    collection: CollectionName;
    document: string;
    data?: DocumentData;
  }>
): Promise<void> => {
  const batch = writeBatch(db);

  try {
    operations.forEach(({ type, collection: collectionName, document: documentId, data }) => {
      const docRef = doc(db, collectionName, documentId);
      
      switch (type) {
        case 'set':
          batch.set(docRef, data!);
          break;
        case 'update':
          batch.update(docRef, data!);
          break;
        case 'delete':
          batch.delete(docRef);
          break;
      }
    });

    await batch.commit();
  } catch (error) {
    throw new DatabaseError('Failed to execute batch operation', (error as Error).message);
  }
};