import { doc, updateDoc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { COLLECTIONS } from './constants';

export interface MaintenanceConfig {
  isEnabled: boolean;
  message: string;
  endTime: string;
  bypassCode: string;
}

export const getMaintenanceStatus = async (): Promise<MaintenanceConfig | null> => {
  try {
    const docRef = doc(db, COLLECTIONS.SETTINGS, 'maintenance');
    const docSnap = await getDoc(docRef);
    
    if (!docSnap.exists()) {
      // Initialize with default values if document doesn't exist
      const defaultConfig: MaintenanceConfig = {
        isEnabled: false,
        message: 'System is under maintenance. Please try again later.',
        endTime: new Date(Date.now() + 3600000).toISOString(),
        bypassCode: ''
      };
      
      await setDoc(docRef, defaultConfig);
      return defaultConfig;
    }
    
    return docSnap.data() as MaintenanceConfig;
  } catch (error) {
    console.error('Error getting maintenance status:', error);
    return null;
  }
};

export const updateMaintenanceStatus = async (config: Partial<MaintenanceConfig>): Promise<void> => {
  try {
    const docRef = doc(db, COLLECTIONS.SETTINGS, 'maintenance');
    await updateDoc(docRef, {
      ...config,
      updatedAt: new Date()
    });
  } catch (error) {
    console.error('Error updating maintenance status:', error);
    throw new Error('Failed to update maintenance settings');
  }
};

export const validateBypassCode = async (code: string): Promise<boolean> => {
  try {
    const status = await getMaintenanceStatus();
    return status?.bypassCode === code;
  } catch (error) {
    console.error('Error validating bypass code:', error);
    return false;
  }
};