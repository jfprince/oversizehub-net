import { auth, db } from './firebase';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  sendEmailVerification,
  applyActionCode,
  checkActionCode,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  RecaptchaVerifier,
  PhoneAuthProvider,
  signInWithPhoneNumber
} from 'firebase/auth';
import { 
  doc, 
  setDoc,
  getDoc,
  updateDoc,
  serverTimestamp 
} from 'firebase/firestore';
import { ADMIN_EMAIL } from './database/constants';
import { UserProfile } from '../types/user';

// Initialize reCAPTCHA verifier
let recaptchaVerifier: RecaptchaVerifier | null = null;

const initRecaptcha = () => {
  if (!recaptchaVerifier) {
    recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
      size: 'invisible',
      callback: () => {},
      'expired-callback': () => {}
    });
  }
  return recaptchaVerifier;
};

export const createUser = async (
  email: string,
  password: string,
  recaptchaToken: string,
  additionalData: Record<string, any> = {}
): Promise<UserProfile> => {
  try {
    // Create user
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const { user } = userCredential;

    // Send verification email
    const actionCodeSettings = {
      url: `${window.location.origin}/verify-email`,
      handleCodeInApp: true
    };
    await sendEmailVerification(user, actionCodeSettings);

    // Create user profile
    const userProfile: UserProfile = {
      uid: user.uid,
      email: user.email!,
      displayName: `${additionalData.firstName} ${additionalData.lastName}`,
      accountType: email === ADMIN_EMAIL ? 'admin' : 'personal',
      role: email === ADMIN_EMAIL ? 'admin' : 'user',
      emailVerified: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      ...additionalData
    };

    // Save to Firestore
    await setDoc(doc(db, 'users', user.uid), {
      ...userProfile,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    return userProfile;
  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }
};

export const signIn = async (
  email: string, 
  password: string, 
  rememberMe: boolean = false
): Promise<void> => {
  try {
    // Set persistence based on rememberMe
    await setPersistence(auth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
    
    // Sign in
    await signInWithEmailAndPassword(auth, email, password);

    // If admin user, ensure admin role
    if (email === ADMIN_EMAIL) {
      const userRef = doc(db, 'users', auth.currentUser!.uid);
      await setDoc(userRef, {
        email: ADMIN_EMAIL,
        role: 'admin',
        accountType: 'admin',
        updatedAt: serverTimestamp()
      }, { merge: true });
    }
  } catch (error) {
    console.error('Error signing in:', error);
    throw error;
  }
};

export const signOutUser = async (): Promise<void> => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Error signing out:', error);
    throw error;
  }
};

export const resendVerificationEmail = async (): Promise<void> => {
  const user = auth.currentUser;
  if (!user) throw new Error('No user signed in');

  const actionCodeSettings = {
    url: `${window.location.origin}/verify-email`,
    handleCodeInApp: true
  };

  await sendEmailVerification(user, actionCodeSettings);
};

export const verifyEmail = async (code: string): Promise<void> => {
  try {
    await applyActionCode(auth, code);
    
    // Update user profile
    if (auth.currentUser) {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, {
        emailVerified: true,
        updatedAt: serverTimestamp()
      });
    }
  } catch (error) {
    console.error('Error verifying email:', error);
    throw error;
  }
};

export const sendPhoneVerification = async (phoneNumber: string): Promise<string> => {
  try {
    const verifier = initRecaptcha();
    const provider = new PhoneAuthProvider(auth);
    return await provider.verifyPhoneNumber(phoneNumber, verifier);
  } catch (error) {
    console.error('Error sending phone verification:', error);
    throw error;
  }
};

export const verifyPhoneCode = async (verificationId: string, code: string): Promise<void> => {
  try {
    const credential = PhoneAuthProvider.credential(verificationId, code);
    const user = auth.currentUser;
    if (!user) throw new Error('No user signed in');

    await user.linkWithCredential(credential);
    
    // Update user profile
    const userRef = doc(db, 'users', user.uid);
    await updateDoc(userRef, {
      phoneVerified: true,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error verifying phone code:', error);
    throw error;
  }
};