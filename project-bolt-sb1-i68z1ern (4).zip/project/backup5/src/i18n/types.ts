export interface Translations {
  [key: string]: {
    navigation: {
      home: string;
      features: string;
      pricing: string;
      contact: string;
      map: string;
      profile: string;
      backend: string;
    };
    auth: {
      login: string;
      logout: string;
      signUp: string;
      email: string;
      password: string;
      confirmPassword: string;
    };
    footer: {
      company: string;
      about: string;
      contact: string;
      legal: string;
      privacy: string;
      terms: string;
      support: string;
      help: string;
      documentation: string;
      status: string;
      account: string;
      admin: string;
    };
  };
}