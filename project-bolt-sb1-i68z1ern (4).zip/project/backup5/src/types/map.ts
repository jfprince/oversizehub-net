export interface MapFeature {
  id: string;
  type: 'point' | 'line' | 'polygon';
  coordinates: number[][];
  properties: {
    label?: string;
    media?: {
      type: 'image' | 'video' | 'document';
      url: string;
    }[];
  };
}

export interface MapLayer {
  id: string;
  name: string;
  visible: boolean;
  features: MapFeature[];
}

export interface MapViewport {
  longitude: number;
  latitude: number;
  zoom: number;
  bearing?: number;
  pitch?: number;
}

export interface MapStyle {
  id: string;
  name: string;
  url: string;
}