export type AccountType = 'personal' | 'business' | 'admin';
export type UserRole = 'owner' | 'admin' | 'user';

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  accountType: AccountType;
  businessId?: string;
  role?: UserRole;
  suspended?: boolean;
  professional?: {
    companyName: string;
    jobTitle: string;
    companyType: string;
    yearsExperience: number;
    certifications: string[];
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface BusinessProfile {
  id: string;
  name: string;
  address?: string;
  phone?: string;
  email: string;
  ownerId: string;
  maxUsers?: number;
  createdAt: Date;
  updatedAt: Date;
}