export type MapProvider = 'google' | 'mapbox' | 'igo2';
export type RouteType = 'fastest' | 'shortest' | 'custom';
export type VehicleType = 'car' | 'truck' | 'oversized';

export interface VehicleDimensions {
  length: number;
  width: number;
  height: number;
  weight: number;
}

export interface RouteOptions {
  provider: MapProvider;
  routeType: RouteType;
  waypoints?: [number, number][];
  vehicleType: VehicleType;
  dimensions?: VehicleDimensions;
}

export interface Waypoint {
  id: string;
  address: string;
  coords?: [number, number];
}

export interface RouteResult {
  distance: number;
  duration: number;
  coordinates: [number, number][];
  restrictions?: {
    height?: number;
    width?: number;
    weight?: number;
  };
}