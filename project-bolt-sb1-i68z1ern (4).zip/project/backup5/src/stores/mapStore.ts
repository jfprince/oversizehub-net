import { create } from 'zustand';
import { MAPBOX_STYLES, DEFAULT_CENTER, DEFAULT_ZOOM } from '../config/mapbox';
import { MapViewport, MapFeature, MapLayer } from '../types/map';

interface MapState {
  viewport: MapViewport;
  mapStyle: string;
  layers: MapLayer[];
  activeLayer: string | null;
  drawingMode: 'point' | 'line' | 'polygon' | null;
  selectedFeature: MapFeature | null;
  setViewport: (viewport: Partial<MapViewport>) => void;
  setMapStyle: (style: string) => void;
  addLayer: (layer: MapLayer) => void;
  removeLayer: (layerId: string) => void;
  setActiveLayer: (layerId: string | null) => void;
  setDrawingMode: (mode: 'point' | 'line' | 'polygon' | null) => void;
  addFeature: (layerId: string, feature: MapFeature) => void;
  removeFeature: (layerId: string, featureId: string) => void;
  setSelectedFeature: (feature: MapFeature | null) => void;
}

export const useMapStore = create<MapState>((set) => ({
  viewport: {
    longitude: DEFAULT_CENTER[0],
    latitude: DEFAULT_CENTER[1],
    zoom: DEFAULT_ZOOM,
  },
  mapStyle: MAPBOX_STYLES.STREETS,
  layers: [],
  activeLayer: null,
  drawingMode: null,
  selectedFeature: null,
  setViewport: (newViewport) =>
    set((state) => ({
      viewport: { ...state.viewport, ...newViewport },
    })),
  setMapStyle: (style) => set({ mapStyle: style }),
  addLayer: (layer) =>
    set((state) => ({
      layers: [...state.layers, layer],
    })),
  removeLayer: (layerId) =>
    set((state) => ({
      layers: state.layers.filter((layer) => layer.id !== layerId),
    })),
  setActiveLayer: (layerId) => set({ activeLayer: layerId }),
  setDrawingMode: (mode) => set({ drawingMode: mode }),
  addFeature: (layerId, feature) =>
    set((state) => ({
      layers: state.layers.map((layer) =>
        layer.id === layerId
          ? { ...layer, features: [...layer.features, feature] }
          : layer
      ),
    })),
  removeFeature: (layerId, featureId) =>
    set((state) => ({
      layers: state.layers.map((layer) =>
        layer.id === layerId
          ? {
              ...layer,
              features: layer.features.filter((f) => f.id !== featureId),
            }
          : layer
      ),
    })),
  setSelectedFeature: (feature) => set({ selectedFeature: feature }),
}));