import { create } from 'zustand';
import { RouteType, VehicleType, VehicleDimensions } from '../types/route';

interface RouteState {
  route: [number, number][] | null;
  waypoints: [number, number][];
  routeType: RouteType;
  vehicleType: VehicleType;
  dimensions: VehicleDimensions;
  setRoute: (route: [number, number][] | null) => void;
  addWaypoint: (waypoint: [number, number]) => void;
  removeWaypoint: (index: number) => void;
  clearRoute: () => void;
  setRouteType: (type: RouteType) => void;
  setVehicleType: (type: VehicleType) => void;
  setDimensions: (dimensions: VehicleDimensions) => void;
}

export const useRouteStore = create<RouteState>((set) => ({
  route: null,
  waypoints: [],
  routeType: 'fastest',
  vehicleType: 'truck',
  dimensions: {
    length: 0,
    width: 0,
    height: 0,
    weight: 0
  },
  setRoute: (route) => set({ route }),
  addWaypoint: (waypoint) => 
    set((state) => ({ waypoints: [...state.waypoints, waypoint] })),
  removeWaypoint: (index) =>
    set((state) => ({
      waypoints: state.waypoints.filter((_, i) => i !== index),
    })),
  clearRoute: () => set({ route: null, waypoints: [] }),
  setRouteType: (routeType) => set({ routeType }),
  setVehicleType: (vehicleType) => set({ vehicleType }),
  setDimensions: (dimensions) => set({ dimensions })
}));