import React, { useState, useEffect } from 'react';
import { AlertTriangle, Clock, Lock, MessageSquare } from 'lucide-react';
import { getMaintenanceStatus, updateMaintenanceStatus } from '../../../lib/database/maintenance';
import type { MaintenanceConfig } from '../../../lib/database/maintenance';

export const MaintenanceMode: React.FC = () => {
  const [config, setConfig] = useState<MaintenanceConfig>({
    isEnabled: false,
    message: '',
    endTime: new Date(Date.now() + 3600000).toISOString().slice(0, 16),
    bypassCode: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadMaintenanceStatus();
  }, []);

  const loadMaintenanceStatus = async () => {
    try {
      const status = await getMaintenanceStatus();
      if (status) {
        setConfig(status);
      }
    } catch (err) {
      setError('Failed to load maintenance status');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      await updateMaintenanceStatus(config);
      setSuccess('Maintenance settings updated successfully');
      await loadMaintenanceStatus(); // Reload the latest status
    } catch (err) {
      setError('Failed to update maintenance settings');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900">Maintenance Mode</h2>
        <div className="flex items-center space-x-2">
          <span className={`w-2 h-2 rounded-full ${config.isEnabled ? 'bg-red-500' : 'bg-green-500'}`} />
          <span className="text-sm text-gray-600">
            {config.isEnabled ? 'Maintenance Active' : 'System Online'}
          </span>
        </div>
      </div>

      {config.isEnabled && (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-yellow-400" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-yellow-800">Maintenance Mode Active</h3>
              <p className="mt-1 text-sm text-yellow-700">
                The system is currently in maintenance mode. Only users with the bypass code can access the system.
              </p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={config.isEnabled}
              onChange={(e) => setConfig({ ...config, isEnabled: e.target.checked })}
              className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
            />
            <span className="text-sm font-medium text-gray-700">Enable Maintenance Mode</span>
          </label>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            <div className="flex items-center space-x-2 mb-1">
              <MessageSquare className="h-4 w-4" />
              <span>Maintenance Message</span>
            </div>
          </label>
          <textarea
            value={config.message}
            onChange={(e) => setConfig({ ...config, message: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            rows={3}
            placeholder="Enter the message to display during maintenance..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            <div className="flex items-center space-x-2 mb-1">
              <Clock className="h-4 w-4" />
              <span>Expected End Time</span>
            </div>
          </label>
          <input
            type="datetime-local"
            value={config.endTime}
            onChange={(e) => setConfig({ ...config, endTime: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            <div className="flex items-center space-x-2 mb-1">
              <Lock className="h-4 w-4" />
              <span>Bypass Code</span>
            </div>
          </label>
          <input
            type="text"
            value={config.bypassCode}
            onChange={(e) => setConfig({ ...config, bypassCode: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            placeholder="Enter a code to bypass maintenance mode..."
          />
          <p className="mt-1 text-sm text-gray-500">
            Users with this code can access the system during maintenance.
          </p>
        </div>

        {error && (
          <div className="text-red-600 text-sm">{error}</div>
        )}

        {success && (
          <div className="text-green-600 text-sm">{success}</div>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  );
};