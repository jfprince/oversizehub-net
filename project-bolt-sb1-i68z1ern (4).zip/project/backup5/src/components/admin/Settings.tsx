import React, { useState } from 'react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { COLLECTIONS } from '../../lib/database/constants';

export const Settings: React.FC = () => {
  const [settings, setSettings] = useState({
    maxRoutesPerUser: 1000,
    requireEmailVerification: true,
    security: {
      passwordMinLength: 8,
      requireSpecialChars: true,
      sessionTimeout: 3600
    },
    maps: {
      defaultCenter: [-73.5673, 45.5017],
      defaultZoom: 12,
      maxOfflineArea: 100
    }
  });
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await updateDoc(doc(db, COLLECTIONS.SETTINGS, 'system'), settings);
    } catch (error) {
      console.error('Error saving settings:', error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-900">System Settings</h2>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Maximum Routes per User
          </label>
          <input
            type="number"
            value={settings.maxRoutesPerUser}
            onChange={(e) => setSettings({ ...settings, maxRoutesPerUser: parseInt(e.target.value) })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>

        <div className="flex items-center">
          <input
            type="checkbox"
            id="emailVerification"
            checked={settings.requireEmailVerification}
            onChange={(e) => setSettings({ ...settings, requireEmailVerification: e.target.checked })}
            className="h-4 w-4 text-[#ED4235] focus:ring-[#ED4235] border-gray-300 rounded"
          />
          <label htmlFor="emailVerification" className="ml-2 block text-sm text-gray-900">
            Require Email Verification
          </label>
        </div>

        <div className="pt-4">
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
          >
            {isSaving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
};