import React from 'react';
import { NavItem } from './NavItem';
import { NavItemType } from './types';
import { 
  Database, 
  Settings, 
  Activity,
  Wrench,
  Users,
  Shield,
  FileText,
  Mail,
  HelpCircle
} from 'lucide-react';
import { DatabaseManagement } from '../DatabaseManagement';
import { SystemStatus } from '../SystemStatus';
import { Settings as SettingsComponent } from '../Settings';
import { UserManagement } from '../UserManagement';
import { MaintenanceMode } from '../maintenance/MaintenanceMode';

export const menuItems: NavItemType[] = [
  {
    id: 'users',
    label: 'User Management',
    icon: Users,
    component: UserManagement,
    subItems: [
      { id: 'all-users', label: 'All Users', icon: Users, component: UserManagement },
      { id: 'roles', label: 'Roles & Permissions', icon: Shield },
      { id: 'verification', label: 'Verification Requests', icon: FileText }
    ]
  },
  {
    id: 'maintenance',
    label: 'Maintenance',
    icon: Wrench,
    component: MaintenanceMode
  },
  {
    id: 'system',
    label: 'System',
    icon: Activity,
    subItems: [
      { id: 'database', label: 'Database', icon: Database, component: DatabaseManagement },
      { id: 'status', label: 'System Status', icon: Activity, component: SystemStatus },
      { id: 'settings', label: 'Settings', icon: Settings, component: SettingsComponent }
    ]
  },
  {
    id: 'support',
    label: 'Support',
    icon: HelpCircle,
    subItems: [
      { id: 'documentation', label: 'Documentation', icon: FileText },
      { id: 'contact', label: 'Contact Support', icon: Mail }
    ]
  }
];

export const AdminMenu: React.FC<{
  activeTab: string;
  onTabChange: (tabId: string) => void;
}> = ({ activeTab, onTabChange }) => {
  return (
    <div className="border-b border-gray-200">
      <nav className="flex">
        {menuItems.map((item) => (
          <NavItem
            key={item.id}
            item={item}
            activeTab={activeTab}
            onTabChange={onTabChange}
          />
        ))}
      </nav>
    </div>
  );
};