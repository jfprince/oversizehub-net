import React from 'react';
import { NavSubItemType } from './types';

interface NavDropdownProps {
  items: NavSubItemType[];
  activeTab: string;
  onSelect: (id: string) => void;
}

export const NavDropdown: React.FC<NavDropdownProps> = ({ items, activeTab, onSelect }) => {
  return (
    <div className="absolute left-0 mt-1 w-56 bg-white rounded-lg shadow-lg border border-gray-100 py-1 z-50">
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => onSelect(item.id)}
          className={`flex items-center w-full px-4 py-2 text-sm ${
            activeTab === item.id
              ? 'text-[#ED4235] bg-red-50'
              : 'text-gray-700 hover:bg-gray-50'
          }`}
        >
          {item.icon && <item.icon className="h-4 w-4 mr-2" />}
          <span>{item.label}</span>
        </button>
      ))}
    </div>
  );
};