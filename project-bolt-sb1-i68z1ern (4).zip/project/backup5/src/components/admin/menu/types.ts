import { LucideIcon } from 'lucide-react';

export interface NavSubItemType {
  id: string;
  label: string;
  icon?: LucideIcon;
  component?: React.ComponentType;
}

export interface NavItemType {
  id: string;
  label: string;
  icon: LucideIcon;
  link?: string;
  isExternal?: boolean;
  component?: React.ComponentType;
  subItems?: NavSubItemType[];
}