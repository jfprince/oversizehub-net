import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  MapPin, 
  Truck, 
  Shield, 
  Globe, 
  Lock, 
  Ban, 
  Database, 
  Eye,
  Map,
  Users
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const Hero: React.FC = () => {
  const { t } = useTranslation();

  return (
    <div className="relative">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://soltec.ca/DJI_0260.JPG)',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/75 to-black/90"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-24 md:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-8 leading-tight">
              <span className="block">Professional Solutions for</span>
              <span className="block text-[#ED4235] mt-2">Heavy Transport</span>
              <span className="block text-white mt-2">Industry</span>
            </h1>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-8">
              <div className="space-y-4 text-white">
                <p className="text-xl font-medium leading-relaxed">
                  Transform your heavy transport operations with OversizeHub.net's comprehensive suite of professional tools.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Map className="h-5 w-5 text-[#ED4235] mr-2" />
                      Advanced Route Planning
                    </h3>
                    <p className="text-gray-300">
                      Intelligent mapping and optimization specifically designed for oversized loads and heavy transport vehicles.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Shield className="h-5 w-5 text-[#ED4235] mr-2" />
                      Compliance & Safety
                    </h3>
                    <p className="text-gray-300">
                      Built-in regulation compliance tools and real-time safety alerts for your transport operations.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Database className="h-5 w-5 text-[#ED4235] mr-2" />
                      Seamless Integration
                    </h3>
                    <p className="text-gray-300">
                      Import and export data in multiple formats, with offline access for uninterrupted operations.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-lg font-semibold flex items-center">
                      <Users className="h-5 w-5 text-[#ED4235] mr-2" />
                      Team Collaboration
                    </h3>
                    <p className="text-gray-300">
                      Real-time collaboration tools for efficient fleet management and route coordination.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Privacy Features */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 flex items-start space-x-3">
                <Ban className="h-5 w-5 text-[#ED4235] flex-shrink-0 mt-1" />
                <div className="text-left">
                  <h4 className="text-white font-semibold">No Advertisements</h4>
                  <p className="text-gray-300 text-sm">Clean, distraction-free experience across all plans</p>
                </div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 flex items-start space-x-3">
                <Database className="h-5 w-5 text-[#ED4235] flex-shrink-0 mt-1" />
                <div className="text-left">
                  <h4 className="text-white font-semibold">Your Data is Yours</h4>
                  <p className="text-gray-300 text-sm">No data sharing with third parties</p>
                </div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 flex items-start space-x-3">
                <Eye className="h-5 w-5 text-[#ED4235] flex-shrink-0 mt-1" />
                <div className="text-left">
                  <h4 className="text-white font-semibold">No Tracking</h4>
                  <p className="text-gray-300 text-sm">No analytics or social media tracking</p>
                </div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 flex items-start space-x-3">
                <Lock className="h-5 w-5 text-[#ED4235] flex-shrink-0 mt-1" />
                <div className="text-left">
                  <h4 className="text-white font-semibold">Subscription Only</h4>
                  <p className="text-gray-300 text-sm">Transparent pricing, no hidden fees</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <Link 
                to="/signup" 
                className="px-8 py-4 bg-[#ED4235] text-white font-semibold rounded-xl hover:bg-opacity-90 transition-all transform hover:-translate-y-1 shadow-lg hover:shadow-xl"
              >
                Start Free Trial
              </Link>
              <a 
                href="#features" 
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-[#ED4235] transition-all transform hover:-translate-y-1 shadow-lg hover:shadow-xl"
              >
                Explore Features
              </a>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 py-12">
          <StatCard
            icon={Globe}
            number="50+"
            label="Coverage"
            description="States & Provinces"
          />
          <StatCard
            icon={Truck}
            number="1000+"
            label="Routes"
            description="Optimized Daily"
          />
          <StatCard
            icon={Shield}
            number="99.9%"
            label="Uptime"
            description="Service Reliability"
          />
          <StatCard
            icon={MapPin}
            number="24/7"
            label="Support"
            description="Expert Assistance"
          />
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{
  icon: React.ElementType;
  number: string;
  label: string;
  description: string;
}> = ({ icon: Icon, number, label, description }) => (
  <div className="group bg-white/5 backdrop-blur-sm rounded-xl p-6 transform hover:scale-[1.02] transition-all duration-300 hover:bg-white/10">
    <div className="flex flex-col items-center text-center space-y-2">
      <Icon className="h-8 w-8 text-[#ED4235] mb-2" />
      <div className="text-3xl font-bold text-white">{number}</div>
      <div className="text-sm uppercase tracking-wider text-[#ED4235] font-semibold">{label}</div>
      <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">
        {description}
      </p>
    </div>
  </div>
);

export default Hero;