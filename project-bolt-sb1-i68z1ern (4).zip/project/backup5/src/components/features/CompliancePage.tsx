import React, { useState } from 'react';
import { Shield, FileCheck, AlertTriangle, Scale, Truck, FileText, ChevronDown, Info, MapPin, Globe } from 'lucide-react';
import { canadianProvinces, usStates } from '../../data/compliance';

export const CompliancePage: React.FC = () => {
  const [expandedJurisdiction, setExpandedJurisdiction] = useState<string | null>("Québec");
  const [expandedSection, setExpandedSection] = useState<string>("general");
  const [region, setRegion] = useState<'canada' | 'usa'>('canada');

  const generalInfo = {
    title: "General Compliance Information",
    sections: [
      {
        title: "Documentation Requirements",
        items: [
          "Valid commercial driver's license with appropriate endorsements",
          "Vehicle registration and insurance documents",
          "Permits specific to oversized/overweight loads",
          "Route survey and engineering assessments when required",
          "Load documentation including dimensions and weight"
        ]
      },
      {
        title: "Safety Requirements",
        items: [
          "Warning flags and signs on oversized loads",
          "Proper lighting and reflective markings",
          "Communication equipment for escort vehicles",
          "Height poles when required",
          "Safety chains and proper load securement"
        ]
      },
      {
        title: "Operating Hours",
        items: [
          "Most jurisdictions restrict movement during peak traffic hours",
          "Night movement may require additional lighting and permits",
          "Weekend and holiday restrictions vary by location",
          "Weather-related restrictions may apply",
          "Urban area specific time restrictions"
        ]
      },
      {
        title: "Route Planning",
        items: [
          "Pre-approved routes for oversized loads",
          "Bridge and tunnel clearance verification",
          "Weight restriction compliance on roads and bridges",
          "Turn radius and swept path analysis",
          "Coordination with utilities for overhead lines"
        ]
      }
    ]
  };

  const renderJurisdictionContent = (jurisdiction: any) => {
    if (jurisdiction.dataStatus === 'pending') {
      return (
        <div className="p-6 text-center text-gray-500">
          <p>Detailed information for {jurisdiction.name} is coming soon.</p>
          <p className="text-sm mt-2">Please check back later or contact local authorities for current requirements.</p>
        </div>
      );
    }

    return (
      <div className="p-6 space-y-6">
        {/* Standard Dimensions */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Truck className="h-5 w-5 text-[#ED4235] mr-2" />
            Standard Dimensions
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Width: {jurisdiction.standardDimensions.width}</p>
              <p className="text-sm text-gray-600">Height: {jurisdiction.standardDimensions.height}</p>
              <p className="text-sm text-gray-600">Single Vehicle: {jurisdiction.standardDimensions.length.single}</p>
              <p className="text-sm text-gray-600">Combined: {jurisdiction.standardDimensions.length.combined}</p>
            </div>
          </div>
        </div>

        {/* Escort Requirements */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Shield className="h-5 w-5 text-[#ED4235] mr-2" />
            Escort Requirements
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Width</h4>
              <p className="text-sm text-gray-600">Civil: {jurisdiction.escortRequirements.width.civil}</p>
              <p className="text-sm text-gray-600">Police: {jurisdiction.escortRequirements.width.police}</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-700 mb-2">Length</h4>
              <p className="text-sm text-gray-600">Civil: {jurisdiction.escortRequirements.length.civil}</p>
              <p className="text-sm text-gray-600">Police: {jurisdiction.escortRequirements.length.police}</p>
            </div>
          </div>
        </div>

        {/* Time Restrictions */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <AlertTriangle className="h-5 w-5 text-[#ED4235] mr-2" />
            Restrictions
          </h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <ul className="list-disc list-inside space-y-2">
              {jurisdiction.restrictions.time.map((restriction: string, index: number) => (
                <li key={index} className="text-sm text-gray-600">{restriction}</li>
              ))}
              <li className="text-sm text-gray-600">{jurisdiction.restrictions.holidays}</li>
            </ul>
          </div>
        </div>

        {/* Permit Information */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <FileCheck className="h-5 w-5 text-[#ED4235] mr-2" />
            Permit Information
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600"><strong>Website:</strong> {jurisdiction.permitInfo.site}</p>
              <p className="text-sm text-gray-600"><strong>Cost:</strong> {jurisdiction.permitInfo.cost}</p>
              <p className="text-sm text-gray-600"><strong>Processing Time:</strong> {jurisdiction.permitInfo.processingTime}</p>
              <p className="text-sm text-gray-600"><strong>Notes:</strong> {jurisdiction.permitInfo.notes}</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Compliance Requirements
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Comprehensive guide to oversized transport regulations
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-4 mb-8">
          <button
            onClick={() => setExpandedSection("general")}
            className={`px-4 py-2 rounded-lg ${
              expandedSection === "general"
                ? "bg-[#ED4235] text-white"
                : "bg-white text-gray-700 hover:bg-gray-50"
            }`}
          >
            <div className="flex items-center">
              <Info className="h-5 w-5 mr-2" />
              General Information
            </div>
          </button>
          <button
            onClick={() => setExpandedSection("jurisdictions")}
            className={`px-4 py-2 rounded-lg ${
              expandedSection === "jurisdictions"
                ? "bg-[#ED4235] text-white"
                : "bg-white text-gray-700 hover:bg-gray-50"
            }`}
          >
            <div className="flex items-center">
              <Globe className="h-5 w-5 mr-2" />
              Jurisdiction Requirements
            </div>
          </button>
        </div>

        {/* General Information Section */}
        {expandedSection === "general" && (
          <div className="space-y-8">
            {generalInfo.sections.map((section, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                  <Shield className="h-6 w-6 text-[#ED4235] mr-3" />
                  {section.title}
                </h2>
                <ul className="space-y-3">
                  {section.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start">
                      <FileCheck className="h-5 w-5 text-[#ED4235] mr-3 mt-0.5" />
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}

        {/* Jurisdictions Section */}
        {expandedSection === "jurisdictions" && (
          <>
            {/* Region Toggle */}
            <div className="flex space-x-4 mb-8">
              <button
                onClick={() => setRegion('canada')}
                className={`px-6 py-3 rounded-lg flex items-center ${
                  region === 'canada'
                    ? 'bg-[#ED4235] text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Canadian Provinces
              </button>
              <button
                onClick={() => setRegion('usa')}
                className={`px-6 py-3 rounded-lg flex items-center ${
                  region === 'usa'
                    ? 'bg-[#ED4235] text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                US States
              </button>
            </div>

            <div className="space-y-6">
              {(region === 'canada' ? canadianProvinces : usStates).map((jurisdiction) => (
                <div key={jurisdiction.name} className="bg-white rounded-lg shadow-lg overflow-hidden">
                  <button
                    onClick={() => setExpandedJurisdiction(
                      expandedJurisdiction === jurisdiction.name ? null : jurisdiction.name
                    )}
                    className="w-full px-6 py-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center">
                      <Shield className="h-6 w-6 text-[#ED4235] mr-3" />
                      <h2 className="text-xl font-semibold text-gray-900">{jurisdiction.name}</h2>
                      {jurisdiction.dataStatus === 'pending' && (
                        <span className="ml-3 px-2 py-1 text-xs font-medium text-gray-500 bg-gray-100 rounded">
                          Coming Soon
                        </span>
                      )}
                    </div>
                    <ChevronDown 
                      className={`h-5 w-5 text-gray-500 transition-transform ${
                        expandedJurisdiction === jurisdiction.name ? 'rotate-180' : ''
                      }`} 
                    />
                  </button>

                  {expandedJurisdiction === jurisdiction.name && renderJurisdictionContent(jurisdiction)}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};