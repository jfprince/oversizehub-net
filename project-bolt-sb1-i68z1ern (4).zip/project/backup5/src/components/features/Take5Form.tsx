import React, { useState } from 'react';
import { 
  Send, 
  AlertTriangle, 
  ShieldCheck, 
  Truck, 
  FileCheck, 
  MapPin, 
  UserCheck,
  CheckCircle2,
  Mail,
  Calendar,
  User,
  Users,
  CloudSun,
  FileText
} from 'lucide-react';

interface FormData {
  // Vehicle Condition Check
  brakes: boolean;
  tires: boolean;
  lights: boolean;
  mirrors: boolean;
  wipers: boolean;
  
  // Cargo Securement
  tieDowns: boolean;
  loadDistribution: boolean;
  cargoShifting: boolean;
  oversizeSigns: boolean;
  
  // Pre-Trip Inspection
  documentation: boolean;
  defects: string;
  requiredEquipment: boolean;
  
  // Route & Weather
  routePlanning: boolean;
  permits: boolean;
  weatherConditions: string;
  
  // Driver Fitness
  rest: boolean;
  distractions: boolean;
  ppe: boolean;
  communication: boolean;
  
  // Final Check
  safetyConfirm: boolean;
  paperwork: boolean;
  escortCoordination: boolean;
  
  // Sign Off
  driverName: string;
  date: string;
  supervisorName: string;
  email: string;
}

export const Take5Form: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    brakes: false,
    tires: false,
    lights: false,
    mirrors: false,
    wipers: false,
    tieDowns: false,
    loadDistribution: false,
    cargoShifting: false,
    oversizeSigns: false,
    documentation: false,
    defects: '',
    requiredEquipment: false,
    routePlanning: false,
    permits: false,
    weatherConditions: '',
    rest: false,
    distractions: false,
    ppe: false,
    communication: false,
    safetyConfirm: false,
    paperwork: false,
    escortCoordination: false,
    driverName: '',
    date: new Date().toISOString().split('T')[0],
    supervisorName: '',
    email: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    try {
      // Here you would typically send the data to your backend
      // For now, we'll simulate an API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Send email
      const emailBody = `
Take 5 Safety Checklist Report

Driver: ${formData.driverName}
Date: ${formData.date}
Supervisor: ${formData.supervisorName}

Vehicle Condition Check:
- Brakes: ${formData.brakes ? '✓' : '✗'}
- Tires: ${formData.tires ? '✓' : '✗'}
- Lights: ${formData.lights ? '✓' : '✗'}
- Mirrors: ${formData.mirrors ? '✓' : '✗'}
- Wipers: ${formData.wipers ? '✓' : '✗'}

Cargo Securement:
- Tie-Downs: ${formData.tieDowns ? '✓' : '✗'}
- Load Distribution: ${formData.loadDistribution ? '✓' : '✗'}
- Cargo Shifting: ${formData.cargoShifting ? '✓' : '✗'}
- Oversize Signs: ${formData.oversizeSigns ? '✓' : '✗'}

Pre-Trip Inspection:
- Documentation: ${formData.documentation ? '✓' : '✗'}
- Defects Found: ${formData.defects || 'None'}
- Required Equipment: ${formData.requiredEquipment ? '✓' : '✗'}

Route & Weather:
- Route Planning: ${formData.routePlanning ? '✓' : '✗'}
- Permits: ${formData.permits ? '✓' : '✗'}
- Weather Conditions: ${formData.weatherConditions}

Driver Fitness:
- Rest: ${formData.rest ? '✓' : '✗'}
- Distractions: ${formData.distractions ? '✓' : '✗'}
- PPE: ${formData.ppe ? '✓' : '✗'}
- Communication: ${formData.communication ? '✓' : '✗'}

Final Check:
- Safety Confirmation: ${formData.safetyConfirm ? '✓' : '✗'}
- Paperwork: ${formData.paperwork ? '✓' : '✗'}
- Escort Coordination: ${formData.escortCoordination ? '✓' : '✗'}
`;

      // In a real application, you would send this to your backend
      console.log('Email would be sent to:', formData.email);
      console.log('Email content:', emailBody);

      setSuccess(true);
    } catch (err) {
      setError('Failed to submit form. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="bg-green-50 p-6 rounded-lg border border-green-200">
        <div className="flex items-center mb-4">
          <CheckCircle2 className="h-8 w-8 text-green-500 mr-3" />
          <div>
            <h3 className="text-green-800 font-semibold">Take 5 Checklist Submitted Successfully!</h3>
            <p className="text-green-700 text-sm">A copy has been sent to your email.</p>
          </div>
        </div>
        <button
          onClick={() => {
            setSuccess(false);
            setFormData({
              ...formData,
              driverName: '',
              supervisorName: '',
              email: '',
              defects: '',
              weatherConditions: ''
            });
          }}
          className="mt-4 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center"
        >
          <FileCheck className="h-5 w-5 mr-2" />
          Submit Another
        </button>
      </div>
    );
  }

  const renderSection = (title: string, icon: React.ReactNode, children: React.ReactNode) => (
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
      <div className="flex items-center mb-4">
        {icon}
        <h3 className="text-lg font-semibold text-gray-900 ml-3">{title}</h3>
      </div>
      {children}
    </div>
  );

  const renderCheckbox = (label: string, name: keyof FormData) => (
    <label className="flex items-center space-x-3">
      <input
        type="checkbox"
        checked={formData[name] as boolean}
        onChange={(e) => setFormData({ ...formData, [name]: e.target.checked })}
        className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
      />
      <span className="text-gray-700">{label}</span>
    </label>
  );

  return (
    <div className="space-y-8">
      {/* Safety First Banner */}
      <div className="bg-[#ED4235]/5 p-6 rounded-lg border border-[#ED4235]/20">
        <div className="flex items-start">
          <ShieldCheck className="h-8 w-8 text-[#ED4235] flex-shrink-0 mt-1" />
          <div className="ml-4">
            <h3 className="text-lg font-semibold text-gray-900">Safety is Everyone's Responsibility</h3>
            <p className="mt-1 text-gray-600">
              This Take 5 checklist is designed to ensure your safety and the safety of others. 
              Take your time to complete it thoroughly before starting your journey.
            </p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Vehicle Condition Check */}
        {renderSection("Vehicle Condition Check", <Truck className="h-6 w-6 text-[#ED4235]" />, (
          <div className="space-y-3">
            {renderCheckbox("Brakes are working properly and air system checked", "brakes")}
            {renderCheckbox("Tires are properly inflated and in good condition", "tires")}
            {renderCheckbox("All lights and signals are functioning", "lights")}
            {renderCheckbox("Mirrors are clean and properly adjusted", "mirrors")}
            {renderCheckbox("Windshield wipers and washer fluid operational", "wipers")}
          </div>
        ))}

        {/* Cargo Securement */}
        {renderSection("Cargo Securement", <FileCheck className="h-6 w-6 text-[#ED4235]" />, (
          <div className="space-y-3">
            {renderCheckbox("Load tie-downs are properly secured", "tieDowns")}
            {renderCheckbox("Load is evenly distributed", "loadDistribution")}
            {renderCheckbox("Cargo is stable and cannot shift", "cargoShifting")}
            {renderCheckbox("Oversize signs and flags are properly displayed", "oversizeSigns")}
          </div>
        ))}

        {/* Pre-Trip Inspection */}
        {renderSection("Pre-Trip Inspection", <FileText className="h-6 w-6 text-[#ED4235]" />, (
          <div className="space-y-3">
            {renderCheckbox("All required documentation is present", "documentation")}
            <div>
              <label className="block text-sm font-medium text-gray-700">Defects or Issues Found</label>
              <textarea
                value={formData.defects}
                onChange={(e) => setFormData({ ...formData, defects: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                rows={3}
                placeholder="Describe any defects or issues found..."
              />
            </div>
            {renderCheckbox("Required emergency equipment is present", "requiredEquipment")}
          </div>
        ))}

        {/* Route & Weather */}
        {renderSection("Route & Weather", <CloudSun className="h-6 w-6 text-[#ED4235]" />, (
          <div className="space-y-3">
            {renderCheckbox("Route has been reviewed and planned", "routePlanning")}
            {renderCheckbox("All required permits are in hand", "permits")}
            <div>
              <label className="block text-sm font-medium text-gray-700">Weather Conditions</label>
              <textarea
                value={formData.weatherConditions}
                onChange={(e) => setFormData({ ...formData, weatherConditions: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                rows={2}
                placeholder="Describe current weather conditions..."
              />
            </div>
          </div>
        ))}

        {/* Driver Fitness */}
        {renderSection("Driver Fitness", <UserCheck className="h-6 w-6 text-[#ED4235]" />, (
          <div className="space-y-3">
            {renderCheckbox("Had adequate rest and sleep", "rest")}
            {renderCheckbox("Free from distractions", "distractions")}
            {renderCheckbox("Wearing appropriate PPE", "ppe")}
            {renderCheckbox("Communication equipment checked", "communication")}
          </div>
        ))}

        {/* Final Check */}
        {renderSection("Final Check", <CheckCircle2 className="h-6 w-6 text-[#ED4235]" />, (
          <div className="space-y-3">
            {renderCheckbox("Safety-first approach confirmed", "safetyConfirm")}
            {renderCheckbox("All paperwork is complete", "paperwork")}
            {renderCheckbox("Escort coordination confirmed (if applicable)", "escortCoordination")}
          </div>
        ))}

        {/* Sign Off */}
        {renderSection("Sign Off", <Users className="h-6 w-6 text-[#ED4235]" />, (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Driver's Name</label>
              <input
                type="text"
                value={formData.driverName}
                onChange={(e) => setFormData({ ...formData, driverName: e.target.value })}
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Date</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Supervisor's Name</label>
              <input
                type="text"
                value={formData.supervisorName}
                onChange={(e) => setFormData({ ...formData, supervisorName: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Email Address</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                placeholder="Enter email to receive a copy"
              />
            </div>
          </div>
        ))}

        {error && (
          <div className="bg-red-50 p-4 rounded-md flex items-center text-red-700 border border-red-200">
            <AlertTriangle className="h-5 w-5 mr-2" />
            {error}
          </div>
        )}

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-3 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50 flex items-center font-medium shadow-lg hover:shadow-xl transition-all"
          >
            <Send className="h-5 w-5 mr-2" />
            {submitting ? 'Submitting...' : 'Submit Take 5'}
          </button>
        </div>
      </form>
    </div>
  );
};