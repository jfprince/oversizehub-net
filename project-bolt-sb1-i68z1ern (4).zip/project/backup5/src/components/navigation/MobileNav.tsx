import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ChevronDown } from 'lucide-react';
import { mainNavItems } from './config/mainNavItems';
import { LanguageSelector } from '../LanguageSelector';
import { useAuth } from '../auth/AuthProvider';

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [expandedItem, setExpandedItem] = useState<string | null>(null);

  if (!isOpen) return null;

  return (
    <div className="lg:hidden fixed inset-0 z-50">
      <div className="fixed inset-0 bg-black bg-opacity-25" onClick={onClose} />
      <div className="fixed inset-y-0 right-0 max-w-xs w-full bg-white shadow-xl overflow-y-auto">
        <div className="p-6 space-y-6">
          {mainNavItems.map((item) => (
            <div key={item.id}>
              {item.subItems ? (
                <div className="space-y-2">
                  <button
                    onClick={() => setExpandedItem(expandedItem === item.id ? null : item.id)}
                    className="flex items-center justify-between w-full text-left"
                  >
                    <span className="flex items-center text-gray-700">
                      <item.icon className="h-5 w-5 mr-2" />
                      {item.label}
                    </span>
                    <ChevronDown 
                      className={`h-5 w-5 transform transition-transform ${
                        expandedItem === item.id ? 'rotate-180' : ''
                      }`} 
                    />
                  </button>
                  
                  {expandedItem === item.id && (
                    <div className="pl-8 space-y-2">
                      {item.subItems.map((subItem) => (
                        <Link
                          key={subItem.id}
                          to={subItem.link || '#'}
                          className="flex items-center text-gray-600 hover:text-[#ED4235]"
                          onClick={onClose}
                        >
                          {subItem.icon && <subItem.icon className="h-4 w-4 mr-2" />}
                          {subItem.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  to={item.link || '#'}
                  className="flex items-center text-gray-700 hover:text-[#ED4235]"
                  onClick={onClose}
                >
                  <item.icon className="h-5 w-5 mr-2" />
                  {item.label}
                </Link>
              )}
            </div>
          ))}

          <div className="pt-6 border-t border-gray-200">
            <LanguageSelector />
          </div>

          <div className="pt-6">
            {user ? (
              <Link
                to="/profile"
                className="block w-full px-4 py-2 text-center bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
                onClick={onClose}
              >
                {t('navigation.profile')}
              </Link>
            ) : (
              <Link
                to="/login"
                className="block w-full px-4 py-2 text-center bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
                onClick={onClose}
              >
                {t('auth.login')}
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};