import React from 'react';
import { Link } from 'react-router-dom';
import { NavSubItemType } from './types';

interface NavDropdownProps {
  items: NavSubItemType[];
  onClose: () => void;
}

export const NavDropdown: React.FC<NavDropdownProps> = ({ items, onClose }) => {
  return (
    <div className="absolute right-0 mt-1 w-56 bg-white rounded-lg shadow-lg border border-gray-100 py-1 z-50">
      {items.map((item) => (
        item.disabled ? (
          <div
            key={item.id}
            className="flex items-center px-4 py-2 text-sm text-gray-400 cursor-not-allowed"
          >
            {item.icon && <item.icon className="h-4 w-4 mr-2" />}
            <span>{item.label}</span>
          </div>
        ) : (
          <Link
            key={item.id}
            to={item.link || '#'}
            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#ED4235] transition-colors"
            onClick={onClose}
          >
            {item.icon && <item.icon className="h-4 w-4 mr-2" />}
            <span>{item.label}</span>
          </Link>
        )
      ))}
    </div>
  );
};