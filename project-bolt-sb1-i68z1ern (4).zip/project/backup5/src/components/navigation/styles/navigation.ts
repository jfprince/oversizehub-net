export const navItemStyles = {
  base: "px-3 py-2 text-sm font-medium text-gray-700 hover:text-[#ED4235] transition-colors rounded-md hover:bg-gray-50 flex items-center",
  active: "text-[#ED4235] bg-red-50",
  icon: "h-4 w-4 mr-2",
  chevron: "ml-1 h-4 w-4 transition-transform duration-200"
};

export const dropdownStyles = {
  container: "absolute right-0 mt-1 w-56 bg-white rounded-lg shadow-lg border border-gray-100 py-1 z-50",
  item: "flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-[#ED4235] transition-colors",
  icon: "h-4 w-4 mr-2"
};