import { LucideIcon } from 'lucide-react';

export interface NavSubItemType {
  id: string;
  label: string;
  link?: string;
  icon?: LucideIcon;
  disabled?: boolean;
}

export interface NavItemType {
  id: string;
  label: string;
  link?: string;
  icon: LucideIcon;
  subItems?: NavSubItemType[];
  disabled?: boolean;
}

export interface FooterItem {
  label: string;
  href: string;
  external?: boolean;
  disabled?: boolean;
}

export interface FooterSection {
  title: string;
  icon: LucideIcon;
  items: FooterItem[];
}