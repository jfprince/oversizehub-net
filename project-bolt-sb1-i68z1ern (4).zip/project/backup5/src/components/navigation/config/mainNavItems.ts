import {
  Home,
  Map,
  Navigation,
  FileText,
  Shield,
  Truck,
  Globe,
  DollarSign,
  Building2,
  HelpCircle,
  Mail,
  BookOpen,
  Newspaper,
  Phone,
  MapPin
} from 'lucide-react';
import { NavItemType } from '../types';

export const mainNavItems: NavItemType[] = [
  {
    id: 'home',
    label: 'Home',
    link: '/',
    icon: Home
  },
  {
    id: 'map',
    label: 'Map',
    link: '/map',
    icon: Map
  },
  {
    id: 'services',
    label: 'Services',
    icon: Truck,
    subItems: [
      { id: 'advanced-mapping', label: 'Advanced Mapping', icon: Map, disabled: true },
      { id: 'route-planning', label: 'Route Planning', icon: Navigation, disabled: true },
      { id: 'permit-management', label: 'Permit Management', icon: FileText, disabled: true },
      { id: 'escort-services', label: 'Escort Services', icon: Shield, disabled: true },
      { id: 'border-crossing', label: 'Border Crossing', icon: Globe, disabled: true },
      { id: 'compliance', label: 'Compliance Requirements', link: '/features/compliance', icon: Shield },
      { id: 'safety', label: 'Safety Regulations', link: '/features/safety', icon: Shield },
      { id: 'collaboration', label: 'Team Collaboration', icon: Building2, disabled: true },
      { id: 'road-survey', label: 'Road Survey', icon: MapPin, disabled: true }
    ]
  },
  {
    id: 'pricing',
    label: 'Pricing',
    link: '/pricing',
    icon: DollarSign
  },
  {
    id: 'resources',
    label: 'Resources',
    icon: HelpCircle,
    subItems: [
      { id: 'documentation', label: 'Documentation', icon: FileText, disabled: true },
      { id: 'industry-news', label: 'Industry News', icon: Newspaper, disabled: true },
      { id: 'case-studies', label: 'Case Studies', icon: BookOpen, disabled: true },
      { id: 'regulations', label: 'Regulations', icon: Shield, disabled: true },
      { id: 'faqs', label: 'FAQs', icon: HelpCircle, disabled: true },
      { id: 'blog', label: 'Blog', icon: FileText, disabled: true },
      { id: 'support', label: 'Support', icon: Phone, disabled: true },
      { id: 'contact', label: 'Contact Us', icon: Mail, disabled: true }
    ]
  }
];