import {
  Building2,
  Users,
  Shield,
  Navigation,
  Map,
  FileText,
  Truck,
  Globe,
  BookOpen,
  Newspaper,
  Phone,
  Mail,
  Linkedin,
  Twitter,
  HandshakeIcon,
  GraduationCap,
  Heart
} from 'lucide-react';
import { FooterSection } from '../types';

export const footerItems: FooterSection[] = [
  {
    title: 'About Us',
    icon: Building2,
    items: [
      { label: 'Overview', href: '/about', disabled: true },
      { label: 'Mission & Vision', href: '/about/mission', disabled: true },
      { label: 'Team', href: '/about/team', disabled: true }
    ]
  },
  {
    title: 'Services',
    icon: Truck,
    items: [
      { label: 'Route Planning', href: '/map' },
      { label: 'Permit Management', href: '/services/permits', disabled: true },
      { label: 'Escort Services', href: '/services/escort', disabled: true },
      { label: 'Border Crossing', href: '/services/border', disabled: true },
      { label: 'Compliance & Safety', href: '/features/compliance' },
      { label: 'Team Collaboration', href: '/services/collaboration', disabled: true }
    ]
  },
  {
    title: 'Resources',
    icon: BookOpen,
    items: [
      { label: 'Blog', href: '/blog', disabled: true },
      { label: 'Industry News', href: '/news', disabled: true },
      { label: 'Case Studies', href: '/case-studies', disabled: true },
      { label: 'FAQs', href: '/faqs', disabled: true },
      { label: 'Regulations', href: '/regulations', disabled: true }
    ]
  },
  {
    title: 'Contact',
    icon: Mail,
    items: [
      { label: 'Contact Form', href: '/contact', disabled: true },
      { label: 'info@oversizehub.net', href: 'mailto:info@oversizehub.net' },
      { label: 'LinkedIn', href: 'https://linkedin.com/company/oversizehub', external: true },
      { label: 'Twitter', href: 'https://twitter.com/oversizehub', external: true }
    ]
  },
  {
    title: 'Partners',
    icon: HandshakeIcon,
    items: [
      { label: 'Regulatory Authorities', href: '/partners/authorities', disabled: true },
      { label: 'Escort Services', href: '/partners/escort-services', disabled: true },
      { label: 'Transport Companies', href: '/partners/transport', disabled: true }
    ]
  },
  {
    title: 'Legal',
    icon: Shield,
    items: [
      { label: 'Privacy Policy', href: '/legal/privacy', disabled: true },
      { label: 'Terms & Conditions', href: '/legal/terms', disabled: true },
      { label: 'Cookie Policy', href: '/legal/cookies', disabled: true },
      { label: 'Disclaimer', href: '/legal/disclaimer', disabled: true }
    ]
  },
  {
    title: 'Get Involved',
    icon: Heart,
    items: [
      { label: 'Job Opportunities', href: '/careers', disabled: true },
      { label: 'Become a Partner', href: '/partners/join', disabled: true },
      { label: 'Sponsorship', href: '/sponsorship', disabled: true },
      { label: 'Stay Updated', href: '/newsletter', disabled: true }
    ]
  }
];