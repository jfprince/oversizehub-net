import React, { useState, useEffect } from 'react';
import { useRouteStore } from '../../stores/routeStore';
import { 
  Truck, 
  Plus, 
  X, 
  MapPin, 
  Navigation,
  CornerDownRight,
  Ruler,
  Weight,
  ArrowRight
} from 'lucide-react';
import { useDebounce } from 'use-debounce';

interface Suggestion {
  place_name: string;
  center: [number, number];
}

interface VehicleConfig {
  type: 'car' | 'truck' | 'oversized';
  dimensions: {
    length: number;
    width: number;
    height: number;
    weight: number;
  };
}

export const RoutePanel: React.FC = () => {
  const { waypoints, addWaypoint, removeWaypoint, clearRoute } = useRouteStore();
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [activeInput, setActiveInput] = useState<'origin' | 'destination' | null>(null);
  const [debouncedSearch] = useDebounce(activeInput === 'origin' ? origin : destination, 300);
  const [routeType, setRouteType] = useState<'fastest' | 'shortest' | 'custom'>('fastest');
  const [vehicleConfig, setVehicleConfig] = useState<VehicleConfig>({
    type: 'truck',
    dimensions: {
      length: 0,
      width: 0,
      height: 0,
      weight: 0
    }
  });
  const [showVehicleConfig, setShowVehicleConfig] = useState(false);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (!debouncedSearch) {
        setSuggestions([]);
        return;
      }

      try {
        const response = await fetch(
          `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(debouncedSearch)}.json?` +
          `access_token=${import.meta.env.VITE_MAPBOX_TOKEN}&types=address,place`
        );
        const data = await response.json();
        setSuggestions(data.features);
      } catch (error) {
        console.error('Error fetching suggestions:', error);
      }
    };

    fetchSuggestions();
  }, [debouncedSearch]);

  const handleSuggestionSelect = (suggestion: Suggestion) => {
    if (activeInput === 'origin') {
      setOrigin(suggestion.place_name);
      addWaypoint(suggestion.center.reverse() as [number, number]);
    } else if (activeInput === 'destination') {
      setDestination(suggestion.place_name);
      addWaypoint(suggestion.center.reverse() as [number, number]);
    }
    setSuggestions([]);
    setActiveInput(null);
  };

  const isValidCoordinate = (value: string) => {
    const coords = value.split(',').map(v => parseFloat(v.trim()));
    return coords.length === 2 && 
           !isNaN(coords[0]) && 
           !isNaN(coords[1]) &&
           coords[0] >= -90 && 
           coords[0] <= 90 && 
           coords[1] >= -180 && 
           coords[1] <= 180;
  };

  const handleInputChange = (value: string, type: 'origin' | 'destination') => {
    if (type === 'origin') {
      setOrigin(value);
    } else {
      setDestination(value);
    }
    setActiveInput(type);

    if (isValidCoordinate(value)) {
      const [lat, lng] = value.split(',').map(v => parseFloat(v.trim()));
      addWaypoint([lat, lng]);
      setSuggestions([]);
      setActiveInput(null);
    }
  };

  return (
    <div className="absolute top-4 left-4 w-96 bg-white rounded-lg shadow-lg p-4 z-10">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold flex items-center">
          <Truck className="h-5 w-5 text-[#ED4235] mr-2" />
          Route Planner
        </h3>
        <button
          onClick={() => setShowVehicleConfig(!showVehicleConfig)}
          className="text-gray-500 hover:text-[#ED4235]"
        >
          <Ruler className="h-5 w-5" />
        </button>
      </div>

      {showVehicleConfig && (
        <div className="mb-4 p-4 bg-gray-50 rounded-lg space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700">Vehicle Type</label>
            <select
              value={vehicleConfig.type}
              onChange={(e) => setVehicleConfig({
                ...vehicleConfig,
                type: e.target.value as VehicleConfig['type']
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            >
              <option value="car">Car</option>
              <option value="truck">Truck</option>
              <option value="oversized">Oversized Load</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
              <input
                type="number"
                value={vehicleConfig.dimensions.length}
                onChange={(e) => setVehicleConfig({
                  ...vehicleConfig,
                  dimensions: {
                    ...vehicleConfig.dimensions,
                    length: parseFloat(e.target.value)
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
              <input
                type="number"
                value={vehicleConfig.dimensions.width}
                onChange={(e) => setVehicleConfig({
                  ...vehicleConfig,
                  dimensions: {
                    ...vehicleConfig.dimensions,
                    width: parseFloat(e.target.value)
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
              <input
                type="number"
                value={vehicleConfig.dimensions.height}
                onChange={(e) => setVehicleConfig({
                  ...vehicleConfig,
                  dimensions: {
                    ...vehicleConfig.dimensions,
                    height: parseFloat(e.target.value)
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
              <input
                type="number"
                value={vehicleConfig.dimensions.weight}
                onChange={(e) => setVehicleConfig({
                  ...vehicleConfig,
                  dimensions: {
                    ...vehicleConfig.dimensions,
                    weight: parseFloat(e.target.value)
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {/* Origin Input */}
        <div className="relative">
          <div className="flex items-center space-x-2">
            <MapPin className="h-5 w-5 text-[#ED4235]" />
            <input
              type="text"
              value={origin}
              onChange={(e) => handleInputChange(e.target.value, 'origin')}
              placeholder="Enter origin (address or coordinates)"
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          {activeInput === 'origin' && suggestions.length > 0 && (
            <div className="absolute z-10 w-full mt-1 bg-white rounded-md shadow-lg max-h-60 overflow-auto">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionSelect(suggestion)}
                  className="w-full text-left px-4 py-2 hover:bg-gray-100"
                >
                  {suggestion.place_name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Destination Input */}
        <div className="relative">
          <div className="flex items-center space-x-2">
            <MapPin className="h-5 w-5 text-[#ED4235]" />
            <input
              type="text"
              value={destination}
              onChange={(e) => handleInputChange(e.target.value, 'destination')}
              placeholder="Enter destination (address or coordinates)"
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          {activeInput === 'destination' && suggestions.length > 0 && (
            <div className="absolute z-10 w-full mt-1 bg-white rounded-md shadow-lg max-h-60 overflow-auto">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => handleSuggestionSelect(suggestion)}
                  className="w-full text-left px-4 py-2 hover:bg-gray-100"
                >
                  {suggestion.place_name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Route Type Selection */}
        <div className="flex space-x-2">
          <button
            onClick={() => setRouteType('fastest')}
            className={`flex-1 py-2 px-3 rounded-md ${
              routeType === 'fastest'
                ? 'bg-[#ED4235] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Fastest
          </button>
          <button
            onClick={() => setRouteType('shortest')}
            className={`flex-1 py-2 px-3 rounded-md ${
              routeType === 'shortest'
                ? 'bg-[#ED4235] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Shortest
          </button>
          <button
            onClick={() => setRouteType('custom')}
            className={`flex-1 py-2 px-3 rounded-md ${
              routeType === 'custom'
                ? 'bg-[#ED4235] text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Custom
          </button>
        </div>

        {/* Waypoints List */}
        <div className="space-y-2">
          {waypoints.map((waypoint, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-2 bg-gray-50 rounded-md"
            >
              <div className="flex items-center">
                {index === 0 ? (
                  <MapPin className="h-4 w-4 text-green-500 mr-2" />
                ) : index === waypoints.length - 1 ? (
                  <MapPin className="h-4 w-4 text-red-500 mr-2" />
                ) : (
                  <CornerDownRight className="h-4 w-4 text-blue-500 mr-2" />
                )}
                <span className="text-sm text-gray-700">
                  {`${waypoint[0].toFixed(4)}, ${waypoint[1].toFixed(4)}`}
                </span>
              </div>
              <button
                onClick={() => removeWaypoint(index)}
                className="text-gray-400 hover:text-red-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-2">
          <button
            onClick={() => clearRoute()}
            className="flex-1 py-2 px-4 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Clear
          </button>
          <button
            className="flex-1 py-2 px-4 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 flex items-center justify-center"
          >
            <Navigation className="h-4 w-4 mr-2" />
            Calculate Route
          </button>
        </div>
      </div>
    </div>
  );
};