import React, { useCallback, useEffect, useRef } from 'react';
import Map, { NavigationControl, Source, Layer } from 'react-map-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { MAPBOX_TOKEN, MAPBOX_STYLES, DEFAULT_CENTER, DEFAULT_ZOOM } from '../../config/mapbox';
import { MapControls } from './MapControls';
import { RouteLayer } from './RouteLayer';
import { useMapStore } from '../../stores/mapStore';
import { MapToolbar } from './MapToolbar';
import { useRouteStore } from '../../stores/routeStore';
import { MapTabs } from './MapTabs';

const MapView: React.FC = () => {
  const mapRef = useRef(null);
  const { viewport, setViewport } = useMapStore();
  const { route, waypoints } = useRouteStore();

  const onMove = useCallback(({ viewState }) => {
    setViewport({
      longitude: viewState.longitude,
      latitude: viewState.latitude,
      zoom: viewState.zoom
    });
  }, []);

  return (
    <div className="relative h-[calc(100vh-4rem)] w-full">
      <Map
        ref={mapRef}
        mapboxAccessToken={MAPBOX_TOKEN}
        initialViewState={{
          longitude: DEFAULT_CENTER[0],
          latitude: DEFAULT_CENTER[1],
          zoom: DEFAULT_ZOOM
        }}
        style={{ width: '100%', height: '100%' }}
        mapStyle={MAPBOX_STYLES.STREETS}
        onMove={onMove}
      >
        <NavigationControl position="bottom-right" />
        <MapControls />
        <MapToolbar />
        <RouteLayer route={route} waypoints={waypoints} />
      </Map>
      <MapTabs />
    </div>
  );
};

export default MapView;