import React from 'react';
import { Layers, Navigation, ZoomIn, ZoomOut } from 'lucide-react';
import { useMapStore } from '../../stores/mapStore';
import { MAPBOX_STYLES } from '../../config/mapbox';

export const MapToolbar: React.FC = () => {
  const { setMapStyle } = useMapStore();

  return (
    <div className="absolute left-4 top-4 z-10 flex flex-col gap-2 bg-white rounded-lg shadow-lg p-2">
      <button
        onClick={() => setMapStyle(MAPBOX_STYLES.STREETS)}
        className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        title="Street View"
      >
        <Navigation className="h-5 w-5 text-gray-700" />
      </button>
      <button
        onClick={() => setMapStyle(MAPBOX_STYLES.SATELLITE)}
        className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        title="Satellite View"
      >
        <Layers className="h-5 w-5 text-gray-700" />
      </button>
    </div>
  );
};