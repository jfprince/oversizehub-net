import React from 'react';
import { Layers, Navigation, ZoomIn, ZoomOut } from 'lucide-react';
import { useMap } from 'react-map-gl';

export const MapControls: React.FC = () => {
  const { current: map } = useMap();

  const handleZoomIn = () => {
    if (map) {
      map.zoomIn();
    }
  };

  const handleZoomOut = () => {
    if (map) {
      map.zoomOut();
    }
  };

  return (
    <div className="absolute right-4 top-4 z-[1000] flex flex-col gap-2">
      <button
        onClick={handleZoomIn}
        className="rounded-lg bg-white p-2 shadow-lg hover:bg-gray-50 transition-colors"
        aria-label="Zoom in"
      >
        <ZoomIn className="h-6 w-6 text-gray-700" />
      </button>
      <button
        onClick={handleZoomOut}
        className="rounded-lg bg-white p-2 shadow-lg hover:bg-gray-50 transition-colors"
        aria-label="Zoom out"
      >
        <ZoomOut className="h-6 w-6 text-gray-700" />
      </button>
      <button 
        className="rounded-lg bg-white p-2 shadow-lg hover:bg-gray-50 transition-colors"
        aria-label="Toggle layers"
      >
        <Layers className="h-6 w-6 text-gray-700" />
      </button>
      <button 
        className="rounded-lg bg-white p-2 shadow-lg hover:bg-gray-50 transition-colors"
        aria-label="Toggle navigation"
      >
        <Navigation className="h-6 w-6 text-gray-700" />
      </button>
    </div>
  );
};