import React from 'react';
import { Source, Layer } from 'react-map-gl';
import { MapFeature } from '../../../types/map';

interface DrawingLayerProps {
  features: MapFeature[];
}

export const DrawingLayer: React.FC<DrawingLayerProps> = ({ features }) => {
  const geojson = {
    type: 'FeatureCollection',
    features: features.map(feature => ({
      type: 'Feature',
      geometry: {
        type: feature.type === 'point' ? 'Point' : 
              feature.type === 'line' ? 'LineString' : 'Polygon',
        coordinates: feature.coordinates
      },
      properties: feature.properties
    }))
  };

  return (
    <>
      <Source id="drawing-source" type="geojson" data={geojson}>
        <Layer
          id="drawing-points"
          type="circle"
          paint={{
            'circle-radius': 6,
            'circle-color': '#ED4235',
            'circle-stroke-width': 2,
            'circle-stroke-color': '#ffffff'
          }}
          filter={['==', '$type', 'Point']}
        />
        <Layer
          id="drawing-lines"
          type="line"
          paint={{
            'line-color': '#ED4235',
            'line-width': 2
          }}
          filter={['==', '$type', 'LineString']}
        />
        <Layer
          id="drawing-polygons"
          type="fill"
          paint={{
            'fill-color': '#ED4235',
            'fill-opacity': 0.3,
            'fill-outline-color': '#ED4235'
          }}
          filter={['==', '$type', 'Polygon']}
        />
      </Source>
    </>
  );
};