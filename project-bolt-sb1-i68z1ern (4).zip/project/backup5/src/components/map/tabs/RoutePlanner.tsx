import React, { useState } from 'react';
import { MapPin, Navigation, Truck, X } from 'lucide-react';
import { AddressSearch } from '../AddressSearch';

interface VehicleConfig {
  type: 'car' | 'truck' | 'oversized';
  dimensions?: {
    length: number;
    width: number;
    height: number;
    weight: number;
  };
}

export const RoutePlanner: React.FC = () => {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [waypoints, setWaypoints] = useState<string[]>([]);
  const [routeType, setRouteType] = useState<'shortest' | 'fastest' | 'custom'>('fastest');
  const [vehicleConfig, setVehicleConfig] = useState<VehicleConfig>({ type: 'car' });

  const handleAddWaypoint = () => {
    setWaypoints([...waypoints, '']);
  };

  const handleRemoveWaypoint = (index: number) => {
    setWaypoints(waypoints.filter((_, i) => i !== index));
  };

  const handleClear = () => {
    setOrigin('');
    setDestination('');
    setWaypoints([]);
    setVehicleConfig({ type: 'car' });
  };

  return (
    <div className="space-y-4">
      {/* Origin */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Origin</label>
        <AddressSearch
          value={origin}
          onChange={setOrigin}
          placeholder="Enter origin address or coordinates"
        />
      </div>

      {/* Waypoints */}
      {waypoints.map((waypoint, index) => (
        <div key={index} className="relative">
          <label className="block text-sm font-medium text-gray-700 mb-1">Waypoint {index + 1}</label>
          <div className="flex gap-2">
            <AddressSearch
              value={waypoint}
              onChange={(value) => {
                const newWaypoints = [...waypoints];
                newWaypoints[index] = value;
                setWaypoints(newWaypoints);
              }}
              placeholder="Enter waypoint address or coordinates"
            />
            <button
              onClick={() => handleRemoveWaypoint(index)}
              className="text-gray-400 hover:text-red-500"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      ))}

      <button
        onClick={handleAddWaypoint}
        className="text-[#ED4235] hover:text-[#ED4235]/80 text-sm font-medium"
      >
        + Add Waypoint
      </button>

      {/* Destination */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Destination</label>
        <AddressSearch
          value={destination}
          onChange={setDestination}
          placeholder="Enter destination address or coordinates"
        />
      </div>

      {/* Route Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Route Type</label>
        <div className="flex gap-2">
          {(['shortest', 'fastest', 'custom'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setRouteType(type)}
              className={`flex-1 py-2 px-3 rounded-md capitalize ${
                routeType === type
                  ? 'bg-[#ED4235] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Vehicle Configuration */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Vehicle Type</label>
        <select
          value={vehicleConfig.type}
          onChange={(e) => setVehicleConfig({ type: e.target.value as VehicleConfig['type'] })}
          className="w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="car">Car</option>
          <option value="truck">Truck</option>
          <option value="oversized">Oversized Load</option>
        </select>
      </div>

      {/* Dimensions for Oversized Load */}
      {vehicleConfig.type === 'oversized' && (
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
            <input
              type="number"
              value={vehicleConfig.dimensions?.length || ''}
              onChange={(e) => setVehicleConfig({
                ...vehicleConfig,
                dimensions: {
                  ...vehicleConfig.dimensions,
                  length: parseFloat(e.target.value)
                }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
            <input
              type="number"
              value={vehicleConfig.dimensions?.width || ''}
              onChange={(e) => setVehicleConfig({
                ...vehicleConfig,
                dimensions: {
                  ...vehicleConfig.dimensions,
                  width: parseFloat(e.target.value)
                }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
            <input
              type="number"
              value={vehicleConfig.dimensions?.height || ''}
              onChange={(e) => setVehicleConfig({
                ...vehicleConfig,
                dimensions: {
                  ...vehicleConfig.dimensions,
                  height: parseFloat(e.target.value)
                }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
            <input
              type="number"
              value={vehicleConfig.dimensions?.weight || ''}
              onChange={(e) => setVehicleConfig({
                ...vehicleConfig,
                dimensions: {
                  ...vehicleConfig.dimensions,
                  weight: parseFloat(e.target.value)
                }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4 pt-4">
        <button
          onClick={handleClear}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
        >
          Clear
        </button>
        <button
          className="flex-1 px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 flex items-center justify-center"
        >
          <Navigation className="h-4 w-4 mr-2" />
          Calculate Route
        </button>
      </div>
    </div>
  );
};