import React, { useState } from 'react';
import { Layers, Plus, Trash } from 'lucide-react';

interface MapLayer {
  id: string;
  name: string;
  type: string;
  visible: boolean;
}

export const MapManagement: React.FC = () => {
  const [selectedProvider, setSelectedProvider] = useState('openstreet');
  const [layers, setLayers] = useState<MapLayer[]>([
    { id: 'base', name: 'Base Layer', type: 'base', visible: true }
  ]);

  const handleAddLayer = () => {
    const newLayer: MapLayer = {
      id: Date.now().toString(),
      name: `Layer ${layers.length + 1}`,
      type: 'custom',
      visible: true
    };
    setLayers([...layers, newLayer]);
  };

  const handleRemoveLayer = (layerId: string) => {
    setLayers(layers.filter(layer => layer.id !== layerId));
  };

  return (
    <div className="space-y-6">
      {/* Map Provider Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Map Provider</label>
        <select
          value={selectedProvider}
          onChange={(e) => setSelectedProvider(e.target.value)}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="openstreet">OpenStreetMap</option>
          <option value="igo2">IGO2</option>
          <option value="google">Google Maps</option>
          <option value="topo">Topographic</option>
          <option value="satellite">Satellite</option>
          <option value="custom">Custom</option>
        </select>
      </div>

      {/* Layer Management */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-medium text-gray-700">Map Layers</h3>
          <button
            onClick={handleAddLayer}
            className="text-[#ED4235] hover:text-[#ED4235]/80 text-sm font-medium flex items-center"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add Layer
          </button>
        </div>

        <div className="space-y-2">
          {layers.map(layer => (
            <div
              key={layer.id}
              className="flex items-center justify-between bg-gray-50 p-2 rounded-md"
            >
              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={layer.visible}
                  onChange={(e) => {
                    setLayers(layers.map(l =>
                      l.id === layer.id ? { ...l, visible: e.target.checked } : l
                    ));
                  }}
                  className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
                />
                <span className="ml-2 text-sm text-gray-700">{layer.name}</span>
              </div>
              {layer.type !== 'base' && (
                <button
                  onClick={() => handleRemoveLayer(layer.id)}
                  className="text-gray-400 hover:text-red-500"
                >
                  <Trash className="h-4 w-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Save Button */}
      <div>
        <button className="w-full px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
          Apply Changes
        </button>
      </div>
    </div>
  );
};