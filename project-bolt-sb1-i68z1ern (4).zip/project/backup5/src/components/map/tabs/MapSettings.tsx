import React, { useState } from 'react';
import { Globe, Share2, Eye, Sliders } from 'lucide-react';

export const MapSettings: React.FC = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [privacy, setPrivacy] = useState<'private' | 'public' | 'shared'>('private');
  const [settings, setSettings] = useState({
    showSearch: true,
    showEmbed: true,
    showInfoBox: true,
    showMenu: true,
    showTabs: true,
    showLocation: true,
    showDirections: true,
    iconSize: 'medium'
  });

  return (
    <div className="space-y-6">
      {/* Basic Info */}
      <div>
        <label className="block text-sm font-medium text-gray-700">Map Title</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          placeholder="Enter map title"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          placeholder="Enter map description"
        />
      </div>

      {/* Privacy Settings */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Privacy & Collaboration</label>
        <select
          value={privacy}
          onChange={(e) => setPrivacy(e.target.value as typeof privacy)}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="private">Private</option>
          <option value="public">Public</option>
          <option value="shared">Shared with specific users</option>
        </select>
      </div>

      {/* Sharing Options */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
          <Share2 className="h-4 w-4 mr-2" />
          Sharing Options
        </h3>
        <div className="space-y-2">
          <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md">
            Embed on website
          </button>
          <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md">
            Share link
          </button>
          <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md">
            Push to driver ELD/cell
          </button>
        </div>
      </div>

      {/* Visibility Controls */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
          <Eye className="h-4 w-4 mr-2" />
          Visibility Controls
        </h3>
        <div className="space-y-2">
          {Object.entries(settings).map(([key, value]) => (
            key !== 'iconSize' && (
              <label key={key} className="flex items-center">
                <input
                  type="checkbox"
                  checked={value}
                  onChange={(e) => setSettings({ ...settings, [key]: e.target.checked })}
                  className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
                />
                <span className="ml-2 text-sm text-gray-700">
                  Show {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                </span>
              </label>
            )
          ))}
        </div>
      </div>

      {/* Icon Size */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Icon Size</label>
        <select
          value={settings.iconSize}
          onChange={(e) => setSettings({ ...settings, iconSize: e.target.value })}
          className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="small">Small</option>
          <option value="medium">Medium</option>
          <option value="large">Large</option>
        </select>
      </div>

      {/* Save Button */}
      <div>
        <button className="w-full px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
          Save Settings
        </button>
      </div>
    </div>
  );
};