import React from 'react';
import { Source, Layer, Marker } from 'react-map-gl';
import { MapPin } from 'lucide-react';

interface RouteLayerProps {
  route: LatLngTuple[] | null;
  waypoints: LatLngTuple[];
}

export const RouteLayer: React.FC<RouteLayerProps> = ({ route, waypoints }) => {
  if (!route || !waypoints.length) return null;

  const geojson: GeoJSON.FeatureCollection = {
    type: 'FeatureCollection',
    features: [
      {
        type: 'Feature',
        properties: {},
        geometry: {
          type: 'LineString',
          coordinates: route.map(([lat, lng]) => [lng, lat])
        }
      }
    ]
  };

  return (
    <>
      <Source id="route-source" type="geojson" data={geojson}>
        <Layer
          id="route-layer"
          type="line"
          paint={{
            'line-color': '#ED4235',
            'line-width': 4,
            'line-opacity': 0.8
          }}
        />
      </Source>
      
      {waypoints.map(([lat, lng], index) => {
        const isOrigin = index === 0;
        const isDestination = index === waypoints.length - 1;

        return (
          <Marker
            key={`waypoint-${index}`}
            longitude={lng}
            latitude={lat}
            anchor="bottom"
          >
            <MapPin 
              className={`h-8 w-8 ${
                isOrigin ? 'text-green-500' : 
                isDestination ? 'text-red-500' : 
                'text-blue-500'
              }`}
            />
          </Marker>
        );
      })}
    </>
  );
};