import React, { useState, useRef, useEffect } from 'react';
import { Activity, Server, Database, Globe, X } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { collection, getDocs } from 'firebase/firestore';

interface SystemStatus {
  auth: boolean;
  database: boolean;
  api: boolean;
  collections: {
    [key: string]: boolean;
  };
}

export const SystemStatus: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [status, setStatus] = useState<SystemStatus>({
    auth: false,
    database: false,
    api: false,
    collections: {}
  });
  const [loading, setLoading] = useState(true);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen) {
      checkStatus();
    }
  }, [isOpen]);

  const checkStatus = async () => {
    setLoading(true);
    try {
      // Check Firebase Auth
      const authStatus = auth.currentUser !== null || auth.app !== null;

      // Check Firestore
      let dbStatus = false;
      let collections: { [key: string]: boolean } = {};
      try {
        const usersRef = collection(db, 'users');
        await getDocs(usersRef);
        dbStatus = true;

        // Check collections
        const collectionNames = ['users', 'routes', 'settings'];
        for (const name of collectionNames) {
          try {
            const colRef = collection(db, name);
            await getDocs(colRef);
            collections[name] = true;
          } catch {
            collections[name] = false;
          }
        }
      } catch {
        dbStatus = false;
      }

      setStatus({
        auth: authStatus,
        database: dbStatus,
        api: true, // Assuming API is always available in this context
        collections
      });
    } catch (error) {
      console.error('Error checking system status:', error);
    } finally {
      setLoading(false);
    }
  };

  const StatusIndicator: React.FC<{ active: boolean }> = ({ active }) => (
    <span className={`w-2 h-2 rounded-full ${active ? 'bg-green-500' : 'bg-red-500'}`} />
  );

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 text-gray-600 hover:text-[#ED4235] transition-colors"
      >
        <Activity className="h-4 w-4" />
        <span>System Status</span>
      </button>

      {isOpen && (
        <div className="fixed top-20 right-4 w-80 bg-white rounded-lg shadow-lg max-h-[calc(100vh-6rem)] overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-900">System Status</h3>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="p-4">
            {loading ? (
              <div className="flex justify-center py-4">
                <Activity className="h-8 w-8 text-blue-500 animate-spin" />
              </div>
            ) : (
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Server className="h-5 w-5 text-gray-400" />
                      <span>Authentication</span>
                    </div>
                    <StatusIndicator active={status.auth} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Database className="h-5 w-5 text-gray-400" />
                      <span>Database</span>
                    </div>
                    <StatusIndicator active={status.database} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Globe className="h-5 w-5 text-gray-400" />
                      <span>API</span>
                    </div>
                    <StatusIndicator active={status.api} />
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Collections</h4>
                  <div className="space-y-2">
                    {Object.entries(status.collections).map(([name, active]) => (
                      <div key={name} className="flex items-center justify-between">
                        <span className="text-gray-600">{name}</span>
                        <StatusIndicator active={active} />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="text-xs text-gray-500 text-right">
                  Last checked: {new Date().toLocaleTimeString()}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};