import React, { useState } from 'react';
import { Clock, Lock } from 'lucide-react';
import { validateBypassCode } from '../lib/database/maintenance';
import { Logo } from './ui/Logo';

interface MaintenanceScreenProps {
  message: string;
  endTime: string;
  onBypass: () => void;
}

export const MaintenanceScreen: React.FC<MaintenanceScreenProps> = ({ 
  message, 
  endTime, 
  onBypass 
}) => {
  const [bypassCode, setBypassCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleBypass = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const isValid = await validateBypassCode(bypassCode);
      if (isValid) {
        onBypass();
      } else {
        setError('Invalid bypass code');
      }
    } catch (err) {
      setError('Failed to validate bypass code');
    } finally {
      setLoading(false);
    }
  };

  const endTimeDate = new Date(endTime);
  const timeRemaining = endTimeDate.getTime() - Date.now();
  const hoursRemaining = Math.max(0, Math.floor(timeRemaining / (1000 * 60 * 60)));
  const minutesRemaining = Math.max(0, Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60)));

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center">
      <div className="w-full max-w-md mt-20">
        <Logo className="mx-auto transform scale-125" />
      </div>
      
      <div className="flex-1 w-full max-w-md px-4 flex flex-col justify-center -mt-12">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Under Maintenance</h2>
          <p className="mt-2 text-gray-600">{message}</p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg space-y-6">
          <div className="flex items-center justify-center space-x-4 text-gray-600">
            <Clock className="h-5 w-5" />
            <span>
              Expected completion in: {hoursRemaining}h {minutesRemaining}m
            </span>
          </div>

          <form onSubmit={handleBypass} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                <div className="flex items-center space-x-2">
                  <Lock className="h-4 w-4" />
                  <span>Bypass Code</span>
                </div>
              </label>
              <input
                type="text"
                value={bypassCode}
                onChange={(e) => setBypassCode(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                placeholder="Enter bypass code..."
              />
            </div>

            {error && (
              <p className="text-red-600 text-sm">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading || !bypassCode}
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#ED4235] hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#ED4235] disabled:opacity-50"
            >
              {loading ? 'Verifying...' : 'Access System'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};