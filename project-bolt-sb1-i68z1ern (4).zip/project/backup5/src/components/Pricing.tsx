import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Check, Ban, Database, Eye, Lock, Shield, Building2, Users, Truck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { DemoRequest } from './DemoRequest';

export const Pricing: React.FC = () => {
  const { t } = useTranslation();
  const [showDemoRequest, setShowDemoRequest] = useState(false);

  const plans = [
    {
      name: "Pro Solo",
      description: "Perfect for independent professionals",
      price: 20,
      interval: "month",
      features: [
        "Advanced route planning",
        "Custom map creation",
        "Data import/export",
        "Offline access",
        "Basic support",
        "1 user included"
      ],
      cta: "Start Free Trial",
      link: "/signup/personal"
    },
    {
      name: "Pro Team",
      description: "Ideal for small teams",
      price: 100,
      interval: "month",
      features: [
        "All Pro Solo features",
        "Team collaboration",
        "Role-based access",
        "Priority support",
        "Custom branding",
        "Up to 5 users"
      ],
      cta: "Start Free Trial",
      link: "/signup/business",
      highlight: true
    },
    {
      name: "Enterprise",
      description: "For large organizations",
      price: "Custom",
      features: [
        "All Pro Team features",
        "Unlimited users",
        "Custom integration",
        "Dedicated support",
        "SLA guarantees",
        "On-premise option"
      ],
      cta: "Contact Sales",
      link: "#"
    }
  ];

  return (
    <section id="pricing" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Privacy-First Banner */}
        <div className="mb-16 bg-gray-50 rounded-2xl p-8 border border-gray-200">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <Lock className="h-6 w-6 text-[#ED4235] mr-2" />
            Privacy-First and Ad-Free Platform
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="flex items-start space-x-3">
              <Ban className="h-6 w-6 text-[#ED4235] flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-gray-900">No Advertisements</h4>
                <p className="text-gray-600 text-sm">Clean, distraction-free experience across all plans</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Database className="h-6 w-6 text-[#ED4235] flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-gray-900">Your Data is Yours</h4>
                <p className="text-gray-600 text-sm">No data sharing with third parties</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Eye className="h-6 w-6 text-[#ED4235] flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-gray-900">No Tracking</h4>
                <p className="text-gray-600 text-sm">No analytics or social media tracking</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Shield className="h-6 w-6 text-[#ED4235] flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-gray-900">Subscription Only</h4>
                <p className="text-gray-600 text-sm">Transparent pricing, no hidden fees</p>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Choose Your Plan
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            All plans include a 30-day free trial. No credit card required.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-3 lg:gap-8">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`bg-white rounded-lg shadow-lg overflow-hidden ${
                plan.highlight ? 'border-2 border-[#ED4235] ring-2 ring-[#ED4235] ring-opacity-20' : ''
              }`}
            >
              <div className="px-6 py-8">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                  {index === 0 && <Users className="h-8 w-8 text-[#ED4235]" />}
                  {index === 1 && <Building2 className="h-8 w-8 text-[#ED4235]" />}
                  {index === 2 && <Truck className="h-8 w-8 text-[#ED4235]" />}
                </div>
                <p className="mt-4 text-gray-600">{plan.description}</p>
                <p className="mt-8">
                  {typeof plan.price === 'number' ? (
                    <>
                      <span className="text-4xl font-bold text-gray-900">${plan.price}</span>
                      <span className="text-gray-600">/month</span>
                    </>
                  ) : (
                    <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                  )}
                </p>
                <ul className="mt-8 space-y-4">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <Check className="h-5 w-5 text-green-500 mr-3" />
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="px-6 py-4 bg-gray-50">
                {plan.name === 'Enterprise' ? (
                  <button
                    onClick={() => setShowDemoRequest(true)}
                    className="block w-full text-center px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
                  >
                    {plan.cta}
                  </button>
                ) : (
                  <Link
                    to={plan.link}
                    className="block w-full text-center px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
                  >
                    {plan.cta}
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-[#ED4235]/5 via-[#ED4235]/10 to-[#ED4235]/5 rounded-2xl p-8">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <h3 className="text-2xl font-bold text-gray-900">
              Start Your Journey Today
            </h3>
            <p className="text-lg text-gray-600">
              All paid plans include a comprehensive 30-day free trial with full access to all features.
              No credit card required to get started.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-6">
              <div className="flex items-center text-gray-600">
                <Check className="h-5 w-5 text-green-500 mr-2" />
                Full Feature Access
              </div>
              <div className="flex items-center text-gray-600">
                <Check className="h-5 w-5 text-green-500 mr-2" />
                No Credit Card Required
              </div>
              <div className="flex items-center text-gray-600">
                <Check className="h-5 w-5 text-green-500 mr-2" />
                Cancel Anytime
              </div>
            </div>
            <div className="mt-8 pt-6 border-t border-gray-200">
              <p className="text-sm text-gray-500">
                Looking for a custom solution?{' '}
                <button 
                  onClick={() => setShowDemoRequest(true)}
                  className="text-[#ED4235] hover:text-[#ED4235]/90 font-medium"
                >
                  Contact our enterprise sales team
                </button>{' '}
                to discuss your specific requirements.
              </p>
            </div>
          </div>
        </div>
      </div>

      {showDemoRequest && (
        <DemoRequest onClose={() => setShowDemoRequest(false)} />
      )}
    </section>
  );
};