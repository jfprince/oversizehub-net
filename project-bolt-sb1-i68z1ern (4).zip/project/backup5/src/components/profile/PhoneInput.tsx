import React, { useState } from 'react';
import { Phone, Check, AlertCircle } from 'lucide-react';
import { validatePhoneNumber, formatPhoneNumber } from './validation/phoneValidation';

interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

export const PhoneInput: React.FC<PhoneInputProps> = ({ value, onChange, disabled }) => {
  const [error, setError] = useState<string | null>(null);
  const [isValid, setIsValid] = useState(false);

  const handleChange = (newValue: string) => {
    const formattedValue = formatPhoneNumber(newValue);
    const validationError = validatePhoneNumber(formattedValue);
    
    setError(validationError);
    setIsValid(!validationError);
    onChange(formattedValue);
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 flex items-center">
        <Phone className="h-4 w-4 mr-2" />
        Phone Number
      </label>
      <div className="relative mt-1">
        <input
          type="tel"
          value={value}
          onChange={(e) => handleChange(e.target.value)}
          disabled={disabled}
          className={`
            block w-full rounded-md shadow-sm
            ${error 
              ? 'border-red-300 focus:border-red-500 focus:ring-red-500' 
              : 'border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]'}
            ${isValid ? 'pr-10' : ''}
            disabled:bg-gray-50
          `}
        />
        {isValid && (
          <div className="absolute inset-y-0 right-0 flex items-center pr-3">
            <Check className="h-5 w-5 text-green-500" />
          </div>
        )}
      </div>
      {error && (
        <p className="mt-1 text-sm text-red-600 flex items-center">
          <AlertCircle className="h-4 w-4 mr-1" />
          {error}
        </p>
      )}
      {!error && value && (
        <p className="mt-1 text-sm text-gray-500">
          Format: {formatPhoneNumber(value)}
        </p>
      )}
    </div>
  );
};