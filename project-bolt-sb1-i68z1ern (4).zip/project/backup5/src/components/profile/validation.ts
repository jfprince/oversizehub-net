import { z } from 'zod';

export const baseInfoSchema = z.object({
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  username: z.string().min(3, 'Username must be at least 3 characters')
    .regex(/^[a-zA-Z0-9_-]+$/, 'Username can only contain letters, numbers, underscores, and hyphens'),
  email: z.string().email('Invalid email address'),
  phone: z.string().regex(/^\+?[\d\s-()]{10,}$/, 'Invalid phone number'),
  profilePicture: z.string().url().optional()
});

export const professionalInfoSchema = z.object({
  companyName: z.string().min(2, 'Company name must be at least 2 characters'),
  jobTitle: z.string().min(2, 'Job title must be at least 2 characters'),
  companyType: z.string(),
  yearsOfExperience: z.number().min(0).max(100),
  certifications: z.array(z.string())
});

export const contactInfoSchema = z.object({
  headquarters: z.object({
    street: z.string(),
    city: z.string(),
    state: z.string(),
    country: z.string(),
    postalCode: z.string().regex(/^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/, 'Invalid postal code')
  }),
  operatingRegions: z.array(z.string()),
  timeZone: z.string()
});

export const logisticsInfoSchema = z.object({
  fleetDetails: z.object({
    vehicleTypes: z.array(z.string()),
    totalVehicles: z.number().min(0)
  }),
  specialties: z.array(z.string()),
  capacityInfo: z.object({
    maxLength: z.number().min(0),
    maxWidth: z.number().min(0),
    maxHeight: z.number().min(0),
    maxWeight: z.number().min(0)
  }),
  routingExpertise: z.array(z.string())
});

export const validateField = <T>(
  schema: z.ZodType<T>,
  field: keyof T,
  value: any
): string | null => {
  try {
    schema.shape[field].parse(value);
    return null;
  } catch (error) {
    if (error instanceof z.ZodError) {
      return error.errors[0].message;
    }
    return 'Invalid value';
  }
};