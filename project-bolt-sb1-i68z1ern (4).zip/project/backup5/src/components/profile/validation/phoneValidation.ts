import { parsePhoneNumberFromString, isValidPhoneNumber } from 'libphonenumber-js';

export const validatePhoneNumber = (phone: string): string | null => {
  if (!phone) return 'Phone number is required';
  
  try {
    const phoneNumber = parsePhoneNumberFromString(phone);
    if (!phoneNumber) return 'Invalid phone number format';
    if (!isValidPhoneNumber(phone)) return 'Invalid phone number';
    return null;
  } catch (error) {
    return 'Invalid phone number';
  }
};

export const formatPhoneNumber = (phone: string): string => {
  try {
    const phoneNumber = parsePhoneNumberFromString(phone);
    return phoneNumber ? phoneNumber.formatInternational() : phone;
  } catch (error) {
    return phone;
  }
};