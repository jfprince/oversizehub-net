import { z } from 'zod';

export const addressSchema = z.object({
  street: z.string().min(5, 'Street address must be at least 5 characters'),
  city: z.string().min(2, 'City must be at least 2 characters'),
  state: z.string().min(2, 'State/Province must be at least 2 characters'),
  country: z.string().min(2, 'Country must be at least 2 characters'),
  postalCode: z.string()
    .regex(/^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/, 'Invalid postal code format')
});

export const validatePostalCode = (postalCode: string): string | null => {
  const canadianPostalCode = /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/;
  const usZipCode = /^\d{5}(-\d{4})?$/;

  if (!postalCode) return 'Postal code is required';
  if (canadianPostalCode.test(postalCode)) return null;
  if (usZipCode.test(postalCode)) return null;
  
  return 'Invalid postal/ZIP code format';
};

export const validateCity = (city: string): string | null => {
  if (!city) return 'City is required';
  if (city.length < 2) return 'City must be at least 2 characters';
  if (!/^[A-Za-z\s-]+$/.test(city)) return 'City can only contain letters, spaces, and hyphens';
  return null;
};

export const validateState = (state: string): string | null => {
  if (!state) return 'State/Province is required';
  if (state.length < 2) return 'State/Province must be at least 2 characters';
  if (!/^[A-Za-z\s-]+$/.test(state)) return 'State/Province can only contain letters, spaces, and hyphens';
  return null;
};

export const validateCountry = (country: string): string | null => {
  if (!country) return 'Country is required';
  if (country.length < 2) return 'Country must be at least 2 characters';
  if (!/^[A-Za-z\s-]+$/.test(country)) return 'Country can only contain letters, spaces, and hyphens';
  return null;
};