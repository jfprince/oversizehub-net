import { z } from 'zod';

export const emailSchema = z.string().email('Invalid email address');

export const validateEmail = (email: string): string | null => {
  try {
    emailSchema.parse(email);
    return null;
  } catch (error) {
    return 'Invalid email address';
  }
};

export const validateEmailFormat = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validateEmailDomain = (email: string): boolean => {
  const [, domain] = email.split('@');
  if (!domain) return false;
  
  // Common email domains
  const commonDomains = [
    'gmail.com',
    'yahoo.com',
    'hotmail.com',
    'outlook.com',
    'aol.com',
    'icloud.com',
    'protonmail.com'
  ];
  
  return commonDomains.includes(domain.toLowerCase());
};