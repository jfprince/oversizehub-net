import React, { useState } from 'react';
import { Mail, Check, AlertCircle } from 'lucide-react';
import { validateEmail, validateEmailFormat, validateEmailDomain } from './validation/emailValidation';
import { useDebounce } from 'use-debounce';

interface EmailInputProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

export const EmailInput: React.FC<EmailInputProps> = ({ value, onChange, disabled }) => {
  const [error, setError] = useState<string | null>(null);
  const [isValid, setIsValid] = useState(false);
  const [debouncedValue] = useDebounce(value, 500);

  React.useEffect(() => {
    if (debouncedValue) {
      const validationError = validateEmail(debouncedValue);
      setError(validationError);
      setIsValid(!validationError);
    }
  }, [debouncedValue]);

  const handleChange = (newValue: string) => {
    onChange(newValue);
    
    // Real-time format validation
    if (!validateEmailFormat(newValue)) {
      setError('Invalid email format');
      setIsValid(false);
      return;
    }

    // Domain suggestion
    if (validateEmailDomain(newValue)) {
      setError(null);
      setIsValid(true);
    }
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 flex items-center">
        <Mail className="h-4 w-4 mr-2" />
        Email Address
      </label>
      <div className="relative mt-1">
        <input
          type="email"
          value={value}
          onChange={(e) => handleChange(e.target.value)}
          disabled={disabled}
          className={`
            block w-full rounded-md shadow-sm
            ${error 
              ? 'border-red-300 focus:border-red-500 focus:ring-red-500' 
              : 'border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]'}
            ${isValid ? 'pr-10' : ''}
            disabled:bg-gray-50
          `}
        />
        {isValid && (
          <div className="absolute inset-y-0 right-0 flex items-center pr-3">
            <Check className="h-5 w-5 text-green-500" />
          </div>
        )}
      </div>
      {error && (
        <p className="mt-1 text-sm text-red-600 flex items-center">
          <AlertCircle className="h-4 w-4 mr-1" />
          {error}
        </p>
      )}
      {!error && value && !validateEmailDomain(value) && (
        <p className="mt-1 text-sm text-gray-500">
          Common domains: gmail.com, yahoo.com, outlook.com
        </p>
      )}
    </div>
  );
};