import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  Map,
  Truck,
  Users,
  Wifi,
  Shield,
  Navigation,
  Database,
  Mountain,
  Eye,
  Layers,
  FileJson,
  Lock
} from 'lucide-react';

export const Features: React.FC = () => {
  const { t } = useTranslation();

  const features = [
    {
      title: "Advanced Mapping",
      icon: Map,
      description: "Create and customize interactive maps",
      items: [
        { icon: Layers, text: "Custom map creation with multiple layers" },
        { icon: FileJson, text: "Import/export multiple data formats" },
        { icon: Eye, text: "Satellite and street view visualization" },
        { icon: Mountain, text: "Terrain and elevation analysis" }
      ]
    },
    {
      title: "Transport Solutions",
      icon: Truck,
      description: "Specialized tools for transport professionals",
      items: [
        { icon: Navigation, text: "Route optimization for heavy vehicles" },
        { icon: Shield, text: "Height, width, and weight restrictions" },
        { icon: Lock, text: "Compliance with transport regulations" },
        { icon: Database, text: "Comprehensive route database" }
      ]
    },
    {
      title: "Collaboration",
      icon: Users,
      description: "Work seamlessly with your team",
      items: [
        { icon: Users, text: "Real-time team collaboration" },
        { icon: Database, text: "Shared route library" },
        { icon: Shield, text: "Role-based access control" },
        { icon: Lock, text: "Secure data sharing" }
      ]
    }
  ];

  return (
    <section id="features" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Professional Transport Solutions
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Everything you need to plan, manage, and optimize your transport operations
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow"
            >
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <feature.icon className="h-8 w-8 text-[#ED4235]" />
                  <div className="ml-4">
                    <h3 className="text-xl font-bold text-gray-900">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  {feature.items.map((item, itemIndex) => (
                    <div key={itemIndex} className="flex items-center">
                      <item.icon className="h-5 w-5 text-[#ED4235]" />
                      <span className="ml-3 text-gray-600">{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;