import React, { useState } from 'react';
import { Phone, Check } from 'lucide-react';
import { sendPhoneVerification, verifyPhoneCode } from '../../lib/auth';

interface PhoneVerificationProps {
  onVerified: () => void;
  phoneNumber: string;
}

export const PhoneVerification: React.FC<PhoneVerificationProps> = ({ onVerified, phoneNumber }) => {
  const [verificationId, setVerificationId] = useState('');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [codeSent, setCodeSent] = useState(false);

  const handleSendCode = async () => {
    setLoading(true);
    setError('');
    try {
      const id = await sendPhoneVerification(phoneNumber);
      setVerificationId(id);
      setCodeSent(true);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    if (!code || !verificationId) return;

    setLoading(true);
    setError('');
    try {
      await verifyPhoneCode(verificationId, code);
      onVerified();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Phone className="h-5 w-5 text-[#ED4235]" />
        <h3 className="text-lg font-medium">Phone Verification</h3>
      </div>

      {!codeSent ? (
        <div>
          <p className="text-sm text-gray-600 mb-4">
            We'll send a verification code to {phoneNumber}
          </p>
          <button
            onClick={handleSendCode}
            disabled={loading}
            className="w-full px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
          >
            {loading ? 'Sending...' : 'Send Verification Code'}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Enter Verification Code
            </label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              placeholder="Enter 6-digit code"
            />
          </div>

          <button
            onClick={handleVerifyCode}
            disabled={loading || !code}
            className="w-full px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
          >
            {loading ? 'Verifying...' : 'Verify Code'}
          </button>

          <button
            onClick={handleSendCode}
            disabled={loading}
            className="w-full px-4 py-2 border border-[#ED4235] text-[#ED4235] rounded-md hover:bg-red-50"
          >
            Resend Code
          </button>
        </div>
      )}

      {error && (
        <p className="text-red-500 text-sm">{error}</p>
      )}

      {/* Hidden reCAPTCHA container */}
      <div id="recaptcha-container"></div>
    </div>
  );
};