import React, { useState } from 'react';
import { Mail, Check, AlertCircle } from 'lucide-react';
import { resendVerificationEmail } from '../../lib/auth';

interface EmailVerificationProps {
  email: string;
}

export const EmailVerification: React.FC<EmailVerificationProps> = ({ email }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleResendEmail = async () => {
    setLoading(true);
    setError('');
    try {
      await resendVerificationEmail();
      setSuccess(true);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center space-x-2 mb-4">
        <Mail className="h-6 w-6 text-[#ED4235]" />
        <h3 className="text-lg font-medium">Verify Your Email</h3>
      </div>

      <p className="text-gray-600 mb-4">
        We've sent a verification email to <strong>{email}</strong>. Please check your inbox and click the verification link.
      </p>

      {success && (
        <div className="flex items-center space-x-2 text-green-600 mb-4">
          <Check className="h-5 w-5" />
          <span>Verification email sent successfully!</span>
        </div>
      )}

      {error && (
        <div className="flex items-center space-x-2 text-red-600 mb-4">
          <AlertCircle className="h-5 w-5" />
          <span>{error}</span>
        </div>
      )}

      <button
        onClick={handleResendEmail}
        disabled={loading}
        className="w-full px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
      >
        {loading ? 'Sending...' : 'Resend Verification Email'}
      </button>

      <p className="text-sm text-gray-500 mt-4">
        Didn't receive the email? Check your spam folder or click the button above to resend.
      </p>
    </div>
  );
};