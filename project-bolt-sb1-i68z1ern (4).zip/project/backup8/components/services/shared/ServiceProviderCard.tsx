import React from 'react';
import { Star, MapPin, Calendar, Clock, CheckCircle } from 'lucide-react';
import { ServiceProvider } from '../../../types/services';

interface ServiceProviderCardProps {
  provider: ServiceProvider;
  selected: boolean;
  onSelect: () => void;
  onBook: () => void;
}

export const ServiceProviderCard: React.FC<ServiceProviderCardProps> = ({
  provider,
  selected,
  onSelect,
  onBook
}) => {
  return (
    <div className={`bg-white rounded-lg shadow-lg p-6 border-2 transition-all ${
      selected ? 'border-[#ED4235]' : 'border-transparent'
    }`}>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold">{provider.name}</h3>
          <p className="text-gray-600">{provider.company}</p>
          <div className="flex items-center mt-2">
            <Star className="h-5 w-5 text-yellow-400" />
            <span className="ml-1 font-medium">{provider.rating}</span>
            <span className="ml-1 text-gray-500">({provider.reviews} reviews)</span>
          </div>
        </div>
        <label className="flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={selected}
            onChange={onSelect}
            className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
          />
          <span className="ml-2 text-sm text-gray-600">Compare</span>
        </label>
      </div>

      <div className="mt-4">
        <div className="flex items-center text-gray-600">
          <MapPin className="h-4 w-4 mr-2" />
          {provider.regions.join(', ')}
        </div>
        <div className="flex items-center text-gray-600 mt-2">
          <Clock className="h-4 w-4 mr-2" />
          {provider.availability}
        </div>
      </div>

      <div className="mt-4">
        <h4 className="font-medium text-gray-900 mb-2">Services</h4>
        <div className="flex flex-wrap gap-2">
          {provider.services.map((service, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
            >
              {service}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-6 flex justify-end space-x-4">
        <button
          onClick={onBook}
          className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
        >
          <Calendar className="h-4 w-4 mr-2 inline-block" />
          Book Now
        </button>
      </div>
    </div>
  );
};