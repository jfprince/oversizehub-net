import React from 'react';
import { Filter } from 'lucide-react';

interface ServiceProviderFilterProps {
  filters: {
    region: string;
    rating: number;
    services: string[];
    availability: string;
  };
  onFilter: (filters: ServiceProviderFilterProps['filters']) => void;
}

export const ServiceProviderFilter: React.FC<ServiceProviderFilterProps> = ({
  filters,
  onFilter
}) => {
  const regions = [
    'Ontario',
    'Quebec',
    'British Columbia',
    'Alberta',
    'Maritime Provinces',
    'US Northeast',
    'US Midwest',
    'US South',
    'US West'
  ];

  const availabilityOptions = [
    'Available Now',
    'Available Next Week',
    'Available This Month',
    'Contact for Availability'
  ];

  return (
    <div className="relative">
      <button
        className="flex items-center px-4 py-2 border border-gray-300 rounded-md"
        onClick={() => document.getElementById('filter-panel')?.classList.toggle('hidden')}
      >
        <Filter className="h-4 w-4 mr-2" />
        Filters
      </button>

      <div
        id="filter-panel"
        className="hidden absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg p-6 z-10"
      >
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Region</label>
            <select
              value={filters.region}
              onChange={(e) => onFilter({ ...filters, region: e.target.value })}
              className="w-full rounded-md border-gray-300"
            >
              <option value="">All Regions</option>
              {regions.map((region) => (
                <option key={region} value={region}>{region}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Minimum Rating</label>
            <input
              type="range"
              min="0"
              max="5"
              step="0.5"
              value={filters.rating}
              onChange={(e) => onFilter({ ...filters, rating: parseFloat(e.target.value) })}
              className="w-full"
            />
            <div className="text-center mt-1">{filters.rating} stars</div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Availability</label>
            <select
              value={filters.availability}
              onChange={(e) => onFilter({ ...filters, availability: e.target.value })}
              className="w-full rounded-md border-gray-300"
            >
              <option value="">Any Availability</option>
              {availabilityOptions.map((option) => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};