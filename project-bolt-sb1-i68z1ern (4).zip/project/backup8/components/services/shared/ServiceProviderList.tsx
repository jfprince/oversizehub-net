import React, { useState } from 'react';
import { Star, MapPin, Calendar, Filter, Search, Compare, Clock } from 'lucide-react';
import { ServiceProvider } from '../../../types/services';
import { ServiceProviderCard } from './ServiceProviderCard';
import { ServiceProviderFilter } from './ServiceProviderFilter';
import { ServiceProviderCompare } from './ServiceProviderCompare';
import { BookingForm } from './BookingForm';

interface ServiceProviderListProps {
  providers: ServiceProvider[];
  serviceType: string;
}

export const ServiceProviderList: React.FC<ServiceProviderListProps> = ({ providers, serviceType }) => {
  const [filteredProviders, setFilteredProviders] = useState(providers);
  const [selectedProviders, setSelectedProviders] = useState<string[]>([]);
  const [showCompare, setShowCompare] = useState(false);
  const [showBooking, setShowBooking] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<ServiceProvider | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    region: '',
    rating: 0,
    services: [] as string[],
    availability: ''
  });

  const handleFilter = (newFilters: typeof filters) => {
    setFilters(newFilters);
    // Apply filters to providers
    let filtered = providers;
    if (newFilters.region) {
      filtered = filtered.filter(p => p.regions.includes(newFilters.region));
    }
    if (newFilters.rating > 0) {
      filtered = filtered.filter(p => p.rating >= newFilters.rating);
    }
    if (newFilters.services.length > 0) {
      filtered = filtered.filter(p => 
        newFilters.services.every(s => p.services.includes(s))
      );
    }
    if (newFilters.availability) {
      filtered = filtered.filter(p => p.availability === newFilters.availability);
    }
    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.company.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    setFilteredProviders(filtered);
  };

  const handleCompare = () => {
    if (selectedProviders.length < 2) {
      alert('Please select at least 2 providers to compare');
      return;
    }
    setShowCompare(true);
  };

  const handleBook = (provider: ServiceProvider) => {
    setSelectedProvider(provider);
    setShowBooking(true);
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search providers..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  handleFilter(filters);
                }}
                className="pl-10 w-full rounded-md border-gray-300"
              />
            </div>
          </div>
          <ServiceProviderFilter
            filters={filters}
            onFilter={handleFilter}
          />
          {selectedProviders.length > 1 && (
            <button
              onClick={handleCompare}
              className="flex items-center px-4 py-2 bg-[#ED4235] text-white rounded-md"
            >
              <Compare className="h-4 w-4 mr-2" />
              Compare ({selectedProviders.length})
            </button>
          )}
        </div>
      </div>

      {/* Provider List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredProviders.map((provider) => (
          <ServiceProviderCard
            key={provider.id}
            provider={provider}
            selected={selectedProviders.includes(provider.id)}
            onSelect={() => {
              if (selectedProviders.includes(provider.id)) {
                setSelectedProviders(selectedProviders.filter(id => id !== provider.id));
              } else {
                setSelectedProviders([...selectedProviders, provider.id]);
              }
            }}
            onBook={() => handleBook(provider)}
          />
        ))}
      </div>

      {/* Comparison Modal */}
      {showCompare && (
        <ServiceProviderCompare
          providers={providers.filter(p => selectedProviders.includes(p.id))}
          onClose={() => setShowCompare(false)}
        />
      )}

      {/* Booking Modal */}
      {showBooking && selectedProvider && (
        <BookingForm
          provider={selectedProvider}
          serviceType={serviceType}
          onClose={() => {
            setShowBooking(false);
            setSelectedProvider(null);
          }}
        />
      )}
    </div>
  );
};