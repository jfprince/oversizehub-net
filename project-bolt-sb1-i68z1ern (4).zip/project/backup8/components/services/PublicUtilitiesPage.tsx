import React from 'react';
import { Lightbulb, Phone, FileText, Shield, Map, Clock } from 'lucide-react';

export const PublicUtilitiesPage: React.FC = () => {
  const services = [
    {
      title: "Utility Coordination",
      icon: Phone,
      description: "Complete coordination with public utilities for transport",
      features: [
        "Direct utility company liaison",
        "Permit coordination",
        "Schedule management",
        "Documentation handling"
      ]
    },
    {
      title: "Line Lifting Services",
      icon: Map,
      description: "Professional utility line management",
      features: [
        "Height assessment",
        "Coordination with providers",
        "Safety planning",
        "Real-time monitoring"
      ]
    },
    {
      title: "Compliance Management",
      icon: Shield,
      description: "Utility compliance and safety management",
      features: [
        "Regulatory compliance",
        "Safety protocols",
        "Documentation",
        "Risk assessment"
      ]
    },
    {
      title: "Emergency Response",
      icon: Clock,
      description: "24/7 emergency utility coordination",
      features: [
        "Rapid response team",
        "Emergency planning",
        "Utility company coordination",
        "Incident management"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Public Utilities Services
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Professional utility coordination and management for oversized transport
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex items-center mb-6">
                <service.icon className="h-8 w-8 text-[#ED4235]" />
                <h3 className="ml-4 text-xl font-semibold text-gray-900">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <ul className="space-y-3">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-700">
                    <Lightbulb className="h-5 w-5 text-[#ED4235] mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Need Utility Coordination?
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Contact our utility services team for expert assistance with your transport needs.
          </p>
          <button className="px-6 py-3 bg-[#ED4235] text-white rounded-xl hover:bg-opacity-90">
            Request Service
          </button>
        </div>
      </div>
    </div>
  );
};