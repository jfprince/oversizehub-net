import React from 'react';
import { Ruler, FileText, Compass, Wrench, Calculator } from 'lucide-react';

export const TechnicalServicesPage: React.FC = () => {
  const services = [
    {
      title: "Civil Engineering",
      icon: Ruler,
      description: "Professional civil engineering services",
      features: [
        "Bridge inspections",
        "Structural analysis",
        "Load capacity assessment",
        "Engineering reports"
      ]
    },
    {
      title: "Technical Drawings",
      icon: Compass,
      description: "Comprehensive technical drawing services",
      features: [
        "Load plans (LoadX)",
        "Turning radius simulations",
        "Lashing plans",
        "Lifting plans"
      ]
    },
    {
      title: "Traffic Management",
      icon: FileText,
      description: "Professional traffic management planning",
      features: [
        "Traffic Management Plans (TMP)",
        "Route analysis",
        "Signage planning",
        "Coordination with authorities"
      ]
    },
    {
      title: "Engineering Analysis",
      icon: Calculator,
      description: "Detailed engineering analysis services",
      features: [
        "Structural calculations",
        "Load distribution analysis",
        "Stability assessments",
        "Technical documentation"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Technical Services
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Professional engineering and technical solutions
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex items-center mb-6">
                <service.icon className="h-8 w-8 text-[#ED4235]" />
                <h3 className="ml-4 text-xl font-semibold text-gray-900">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <ul className="space-y-3">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-700">
                    <Wrench className="h-5 w-5 text-[#ED4235] mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Need Technical Assistance?
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Contact our engineering team for expert technical support and solutions.
          </p>
          <button className="px-6 py-3 bg-[#ED4235] text-white rounded-xl hover:bg-opacity-90">
            Request Consultation
          </button>
        </div>
      </div>
    </div>
  );
};