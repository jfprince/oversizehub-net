import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown } from 'lucide-react';
import { NavDropdown } from './NavDropdown';
import { NavItemType } from './types';
import { useNavigation } from './hooks/useNavigation';

export const NavItem: React.FC<{ item: NavItemType }> = ({ item }) => {
  const { isOpen, setIsOpen, ref } = useNavigation();

  if (item.disabled) {
    return (
      <div className="px-3 py-2 text-sm font-medium text-gray-400 cursor-not-allowed flex items-center">
        {item.icon && <item.icon className={`${item.label === '' ? 'h-7 w-7' : 'h-4 w-4 mr-2'}`} />}
        {item.label}
      </div>
    );
  }

  if (item.external && item.href) {
    return (
      <a
        href={item.href}
        target="_blank"
        rel="noopener noreferrer"
        className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-[#ED4235] transition-colors rounded-md hover:bg-gray-50 flex items-center"
      >
        {item.icon && <item.icon className={`${item.label === '' ? 'h-7 w-7' : 'h-4 w-4 mr-2'}`} />}
        {item.label}
      </a>
    );
  }

  if (!item.subItems) {
    return (
      <Link
        to={item.link || '#'}
        className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-[#ED4235] transition-colors rounded-md hover:bg-gray-50 flex items-center"
      >
        {item.icon && <item.icon className={`${item.label === '' ? 'h-7 w-7' : 'h-4 w-4 mr-2'}`} />}
        {item.label}
      </Link>
    );
  }

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-[#ED4235] transition-colors rounded-md hover:bg-gray-50 flex items-center"
        aria-expanded={isOpen}
      >
        {item.icon && <item.icon className={`${item.label === '' ? 'h-7 w-7' : 'h-4 w-4 mr-2'}`} />}
        {item.label}
        <ChevronDown className={`ml-1 h-4 w-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <NavDropdown 
          items={item.subItems} 
          onClose={() => setIsOpen(false)} 
        />
      )}
    </div>
  );
};