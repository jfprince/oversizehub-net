import React from 'react';
import { NavItem } from './NavItem';
import { mainNavItems } from './config/mainNavItems';
import { LanguageSelector } from '../LanguageSelector';

export const MainNav: React.FC = () => {
  // Separate home and user navigation items
  const homeItem = mainNavItems.find(item => item.id === 'home');
  const regularItems = mainNavItems.filter(item => item.id !== 'home');

  return (
    <nav className="flex items-center justify-end space-x-4">
      {/* Regular menu items */}
      {regularItems.map((item) => (
        <NavItem key={item.id} item={item} />
      ))}
      
      {/* Language selector with smaller size */}
      <div className="scale-90">
        <LanguageSelector />
      </div>

      {/* Home icon at the end */}
      {homeItem && <NavItem item={homeItem} />}
    </nav>
  );
};