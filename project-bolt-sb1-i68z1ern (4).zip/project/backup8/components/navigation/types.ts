import { LucideIcon } from 'lucide-react';

export interface NavSubItemType {
  id: string;
  label: string;
  link?: string;
  href?: string;
  icon?: LucideIcon;
  disabled?: boolean;
  external?: boolean;
  subItems?: NavSubItemType[];
}

export interface NavItemType {
  id: string;
  label: string;
  link?: string;
  href?: string;
  icon: LucideIcon;
  subItems?: NavSubItemType[];
  disabled?: boolean;
  external?: boolean;
}

export interface FooterItem {
  label: string;
  href: string;
  external?: boolean;
  disabled?: boolean;
}

export interface FooterSection {
  title: string;
  icon: LucideIcon;
  items: FooterItem[];
}