import {
  Home,
  Map,
  Navigation,
  FileText,
  Shield,
  Truck,
  Globe,
  DollarSign,
  Building2,
  HelpCircle,
  Mail,
  BookOpen,
  Newspaper,
  Phone,
  MapPin,
  Ruler,
  CompassIcon,
  Calculator,
  Laptop,
  HandshakeIcon,
  Users,
  MessageSquare,
  HeadphonesIcon,
  Zap,
  Route,
  Train,
  Ship,
  Cloud,
  Wrench,
  Car,
  FileCheck,
  Scale,
  Anchor,
  Lightbulb,
  GraduationCap,
  Briefcase,
  Download,
  Building,
  Info,
  Bell,
  LinkedinIcon,
  FacebookIcon,
  YoutubeIcon
} from 'lucide-react';
import { NavItemType } from '../types';

export const mainNavItems: NavItemType[] = [
  {
    id: 'home',
    label: '',
    link: '/',
    icon: Home
  },
  {
    id: 'interactive-map',
    label: 'Interactive Map',
    icon: Map,
    subItems: [
      { id: 'advanced-mapping', label: 'Advanced Mapping Software', link: '/map', icon: CompassIcon },
      { id: 'route-planning', label: 'Route Planning', link: '/map', icon: Navigation },
      { id: 'truck-route', label: 'Truck Route Map', icon: Truck, disabled: true },
      { id: 'railways-map', label: 'Railways Map', icon: Train, disabled: true },
      { id: 'barge-map', label: 'Barge Map', icon: Ship, disabled: true },
      { id: 'real-time-data', label: 'Real-Time Data', icon: Cloud, disabled: true }
    ]
  },
  {
    id: 'services',
    label: 'Services',
    icon: Wrench,
    subItems: [
      { id: 'road-survey', label: 'Road Survey', link: '/services/road-survey', icon: Ruler },
      { id: 'desktop-survey', label: 'Desktop Survey', link: '/services/desktop-survey', icon: Laptop },
      { id: 'escort-services', label: 'Escort Services', link: '/services/escort', icon: Shield },
      { id: 'permit-management', label: 'Permit Management', link: '/services/permit-management', icon: FileCheck },
      { id: 'border-crossing', label: 'Border Crossing', link: '/services/border', icon: Globe },
      { id: 'trucking-quote', label: 'GET Trucking Quote', link: '/services/quote', icon: Calculator },
      { id: 'compliance', label: 'Compliance Requirements', link: '/services/compliance', icon: Scale },
      { id: 'safety', label: 'Safety Regulations', link: '/services/safety', icon: Shield },
      { id: 'team-collaboration', label: 'Team Collaboration', link: '/services/collaboration', icon: Users },
      { id: 'rail-services', label: 'Rail Services', link: '/services/rail', icon: Train },
      { id: 'barge-services', label: 'Barge Services', link: '/services/barge', icon: Anchor },
      { id: 'utilities', label: 'Public Utilities Services', link: '/services/utilities', icon: Lightbulb },
      { id: 'technical', label: 'Technical Services', link: '/services/technical', icon: Wrench },
      { id: 'logistics', label: 'Logistics Trade Center', icon: Building, disabled: true },
      { id: 'impact', label: 'Impact Recorder Services', icon: Zap, disabled: true },
      { id: 'lashing', label: 'Lashing / Welding Services', icon: Wrench, disabled: true },
      { id: 'jack', label: 'Jack & Slides', icon: Wrench, disabled: true }
    ]
  },
  {
    id: 'training',
    label: 'Training',
    icon: GraduationCap,
    subItems: [
      { id: 'platform', label: 'Training Platform', icon: Laptop, disabled: true },
      { id: 'tutorials', label: 'Tutorials & Videos', icon: FileText, disabled: true },
      { id: 'brake-check', label: 'Brake Check', icon: Car, disabled: true }
    ]
  },
  {
    id: 'resources',
    label: 'Resources',
    icon: HelpCircle,
    subItems: [
      { id: 'emergency', label: 'Emergency Procedures', icon: Bell, disabled: true },
      { id: 'simulators', label: 'Cost Simulators', icon: Calculator, disabled: true },
      { id: 'equipment', label: 'Equipment Rental', icon: Truck, disabled: true },
      { id: 'rebates', label: 'Rebate Programs', icon: DollarSign, disabled: true },
      { id: 'port-info', label: 'Port Information', icon: Anchor, disabled: true },
      { id: 'border-info', label: 'Border Information', icon: Globe, disabled: true },
      { id: 'drug-test', label: 'Drug Testing', icon: FileText, disabled: true },
      { id: 'documents', label: 'Document Center', icon: FileText, disabled: true },
      { id: 'downloads', label: 'Downloads', icon: Download, disabled: true },
      { id: 'bridge-info', label: 'Bridge Information', icon: Building, disabled: true },
      { id: 'road-ban', label: 'Road Ban Info', icon: Shield, disabled: true },
      { id: 'loadx', label: 'LoadX Software', icon: FileText, disabled: true },
      { id: 'directory', label: 'Partner Directory', icon: Users, disabled: true },
      { id: 'find-partner', label: 'Find a Partner', link: '/partners/find', icon: Users },
      { id: 'become-partner', label: 'Become a Partner', link: '/partners/join', icon: HandshakeIcon },
      { id: 'jobs', label: 'Job Opportunities', icon: Briefcase, disabled: true },
      { id: 'authorities', label: 'Regulatory Authorities', icon: Shield, disabled: true },
      { id: 'news', label: 'Industry News', icon: Newspaper, disabled: true },
      { id: 'case-studies', label: 'Case Studies', icon: BookOpen, disabled: true },
      { id: 'faqs', label: 'FAQs', link: '/resources/faqs', icon: MessageSquare },
      { id: 'blog', label: 'Blog', icon: FileText, disabled: true },
      { id: 'support', label: 'Support', link: '/resources/support', icon: HeadphonesIcon }
    ]
  },
  {
    id: 'about',
    label: 'About',
    icon: Info,
    subItems: [
      { id: 'updates', label: 'Stay Updated', icon: Bell, disabled: true },
      { id: 'team', label: 'Our Team', icon: Users, disabled: true },
      { id: 'partners', label: 'Strategic Partners', icon: HandshakeIcon, disabled: true },
      { id: 'contact', label: 'Contact Us', link: '/contact', icon: Mail },
      { id: 'linkedin', label: 'LinkedIn', href: 'https://linkedin.com', icon: LinkedinIcon, external: true },
      { id: 'facebook', label: 'Facebook', href: 'https://facebook.com', icon: FacebookIcon, external: true },
      { id: 'youtube', label: 'YouTube', href: 'https://youtube.com', icon: YoutubeIcon, external: true }
    ]
  }
];