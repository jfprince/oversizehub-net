import {
  Building2,
  Users,
  Shield,
  Navigation,
  Map,
  FileText,
  Truck,
  Globe,
  BookOpen,
  Newspaper,
  Phone,
  Mail,
  Linkedin,
  Twitter,
  HandshakeIcon,
  GraduationCap,
  Heart,
  Contact
} from 'lucide-react';
import { FooterSection } from '../types';

export const footerItems: FooterSection[] = [
  // ... existing sections ...
  {
    title: 'Contact',
    icon: Mail,
    items: [
      { label: 'Contact Us', href: '/contact' },
      { label: 'Support', href: '/resources/support' },
      { label: 'info@oversizehub.net', href: 'mailto:info@oversizehub.net', external: true },
      { label: '+1 (514) 555-0123', href: 'tel:+15145550123', external: true },
      { label: 'LinkedIn', href: 'https://linkedin.com/company/oversizehub', external: true },
      { label: 'Twitter', href: 'https://twitter.com/oversizehub', external: true }
    ]
  }
];