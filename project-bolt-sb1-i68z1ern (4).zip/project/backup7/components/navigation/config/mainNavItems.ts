import {
  Home,
  Map,
  Navigation,
  FileText,
  Shield,
  Truck,
  Globe,
  DollarSign,
  Building2,
  HelpCircle,
  Mail,
  BookOpen,
  Newspaper,
  Phone,
  MapPin,
  Ruler,
  Compass,
  Calculator,
  Laptop,
  HandshakeIcon,
  Users,
  MessageSquare,
  HeadphonesIcon,
  Zap,
  Route
} from 'lucide-react';
import { NavItemType } from '../types';

export const mainNavItems: NavItemType[] = [
  {
    id: 'home',
    label: 'Home',
    link: '/',
    icon: Home
  },
  {
    id: 'map',
    label: 'Map',
    link: '/map',
    icon: Map
  },
  {
    id: 'features',
    label: 'Features & Services',
    icon: Shield,
    subItems: [
      { 
        id: 'advanced-mapping', 
        label: 'Advanced Mapping', 
        link: '/features/advanced-mapping', 
        icon: Compass 
      },
      { 
        id: 'route-planning', 
        label: 'Route Planning', 
        link: '/features/route-planning', 
        icon: Navigation 
      },
      { 
        id: 'road-survey', 
        label: 'Road Survey', 
        link: '/services/road-survey', 
        icon: Ruler 
      },
      { 
        id: 'desktop-survey', 
        label: 'Desktop Survey', 
        link: '/services/desktop-survey', 
        icon: Laptop 
      },
      { 
        id: 'trucking-quote', 
        label: 'Get Trucking Quote', 
        link: '/services/trucking-quote', 
        icon: Calculator 
      },
      { 
        id: 'permit-management', 
        label: 'Permit Management', 
        link: '/services/permits', 
        icon: FileText 
      },
      { 
        id: 'escort-services', 
        label: 'Escort Services', 
        link: '/services/escort', 
        icon: Shield 
      },
      { 
        id: 'border-crossing', 
        label: 'Border Crossing', 
        link: '/services/border', 
        icon: Globe 
      },
      { 
        id: 'compliance', 
        label: 'Compliance Requirements', 
        link: '/features/compliance', 
        icon: Shield 
      },
      { 
        id: 'safety', 
        label: 'Safety Regulations', 
        link: '/features/safety', 
        icon: Shield 
      },
      { 
        id: 'team-collaboration', 
        label: 'Team Collaboration', 
        link: '/features/team-collaboration', 
        icon: Users 
      }
    ]
  },
  {
    id: 'pricing',
    label: 'Pricing',
    link: '/pricing',
    icon: DollarSign
  },
  {
    id: 'resources',
    label: 'Resources',
    icon: HelpCircle,
    subItems: [
      { 
        id: 'documentation', 
        label: 'Documentation', 
        icon: FileText, 
        disabled: true 
      },
      { 
        id: 'industry-news', 
        label: 'Industry News', 
        icon: Newspaper, 
        disabled: true 
      },
      { 
        id: 'case-studies', 
        label: 'Case Studies', 
        icon: BookOpen, 
        disabled: true 
      },
      { 
        id: 'regulations', 
        label: 'Regulations', 
        icon: Shield, 
        disabled: true 
      },
      { 
        id: 'faqs', 
        label: 'FAQs', 
        link: '/resources/faqs', 
        icon: MessageSquare 
      },
      { 
        id: 'blog', 
        label: 'Blog', 
        icon: FileText, 
        disabled: true 
      },
      { 
        id: 'support', 
        label: 'Support', 
        link: '/resources/support', 
        icon: HeadphonesIcon 
      },
      { 
        id: 'contact', 
        label: 'Contact Us', 
        icon: Mail, 
        disabled: true 
      },
      {
        id: 'find-partner',
        label: 'Find a Partner',
        link: '/partners/find',
        icon: Users
      },
      {
        id: 'become-partner',
        label: 'Become a Partner',
        link: '/partners/join',
        icon: HandshakeIcon
      }
    ]
  }
];