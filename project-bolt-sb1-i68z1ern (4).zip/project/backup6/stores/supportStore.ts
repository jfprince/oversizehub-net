import { create } from 'zustand';
import { nanoid } from 'nanoid';
import { SupportTicket, TicketMessage, TicketFilters } from '../types/support';

interface SupportState {
  tickets: SupportTicket[];
  activeTicket: SupportTicket | null;
  filters: TicketFilters;
  setActiveTicket: (ticket: SupportTicket | null) => void;
  createTicket: (ticket: Omit<SupportTicket, 'id' | 'createdAt' | 'updatedAt' | 'messages'>) => void;
  updateTicket: (ticketId: string, updates: Partial<SupportTicket>) => void;
  addMessage: (message: Omit<TicketMessage, 'id' | 'createdAt'>) => void;
  setFilters: (filters: TicketFilters) => void;
}

export const useSupportStore = create<SupportState>((set) => ({
  tickets: [],
  activeTicket: null,
  filters: {},
  setActiveTicket: (ticket) => set({ activeTicket: ticket }),
  createTicket: (ticket) => set((state) => ({
    tickets: [
      ...state.tickets,
      {
        ...ticket,
        id: nanoid(),
        createdAt: new Date(),
        updatedAt: new Date(),
        messages: []
      }
    ]
  })),
  updateTicket: (ticketId, updates) => set((state) => ({
    tickets: state.tickets.map((ticket) =>
      ticket.id === ticketId
        ? { ...ticket, ...updates, updatedAt: new Date() }
        : ticket
    )
  })),
  addMessage: (message) => set((state) => {
    if (!state.activeTicket) return state;
    
    const newMessage = {
      ...message,
      id: nanoid(),
      createdAt: new Date()
    };

    return {
      tickets: state.tickets.map((ticket) =>
        ticket.id === message.ticketId
          ? {
              ...ticket,
              messages: [...ticket.messages, newMessage],
              updatedAt: new Date()
            }
          : ticket
      )
    };
  }),
  setFilters: (filters) => set({ filters })
}));