export type TicketStatus = 'open' | 'in-progress' | 'resolved' | 'closed';
export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TicketCategory = 
  | 'technical' 
  | 'billing' 
  | 'account' 
  | 'route-planning'
  | 'compliance'
  | 'survey'
  | 'other';

export interface SupportTicket {
  id: string;
  userId: string;
  title: string;
  description: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  attachments?: string[];
  createdAt: Date;
  updatedAt: Date;
  assignedTo?: string;
  messages: TicketMessage[];
}

export interface TicketMessage {
  id: string;
  ticketId: string;
  userId: string;
  content: string;
  attachments?: string[];
  createdAt: Date;
  isStaff: boolean;
}

export interface TicketFilters {
  status?: TicketStatus;
  priority?: TicketPriority;
  category?: TicketCategory;
  dateRange?: {
    start: Date;
    end: Date;
  };
}