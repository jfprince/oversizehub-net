import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Navigation, 
  Settings, 
  List, 
  Database, 
  Menu as MenuIcon,
  X,
  Map,
  Upload,
  ChevronRight,
  Compass,
  Ruler
} from 'lucide-react';
import { RoutePlanner } from './tabs/RoutePlanner';
import { MapSettings } from './tabs/MapSettings';
import { ItemManager } from './tabs/ItemManager';
import { MapManagement } from './tabs/MapManagement';
import { DataManagement } from './tabs/DataManagement';
import { AdvancedMapping } from './tabs/AdvancedMapping';
import { RoadSurvey } from './tabs/RoadSurvey';

interface MapTabsProps {
  initialMode?: string;
}

const menuItems = [
  { id: 'route', label: 'Route Planner', icon: Navigation, component: RoutePlanner },
  { id: 'advanced', label: 'Advanced Mapping', icon: Compass, component: AdvancedMapping },
  { id: 'survey', label: 'Road Survey', icon: Ruler, component: RoadSurvey },
  { id: 'settings', label: 'Settings', icon: Settings, component: MapSettings },
  { id: 'items', label: 'Items', icon: List, component: ItemManager },
  { id: 'map', label: 'Map Management', icon: Map, component: MapManagement },
  { id: 'data', label: 'Data Management', icon: Upload, component: DataManagement }
];

export const MapTabs: React.FC<MapTabsProps> = ({ initialMode = 'route' }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [activeItem, setActiveItem] = useState(initialMode);
  const navigate = useNavigate();

  useEffect(() => {
    if (initialMode) {
      setActiveItem(initialMode);
    }
  }, [initialMode]);

  const handleTabChange = (id: string) => {
    setActiveItem(id);
    navigate(`/map?mode=${id}`);
  };

  const ActiveComponent = menuItems.find(item => item.id === activeItem)?.component || RoutePlanner;

  return (
    <>
      {/* Hamburger Menu Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="absolute left-4 top-4 z-20 bg-white p-2 rounded-lg shadow-lg hover:bg-gray-50"
        aria-label={isOpen ? 'Close menu' : 'Open menu'}
      >
        {isOpen ? (
          <X className="h-6 w-6 text-gray-600" />
        ) : (
          <MenuIcon className="h-6 w-6 text-gray-600" />
        )}
      </button>

      {/* Slide-out Menu */}
      <div 
        className={`fixed inset-y-0 left-0 w-[400px] bg-white shadow-xl transform transition-transform duration-300 ease-in-out z-30 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Menu Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Map Tools</h2>
          <button
            onClick={() => setIsOpen(false)}
            className="p-2 rounded-lg hover:bg-gray-100"
            aria-label="Close menu"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        {/* Menu Items */}
        <div className="flex h-full">
          <div className="w-16 bg-gray-50 border-r border-gray-200 py-4">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleTabChange(item.id)}
                className={`w-full p-3 flex flex-col items-center justify-center space-y-1 ${
                  activeItem === item.id
                    ? 'text-[#ED4235] bg-white border-r-2 border-[#ED4235]'
                    : 'text-gray-600 hover:text-[#ED4235] hover:bg-gray-100'
                }`}
                title={item.label}
              >
                <item.icon className="h-6 w-6" />
                <span className="text-xs">{item.label.split(' ')[0]}</span>
              </button>
            ))}
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto">
            <div className="p-6">
              <ActiveComponent />
            </div>
          </div>
        </div>
      </div>

      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-25 z-20 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
};