import React from 'react';
import { MapPin } from 'lucide-react';
import { AddressSearch } from '../../../map/AddressSearch';

interface RouteInfoProps {
  value: {
    origin: string;
    destination: string;
  };
  onChange: (value: any) => void;
}

export const RouteInfo: React.FC<RouteInfoProps> = ({ value, onChange }) => {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Route Information</h3>
      <p className="text-sm text-gray-500">
        Enter the origin and destination points for your route
      </p>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Origin</label>
          <AddressSearch
            value={value.origin}
            onChange={(newValue) => onChange({ ...value, origin: newValue })}
            placeholder="Enter origin location"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Destination</label>
          <AddressSearch
            value={value.destination}
            onChange={(newValue) => onChange({ ...value, destination: newValue })}
            placeholder="Enter destination location"
          />
        </div>
      </div>
    </div>
  );
};