import React from 'react';
import { Calendar, Globe } from 'lucide-react';

interface ScheduleInfoProps {
  value: {
    departureDate: string;
    dateNeeded: string;
    authority: string;
  };
  onChange: (value: any) => void;
}

export const ScheduleInfo: React.FC<ScheduleInfoProps> = ({ value, onChange }) => {
  const authorities = [
    'Ontario MTO',
    'Quebec MTQ',
    'British Columbia MOT',
    'Alberta Transportation',
    'New York DOT',
    'Michigan DOT',
    'Other'
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Schedule & Authority</h3>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Date of Departure</label>
          <input
            type="date"
            value={value.departureDate}
            onChange={(e) => onChange({ ...value, departureDate: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Date Needed By</label>
          <input
            type="date"
            value={value.dateNeeded}
            onChange={(e) => onChange({ ...value, dateNeeded: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Authority Required For</label>
        <select
          value={value.authority}
          onChange={(e) => onChange({ ...value, authority: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="">Select authority</option>
          {authorities.map((authority) => (
            <option key={authority} value={authority}>{authority}</option>
          ))}
        </select>
      </div>
    </div>
  );
};