import React from 'react';
import { Package, Scale } from 'lucide-react';

interface LoadInfoProps {
  value: {
    loadDimensions: {
      length: string;
      width: string;
      height: string;
      weight: string;
    };
    overallDimensions: {
      length: string;
      width: string;
      height: string;
      weight: string;
    };
    loadType: string;
  };
  onChange: (value: any) => void;
}

export const LoadInfo: React.FC<LoadInfoProps> = ({ value, onChange }) => {
  const loadTypes = [
    'Wind Turbine',
    'Heavy Equipment',
    'Construction Materials',
    'Industrial Machinery',
    'Modular Building',
    'Bridge Beam',
    'Other'
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Load Information</h3>

      {/* Load Dimensions */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-3">Load Dimensions</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
            <input
              type="number"
              value={value.loadDimensions.length}
              onChange={(e) => onChange({
                ...value,
                loadDimensions: { ...value.loadDimensions, length: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
            <input
              type="number"
              value={value.loadDimensions.width}
              onChange={(e) => onChange({
                ...value,
                loadDimensions: { ...value.loadDimensions, width: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
            <input
              type="number"
              value={value.loadDimensions.height}
              onChange={(e) => onChange({
                ...value,
                loadDimensions: { ...value.loadDimensions, height: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
            <input
              type="number"
              value={value.loadDimensions.weight}
              onChange={(e) => onChange({
                ...value,
                loadDimensions: { ...value.loadDimensions, weight: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
        </div>
      </div>

      {/* Overall Dimensions */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-3">Overall Dimensions (Including Truck)</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
            <input
              type="number"
              value={value.overallDimensions.length}
              onChange={(e) => onChange({
                ...value,
                overallDimensions: { ...value.overallDimensions, length: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
            <input
              type="number"
              value={value.overallDimensions.width}
              onChange={(e) => onChange({
                ...value,
                overallDimensions: { ...value.overallDimensions, width: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
            <input
              type="number"
              value={value.overallDimensions.height}
              onChange={(e) => onChange({
                ...value,
                overallDimensions: { ...value.overallDimensions, height: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
            <input
              type="number"
              value={value.overallDimensions.weight}
              onChange={(e) => onChange({
                ...value,
                overallDimensions: { ...value.overallDimensions, weight: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
        </div>
      </div>

      {/* Load Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700">Type of Load</label>
        <select
          value={value.loadType}
          onChange={(e) => onChange({ ...value, loadType: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="">Select load type</option>
          {loadTypes.map((type) => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>
    </div>
  );
};