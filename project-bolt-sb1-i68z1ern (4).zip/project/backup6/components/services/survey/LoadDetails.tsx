import React from 'react';
import { Truck, Package, Scale, Calendar } from 'lucide-react';

interface LoadDetailsProps {
  value: {
    origin: string;
    destination: string;
    loadDimensions: {
      length: string;
      width: string;
      height: string;
      weight: string;
    };
    overallDimensions: {
      length: string;
      width: string;
      height: string;
      weight: string;
    };
    loadType: string;
    departureDate: string;
    authority: string;
    dateNeeded: string;
    equipment: string[];
  };
  onChange: (value: any) => void;
}

export const LoadDetails: React.FC<LoadDetailsProps> = ({ value, onChange }) => {
  const loadTypes = [
    'Wind Turbine',
    'Heavy Equipment',
    'Construction Materials',
    'Industrial Machinery',
    'Modular Building',
    'Bridge Beam',
    'Other'
  ];

  const authorities = [
    'Ontario MTO',
    'Quebec MTQ',
    'British Columbia MOT',
    'Alberta Transportation',
    'New York DOT',
    'Michigan DOT',
    'Other'
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Load Details</h3>
      <p className="text-sm text-gray-500">
        Enter the dimensions and requirements for your load
      </p>

      {/* Load Dimensions */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-3">Load Dimensions</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
            <input
              type="number"
              value={value.loadDimensions.length}
              onChange={(e) => onChange({
                ...value,
                loadDimensions: { ...value.loadDimensions, length: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
            <input
              type="number"
              value={value.loadDimensions.width}
              onChange={(e) => onChange({
                ...value,
                loadDimensions: { ...value.loadDimensions, width: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
            <input
              type="number"
              value={value.loadDimensions.height}
              onChange={(e) => onChange({
                ...value,
                loadDimensions: { ...value.loadDimensions, height: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
            <input
              type="number"
              value={value.loadDimensions.weight}
              onChange={(e) => onChange({
                ...value,
                loadDimensions: { ...value.loadDimensions, weight: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
        </div>
      </div>

      {/* Overall Dimensions */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-3">Overall Dimensions (Including Truck)</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
            <input
              type="number"
              value={value.overallDimensions.length}
              onChange={(e) => onChange({
                ...value,
                overallDimensions: { ...value.overallDimensions, length: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
            <input
              type="number"
              value={value.overallDimensions.width}
              onChange={(e) => onChange({
                ...value,
                overallDimensions: { ...value.overallDimensions, width: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
            <input
              type="number"
              value={value.overallDimensions.height}
              onChange={(e) => onChange({
                ...value,
                overallDimensions: { ...value.overallDimensions, height: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
            <input
              type="number"
              value={value.overallDimensions.weight}
              onChange={(e) => onChange({
                ...value,
                overallDimensions: { ...value.overallDimensions, weight: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
        </div>
      </div>

      {/* Load Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700">Type of Load</label>
        <select
          value={value.loadType}
          onChange={(e) => onChange({ ...value, loadType: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="">Select load type</option>
          {loadTypes.map((type) => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>

      {/* Dates */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Date of Departure</label>
          <input
            type="date"
            value={value.departureDate}
            onChange={(e) => onChange({ ...value, departureDate: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Date Needed By</label>
          <input
            type="date"
            value={value.dateNeeded}
            onChange={(e) => onChange({ ...value, dateNeeded: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
      </div>

      {/* Authority */}
      <div>
        <label className="block text-sm font-medium text-gray-700">Authority Required For</label>
        <select
          value={value.authority}
          onChange={(e) => onChange({ ...value, authority: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="">Select authority</option>
          {authorities.map((authority) => (
            <option key={authority} value={authority}>{authority}</option>
          ))}
        </select>
      </div>
    </div>
  );
};