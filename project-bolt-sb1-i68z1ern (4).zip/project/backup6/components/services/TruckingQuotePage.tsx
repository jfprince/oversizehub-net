import React, { useState } from 'react';
import { 
  Truck, 
  Calendar, 
  MapPin, 
  Package,
  DollarSign,
  Clock,
  FileText,
  Send
} from 'lucide-react';
import { AddressSearch } from '../map/AddressSearch';

interface QuoteFormData {
  origin: string;
  destination: string;
  pickupDate: string;
  deliveryDate: string;
  loadType: string;
  dimensions: {
    length: string;
    width: string;
    height: string;
    weight: string;
  };
  specialRequirements: string[];
  contactInfo: {
    name: string;
    email: string;
    phone: string;
    company: string;
  };
}

export const TruckingQuotePage: React.FC = () => {
  const [formData, setFormData] = useState<QuoteFormData>({
    origin: '',
    destination: '',
    pickupDate: '',
    deliveryDate: '',
    loadType: '',
    dimensions: {
      length: '',
      width: '',
      height: '',
      weight: ''
    },
    specialRequirements: [],
    contactInfo: {
      name: '',
      email: '',
      phone: '',
      company: ''
    }
  });

  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Here you would send the quote request to your backend
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Quote request submitted successfully!');
    } catch (error) {
      console.error('Error submitting quote:', error);
      alert('Failed to submit quote request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const loadTypes = [
    'General Freight',
    'Heavy Equipment',
    'Construction Materials',
    'Industrial Machinery',
    'Wind Energy Components',
    'Modular Buildings',
    'Other'
  ];

  const specialRequirements = [
    'Pilot Car',
    'Police Escort',
    'Route Survey',
    'Permits Required',
    'Weekend Delivery',
    'Team Drivers',
    'Lift Gate',
    'Inside Delivery'
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900">
            Get Your Trucking Quote
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Fast, reliable quotes for your oversized and heavy haul needs
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-8">
            <div className="mb-8 flex justify-between">
              {[1, 2, 3].map((stepNumber) => (
                <div
                  key={stepNumber}
                  className={`flex items-center ${
                    stepNumber < step
                      ? 'text-[#ED4235]'
                      : stepNumber === step
                      ? 'text-[#ED4235]'
                      : 'text-gray-300'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      stepNumber <= step ? 'bg-[#ED4235] text-white' : 'bg-gray-100'
                    }`}
                  >
                    {stepNumber}
                  </div>
                  <span className="ml-2 text-sm font-medium">
                    {stepNumber === 1 ? 'Route Details' : 
                     stepNumber === 2 ? 'Load Information' : 
                     'Contact Details'}
                  </span>
                </div>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
              {step === 1 && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Origin</label>
                    <AddressSearch
                      value={formData.origin}
                      onChange={(value) => setFormData({ ...formData, origin: value })}
                      placeholder="Enter pickup location"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">Destination</label>
                    <AddressSearch
                      value={formData.destination}
                      onChange={(value) => setFormData({ ...formData, destination: value })}
                      placeholder="Enter delivery location"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Pickup Date</label>
                      <input
                        type="date"
                        value={formData.pickupDate}
                        onChange={(e) => setFormData({ ...formData, pickupDate: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Delivery Date</label>
                      <input
                        type="date"
                        value={formData.deliveryDate}
                        onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Load Type</label>
                    <select
                      value={formData.loadType}
                      onChange={(e) => setFormData({ ...formData, loadType: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                    >
                      <option value="">Select load type</option>
                      {loadTypes.map((type) => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
                      <input
                        type="number"
                        value={formData.dimensions.length}
                        onChange={(e) => setFormData({
                          ...formData,
                          dimensions: { ...formData.dimensions, length: e.target.value }
                        })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
                      <input
                        type="number"
                        value={formData.dimensions.width}
                        onChange={(e) => setFormData({
                          ...formData,
                          dimensions: { ...formData.dimensions, width: e.target.value }
                        })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
                      <input
                        type="number"
                        value={formData.dimensions.height}
                        onChange={(e) => setFormData({
                          ...formData,
                          dimensions: { ...formData.dimensions, height: e.target.value }
                        })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
                      <input
                        type="number"
                        value={formData.dimensions.weight}
                        onChange={(e) => setFormData({
                          ...formData,
                          dimensions: { ...formData.dimensions, weight: e.target.value }
                        })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Special Requirements
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {specialRequirements.map((req) => (
                        <label key={req} className="flex items-center">
                          <input
                            type="checkbox"
                            checked={formData.specialRequirements.includes(req)}
                            onChange={(e) => {
                              const newReqs = e.target.checked
                                ? [...formData.specialRequirements, req]
                                : formData.specialRequirements.filter(r => r !== req);
                              setFormData({ ...formData, specialRequirements: newReqs });
                            }}
                            className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
                          />
                          <span className="ml-2 text-sm text-gray-700">{req}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Full Name</label>
                      <input
                        type="text"
                        value={formData.contactInfo.name}
                        onChange={(e) => setFormData({
                          ...formData,
                          contactInfo: { ...formData.contactInfo, name: e.target.value }
                        })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Company Name</label>
                      <input
                        type="text"
                        value={formData.contactInfo.company}
                        onChange={(e) => setFormData({
                          ...formData,
                          contactInfo: { ...formData.contactInfo, company: e.target.value }
                        })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Email</label>
                      <input
                        type="email"
                        value={formData.contactInfo.email}
                        onChange={(e) => setFormData({
                          ...formData,
                          contactInfo: { ...formData.contactInfo, email: e.target.value }
                        })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Phone</label>
                      <input
                        type="tel"
                        value={formData.contactInfo.phone}
                        onChange={(e) => setFormData({
                          ...formData,
                          contactInfo: { ...formData.contactInfo, phone: e.target.value }
                        })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-between pt-6">
                {step > 1 && (
                  <button
                    type="button"
                    onClick={() => setStep(step - 1)}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Back
                  </button>
                )}
                {step < 3 ? (
                  <button
                    type="button"
                    onClick={() => setStep(step + 1)}
                    className="ml-auto px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
                  >
                    Next
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="ml-auto px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50 flex items-center"
                  >
                    {isSubmitting ? (
                      <>
                        <Clock className="animate-spin h-5 w-5 mr-2" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Send className="h-5 w-5 mr-2" />
                        Get Quote
                      </>
                    )}
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};