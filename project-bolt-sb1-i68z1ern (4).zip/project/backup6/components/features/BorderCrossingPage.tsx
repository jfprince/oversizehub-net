import React, { useState } from 'react';
import { 
  Globe, 
  FileText, 
  AlertTriangle, 
  Clock,
  Calendar,
  Truck,
  MapPin,
  Search,
  ChevronDown,
  CheckCircle,
  XCircle
} from 'lucide-react';

export const BorderCrossingPage: React.FC = () => {
  const [selectedCrossing, setSelectedCrossing] = useState<string | null>(null);

  const crossings = [
    {
      id: 'BC1',
      name: 'Windsor-Detroit',
      status: 'open',
      waitTime: '45 mins',
      restrictions: ['No hazmat', 'Height limit: 4.5m'],
      services: ['Customs broker', '24/7 operations', 'Oversize permits'],
      coordinates: '42.3149° N, 83.0364° W'
    },
    {
      id: 'BC2',
      name: 'Sarnia-Port Huron',
      status: 'delay',
      waitTime: '2 hours',
      restrictions: ['Construction ongoing', 'Width limit: 3.8m'],
      services: ['Weigh station', 'Document processing'],
      coordinates: '42.9982° N, 82.4209° W'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Border Crossing Management
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Real-time border information and documentation management
          </p>
        </div>

        {/* Quick Search */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Origin Country</label>
              <select className="w-full rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]">
                <option value="CA">Canada</option>
                <option value="US">United States</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Destination Country</label>
              <select className="w-full rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]">
                <option value="US">United States</option>
                <option value="CA">Canada</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Load Type</label>
              <select className="w-full rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]">
                <option value="oversize">Oversize Load</option>
                <option value="standard">Standard Load</option>
                <option value="hazmat">Hazardous Materials</option>
              </select>
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <button className="px-6 py-3 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
              Find Crossing Points
            </button>
          </div>
        </div>

        {/* Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Required Documents</h3>
            <ul className="space-y-3">
              <li className="flex items-center text-gray-600">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                Commercial Invoice
              </li>
              <li className="flex items-center text-gray-600">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                Bill of Lading
              </li>
              <li className="flex items-center text-gray-600">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2" />
                Special Permits Required
              </li>
            </ul>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Current Alerts</h3>
            <div className="space-y-3">
              <div className="flex items-start text-yellow-700 bg-yellow-50 p-3 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0" />
                <p className="text-sm">Extended wait times at major crossings due to increased volume</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <button className="w-full px-4 py-2 text-left bg-gray-50 hover:bg-gray-100 rounded-lg flex items-center">
                <FileText className="h-5 w-5 text-[#ED4235] mr-2" />
                Pre-file Documentation
              </button>
              <button className="w-full px-4 py-2 text-left bg-gray-50 hover:bg-gray-100 rounded-lg flex items-center">
                <Clock className="h-5 w-5 text-[#ED4235] mr-2" />
                Schedule Crossing
              </button>
            </div>
          </div>
        </div>

        {/* Crossing Points */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Available Crossing Points</h2>
          </div>

          <div className="divide-y divide-gray-200">
            {crossings.map((crossing) => (
              <div
                key={crossing.id}
                className="p-6 hover:bg-gray-50 transition-colors"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                      <Globe className="h-5 w-5 text-[#ED4235] mr-2" />
                      {crossing.name}
                    </h3>
                    <div className="flex items-center mt-1">
                      <MapPin className="h-4 w-4 text-gray-400 mr-1" />
                      <span className="text-gray-600">{crossing.coordinates}</span>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-sm font-medium text-gray-900">
                      Wait Time: {crossing.waitTime}
                    </span>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Restrictions</h4>
                    <ul className="space-y-1">
                      {crossing.restrictions.map((restriction, index) => (
                        <li key={index} className="flex items-center text-gray-600">
                          <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2" />
                          {restriction}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Available Services</h4>
                    <ul className="space-y-1">
                      {crossing.services.map((service, index) => (
                        <li key={index} className="flex items-center text-gray-600">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          {service}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-6 flex justify-end space-x-3">
                  <button className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                    View Details
                  </button>
                  <button className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
                    Schedule Crossing
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};