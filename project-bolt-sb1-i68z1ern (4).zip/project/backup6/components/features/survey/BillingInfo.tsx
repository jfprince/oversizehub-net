import React from 'react';
import { CreditCard, Building2, Mail, MapPin } from 'lucide-react';

interface BillingInfoProps {
  value: {
    name: string;
    email: string;
    company: string;
    address: string;
    paymentMethod: string;
  };
  onChange: (value: any) => void;
}

export const BillingInfo: React.FC<BillingInfoProps> = ({ value, onChange }) => {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Billing Information</h3>
      <p className="text-sm text-gray-500">
        Enter your billing details to complete the booking
      </p>

      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700">Full Name</label>
          <input
            type="text"
            value={value.name}
            onChange={(e) => onChange({ ...value, name: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Mail className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="email"
              value={value.email}
              onChange={(e) => onChange({ ...value, email: e.target.value })}
              className="block w-full pl-10 rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700">Company Name</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Building2 className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              value={value.company}
              onChange={(e) => onChange({ ...value, company: e.target.value })}
              className="block w-full pl-10 rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700">Billing Address</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MapPin className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              value={value.address}
              onChange={(e) => onChange({ ...value, address: e.target.value })}
              className="block w-full pl-10 rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700">Payment Method</label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <CreditCard className="h-5 w-5 text-gray-400" />
            </div>
            <select
              value={value.paymentMethod}
              onChange={(e) => onChange({ ...value, paymentMethod: e.target.value })}
              className="block w-full pl-10 rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]"
            >
              <option value="">Select payment method</option>
              <option value="credit">Credit Card</option>
              <option value="invoice">Invoice</option>
              <option value="purchase_order">Purchase Order</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 p-4 rounded-lg mt-6">
        <h4 className="font-medium text-gray-900 mb-2">Payment Terms</h4>
        <ul className="space-y-2 text-sm text-gray-600">
          <li>• Payment is required within 30 days of invoice</li>
          <li>• All prices are in CAD/USD based on location</li>
          <li>• Cancellation fee applies within 24 hours of survey</li>
        </ul>
      </div>
    </div>
  );
};