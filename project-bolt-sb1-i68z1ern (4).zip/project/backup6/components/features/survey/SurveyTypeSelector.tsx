import React from 'react';
import { Ruler, Plane, Laptop, Zap } from 'lucide-react';

interface SurveyTypeSelectorProps {
  value: string[];
  onChange: (value: string[]) => void;
}

export const SurveyTypeSelector: React.FC<SurveyTypeSelectorProps> = ({ value, onChange }) => {
  const surveyTypes = [
    {
      id: 'laser',
      name: 'Laser Measurement',
      icon: Zap,
      description: 'High-precision measurements for clearances and dimensions'
    },
    {
      id: 'drone',
      name: 'Aerial Survey',
      icon: Plane,
      description: 'Comprehensive aerial mapping and obstacle detection'
    },
    {
      id: 'lidar',
      name: 'LiDAR Scanning',
      icon: Ruler,
      description: '3D scanning for detailed terrain and structure analysis'
    },
    {
      id: 'digital',
      name: 'Digital Survey',
      icon: Laptop,
      description: 'Software-based analysis and route planning'
    }
  ];

  const handleToggle = (id: string) => {
    if (value.includes(id)) {
      onChange(value.filter(v => v !== id));
    } else {
      onChange([...value, id]);
    }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Select Survey Type</h3>
      <p className="text-sm text-gray-500">
        Choose one or more survey types based on your requirements
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {surveyTypes.map((type) => (
          <button
            key={type.id}
            onClick={() => handleToggle(type.id)}
            className={`p-4 rounded-lg border-2 text-left transition-all ${
              value.includes(type.id)
                ? 'border-[#ED4235] bg-red-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex items-start">
              <type.icon className={`h-6 w-6 ${
                value.includes(type.id) ? 'text-[#ED4235]' : 'text-gray-400'
              }`} />
              <div className="ml-3">
                <h4 className="text-sm font-medium text-gray-900">{type.name}</h4>
                <p className="mt-1 text-sm text-gray-500">{type.description}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};