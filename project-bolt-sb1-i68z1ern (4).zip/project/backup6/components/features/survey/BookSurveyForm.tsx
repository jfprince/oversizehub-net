import React, { useState } from 'react';
import { SurveyTypeSelector } from './SurveyTypeSelector';
import { RouteDetails } from './RouteDetails';
import { LoadDetails } from './LoadDetails';
import { SurveyorSelection } from './SurveyorSelection';
import { BillingInfo } from './BillingInfo';
import { ArrowRight, Calendar, CheckCircle } from 'lucide-react';

interface BookSurveyFormProps {
  onClose: () => void;
}

export const BookSurveyForm: React.FC<BookSurveyFormProps> = ({ onClose }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    surveyType: [],
    route: {
      origin: '',
      destination: '',
      waypoints: []
    },
    load: {
      length: '',
      width: '',
      height: '',
      weight: '',
      equipment: []
    },
    schedule: {
      date: '',
      timePreference: ''
    },
    surveyor: null,
    billing: {
      name: '',
      email: '',
      company: '',
      address: '',
      paymentMethod: ''
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
    onClose();
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <SurveyTypeSelector
            value={formData.surveyType}
            onChange={(value) => setFormData({ ...formData, surveyType: value })}
          />
        );
      case 2:
        return (
          <RouteDetails
            value={formData.route}
            onChange={(value) => setFormData({ ...formData, route: value })}
          />
        );
      case 3:
        return (
          <LoadDetails
            value={formData.load}
            onChange={(value) => setFormData({ ...formData, load: value })}
          />
        );
      case 4:
        return (
          <SurveyorSelection
            value={formData.surveyor}
            onChange={(value) => setFormData({ ...formData, surveyor: value })}
            location={formData.route.origin}
          />
        );
      case 5:
        return (
          <BillingInfo
            value={formData.billing}
            onChange={(value) => setFormData({ ...formData, billing: value })}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold">Book a Road Survey</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            ×
          </button>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex justify-between">
            {['Survey Type', 'Route', 'Load Details', 'Surveyor', 'Billing'].map((label, index) => (
              <div
                key={index}
                className={`flex items-center ${
                  index < step ? 'text-[#ED4235]' : 'text-gray-400'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    index < step ? 'bg-[#ED4235] text-white' : 'bg-gray-200'
                  }`}
                >
                  {index < step ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : (
                    index + 1
                  )}
                </div>
                <span className="ml-2 text-sm hidden md:inline">{label}</span>
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {renderStep()}

          <div className="flex justify-between pt-6 border-t border-gray-200">
            {step > 1 && (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800"
              >
                Back
              </button>
            )}
            {step < 5 ? (
              <button
                type="button"
                onClick={() => setStep(step + 1)}
                className="ml-auto flex items-center px-6 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
              >
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </button>
            ) : (
              <button
                type="submit"
                className="ml-auto flex items-center px-6 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
              >
                Book Survey
                <Calendar className="ml-2 h-4 w-4" />
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};