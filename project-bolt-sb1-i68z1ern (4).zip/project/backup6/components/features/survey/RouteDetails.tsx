import React from 'react';
import { MapPin, Plus } from 'lucide-react';
import { AddressSearch } from '../../map/AddressSearch';

interface RouteDetailsProps {
  value: {
    origin: string;
    destination: string;
    waypoints: string[];
  };
  onChange: (value: any) => void;
}

export const RouteDetails: React.FC<RouteDetailsProps> = ({ value, onChange }) => {
  const addWaypoint = () => {
    onChange({
      ...value,
      waypoints: [...value.waypoints, '']
    });
  };

  const removeWaypoint = (index: number) => {
    onChange({
      ...value,
      waypoints: value.waypoints.filter((_, i) => i !== index)
    });
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Route Information</h3>
      <p className="text-sm text-gray-500">
        Enter the route details for your survey
      </p>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Origin</label>
          <AddressSearch
            value={value.origin}
            onChange={(newValue) => onChange({ ...value, origin: newValue })}
            placeholder="Enter origin location"
          />
        </div>

        {value.waypoints.map((waypoint, index) => (
          <div key={index}>
            <label className="block text-sm font-medium text-gray-700">
              Waypoint {index + 1}
            </label>
            <div className="flex gap-2">
              <AddressSearch
                value={waypoint}
                onChange={(newValue) => {
                  const newWaypoints = [...value.waypoints];
                  newWaypoints[index] = newValue;
                  onChange({ ...value, waypoints: newWaypoints });
                }}
                placeholder="Enter waypoint location"
              />
              <button
                type="button"
                onClick={() => removeWaypoint(index)}
                className="px-2 text-gray-400 hover:text-red-500"
              >
                ×
              </button>
            </div>
          </div>
        ))}

        <button
          type="button"
          onClick={addWaypoint}
          className="flex items-center text-[#ED4235] hover:text-[#ED4235]/80"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Waypoint
        </button>

        <div>
          <label className="block text-sm font-medium text-gray-700">Destination</label>
          <AddressSearch
            value={value.destination}
            onChange={(newValue) => onChange({ ...value, destination: newValue })}
            placeholder="Enter destination location"
          />
        </div>
      </div>
    </div>
  );
};