import React from 'react';
import { Truck, Package, Scale } from 'lucide-react';

interface LoadDetailsProps {
  value: {
    length: string;
    width: string;
    height: string;
    weight: string;
    equipment: string[];
  };
  onChange: (value: any) => void;
}

export const LoadDetails: React.FC<LoadDetailsProps> = ({ value, onChange }) => {
  const equipmentOptions = [
    'Crane',
    'High Pole',
    'Escort Vehicles',
    'Height Measuring Device',
    'Width Measuring Device',
    'LiDAR Scanner',
    'Drone'
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Load Details</h3>
      <p className="text-sm text-gray-500">
        Enter the dimensions and requirements for your load
      </p>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
          <input
            type="number"
            value={value.length}
            onChange={(e) => onChange({ ...value, length: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
          <input
            type="number"
            value={value.width}
            onChange={(e) => onChange({ ...value, width: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
          <input
            type="number"
            value={value.height}
            onChange={(e) => onChange({ ...value, height: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
          <input
            type="number"
            value={value.weight}
            onChange={(e) => onChange({ ...value, weight: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Required Equipment
        </label>
        <div className="grid grid-cols-2 gap-2">
          {equipmentOptions.map((equipment) => (
            <label key={equipment} className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={value.equipment.includes(equipment)}
                onChange={(e) => {
                  if (e.target.checked) {
                    onChange({
                      ...value,
                      equipment: [...value.equipment, equipment]
                    });
                  } else {
                    onChange({
                      ...value,
                      equipment: value.equipment.filter((eq) => eq !== equipment)
                    });
                  }
                }}
                className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
              />
              <span className="text-sm text-gray-700">{equipment}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};