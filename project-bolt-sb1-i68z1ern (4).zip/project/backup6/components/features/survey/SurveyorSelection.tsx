import React from 'react';
import { Star, MapPin, Calendar, Clock } from 'lucide-react';

interface SurveyorSelectionProps {
  value: any;
  onChange: (value: any) => void;
  location: string;
}

export const SurveyorSelection: React.FC<SurveyorSelectionProps> = ({ value, onChange, location }) => {
  const surveyors = [
    {
      id: 1,
      name: 'John Smith',
      company: 'Precision Surveys Inc.',
      rating: 4.8,
      reviews: 156,
      location: 'Montreal, QC',
      availability: ['Mon-Fri', '8:00 AM - 6:00 PM'],
      specialties: ['LiDAR', 'Drone', 'High Pole'],
      price: '$450/day'
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      company: 'Advanced Route Surveys',
      rating: 4.9,
      reviews: 203,
      location: 'Toronto, ON',
      availability: ['Mon-Sat', '7:00 AM - 8:00 PM'],
      specialties: ['Laser Measurement', 'Bridge Clearance', 'Route Planning'],
      price: '$500/day'
    }
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Select a Surveyor</h3>
      <p className="text-sm text-gray-500">
        Choose from available surveyors in your area
      </p>

      <div className="space-y-4">
        {surveyors.map((surveyor) => (
          <div
            key={surveyor.id}
            className={`border-2 rounded-lg p-4 transition-all ${
              value?.id === surveyor.id
                ? 'border-[#ED4235] bg-red-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <label className="flex items-start space-x-4 cursor-pointer">
              <input
                type="radio"
                name="surveyor"
                checked={value?.id === surveyor.id}
                onChange={() => onChange(surveyor)}
                className="mt-1 text-[#ED4235] focus:ring-[#ED4235]"
              />
              <div className="flex-grow">
                <div className="flex justify-between">
                  <div>
                    <h4 className="font-medium text-gray-900">{surveyor.name}</h4>
                    <p className="text-sm text-gray-500">{surveyor.company}</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400" />
                      <span className="ml-1 text-sm font-medium">{surveyor.rating}</span>
                      <span className="ml-1 text-sm text-gray-500">
                        ({surveyor.reviews} reviews)
                      </span>
                    </div>
                    <p className="text-sm font-medium text-[#ED4235]">{surveyor.price}</p>
                  </div>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-4">
                  <div className="flex items-center text-sm text-gray-500">
                    <MapPin className="h-4 w-4 mr-1" />
                    {surveyor.location}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {surveyor.availability[0]}
                  </div>
                </div>
                <div className="mt-2">
                  <p className="text-sm text-gray-500">Specialties:</p>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {surveyor.specialties.map((specialty) => (
                      <span
                        key={specialty}
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </label>
          </div>
        ))}
      </div>

      {value && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-2">Schedule Survey</h4>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Preferred Date</label>
              <input
                type="date"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Preferred Time</label>
              <select
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              >
                <option>Morning (8AM - 12PM)</option>
                <option>Afternoon (12PM - 4PM)</option>
                <option>Evening (4PM - 8PM)</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};