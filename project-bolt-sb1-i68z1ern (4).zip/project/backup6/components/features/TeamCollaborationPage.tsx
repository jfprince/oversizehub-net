import React, { useState } from 'react';
import { 
  Users, 
  MessageSquare, 
  Bell, 
  Calendar,
  FileText,
  Map,
  Share,
  Settings,
  Plus,
  UserPlus,
  Mail,
  Phone,
  Clock
} from 'lucide-react';

export const TeamCollaborationPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('team');

  const teamMembers = [
    {
      id: 'TM1',
      name: 'John Smith',
      role: 'Transport Manager',
      status: 'online',
      currentTask: 'Route planning - ON to QC',
      lastActive: '2 mins ago'
    },
    {
      id: 'TM2',
      name: 'Sarah Johnson',
      role: 'Permit Specialist',
      status: 'busy',
      currentTask: 'Processing permits',
      lastActive: '15 mins ago'
    }
  ];

  const recentActivities = [
    {
      id: 'A1',
      user: 'John Smith',
      action: 'Updated route plan',
      resource: 'Route #RT456',
      time: '10 mins ago'
    },
    {
      id: 'A2',
      user: 'Sarah Johnson',
      action: 'Added new permit',
      resource: 'Permit #P789',
      time: '1 hour ago'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Team Collaboration Hub
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Real-time collaboration tools for transport teams
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <button className="flex items-center justify-center p-6 bg-white rounded-xl shadow-lg border-2 border-transparent hover:border-[#ED4235] transition-all">
            <MessageSquare className="h-6 w-6 text-[#ED4235] mr-3" />
            <span className="text-lg font-medium">Team Chat</span>
          </button>
          <button className="flex items-center justify-center p-6 bg-white rounded-xl shadow-lg border-2 border-transparent hover:border-[#ED4235] transition-all">
            <Map className="h-6 w-6 text-[#ED4235] mr-3" />
            <span className="text-lg font-medium">Share Route</span>
          </button>
          <button className="flex items-center justify-center p-6 bg-white rounded-xl shadow-lg border-2 border-transparent hover:border-[#ED4235] transition-all">
            <Calendar className="h-6 w-6 text-[#ED4235] mr-3" />
            <span className="text-lg font-medium">Schedule</span>
          </button>
          <button className="flex items-center justify-center p-6 bg-white rounded-xl shadow-lg border-2 border-transparent hover:border-[#ED4235] transition-all">
            <UserPlus className="h-6 w-6 text-[#ED4235] mr-3" />
            <span className="text-lg font-medium">Add Member</span>
          </button>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex">
              {['team', 'activity', 'documents', 'settings'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-6 py-4 text-sm font-medium border-b-2 ${
                    activeTab === tab
                      ? 'border-[#ED4235] text-[#ED4235]'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </nav>
          </div>

          {/* Team Members */}
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Team Members</h2>
              <button className="flex items-center text-[#ED4235] hover:text-[#ED4235]/80">
                <Plus className="h-5 w-5 mr-1" />
                Add Member
              </button>
            </div>

            <div className="space-y-4">
              {teamMembers.map((member) => (
                <div
                  key={member.id}
                  className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{member.name}</h3>
                      <p className="text-gray-600">{member.role}</p>
                    </div>
                    <div className="flex items-center">
                      <span className={`w-3 h-3 rounded-full ${
                        member.status === 'online' ? 'bg-green-500' : 'bg-yellow-500'
                      }`} />
                      <span className="ml-2 text-sm text-gray-500">{member.status}</span>
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700">Current Task</h4>
                      <p className="text-gray-600">{member.currentTask}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-700">Last Active</h4>
                      <p className="text-gray-600">{member.lastActive}</p>
                    </div>
                  </div>

                  <div className="mt-4 flex justify-end space-x-3">
                    <button className="flex items-center px-3 py-2 text-gray-600 hover:text-[#ED4235]">
                      <Mail className="h-4 w-4 mr-1" />
                      Message
                    </button>
                    <button className="flex items-center px-3 py-2 text-gray-600 hover:text-[#ED4235]">
                      <Phone className="h-4 w-4 mr-1" />
                      Call
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Recent Activity */}
            <div className="mt-8">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Recent Activity</h2>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-[#ED4235] mr-3" />
                      <div>
                        <p className="text-gray-900">
                          <span className="font-medium">{activity.user}</span>
                          {' '}{activity.action}
                        </p>
                        <p className="text-sm text-gray-500">{activity.resource}</p>
                      </div>
                    </div>
                    <span className="text-sm text-gray-500">{activity.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};