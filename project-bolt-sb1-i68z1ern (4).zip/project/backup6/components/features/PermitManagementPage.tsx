import React, { useState } from 'react';
import { 
  FileText, 
  Shield, 
  Clock, 
  Calendar,
  CheckCircle,
  AlertTriangle,
  Download,
  Upload,
  Search,
  Filter,
  Plus
} from 'lucide-react';

export const PermitManagementPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('active');

  const permits = [
    {
      id: 'P1',
      type: 'Oversize',
      status: 'active',
      jurisdiction: 'Ontario',
      expiry: '2024-06-15',
      details: {
        dimensions: '4.6m x 3.8m x 25m',
        weight: '85,000 kg',
        restrictions: ['No night movement', 'Escort required']
      }
    },
    {
      id: 'P2',
      type: 'Superload',
      status: 'pending',
      jurisdiction: 'Quebec',
      expiry: '2024-07-01',
      details: {
        dimensions: '5.2m x 4.3m x 30m',
        weight: '120,000 kg',
        restrictions: ['Police escort required', 'Daylight hours only']
      }
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Permit Management System
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Streamlined permit application, tracking, and management
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <button className="flex items-center justify-center p-6 bg-white rounded-xl shadow-lg border-2 border-transparent hover:border-[#ED4235] transition-all">
            <Plus className="h-6 w-6 text-[#ED4235] mr-3" />
            <span className="text-lg font-medium">New Application</span>
          </button>
          <button className="flex items-center justify-center p-6 bg-white rounded-xl shadow-lg border-2 border-transparent hover:border-[#ED4235] transition-all">
            <Upload className="h-6 w-6 text-[#ED4235] mr-3" />
            <span className="text-lg font-medium">Bulk Import</span>
          </button>
          <button className="flex items-center justify-center p-6 bg-white rounded-xl shadow-lg border-2 border-transparent hover:border-[#ED4235] transition-all">
            <Download className="h-6 w-6 text-[#ED4235] mr-3" />
            <span className="text-lg font-medium">Export Reports</span>
          </button>
        </div>

        {/* Permit List */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex">
              {['active', 'pending', 'expired'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-6 py-4 text-sm font-medium border-b-2 ${
                    activeTab === tab
                      ? 'border-[#ED4235] text-[#ED4235]'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </nav>
          </div>

          {/* Search and Filter */}
          <div className="p-4 border-b border-gray-200 bg-gray-50">
            <div className="flex space-x-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search permits..."
                  className="w-full pl-10 pr-4 py-2 rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]"
                />
              </div>
              <button className="px-4 py-2 bg-white border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </button>
            </div>
          </div>

          {/* Permit Cards */}
          <div className="p-6 space-y-4">
            {permits.map((permit) => (
              <div
                key={permit.id}
                className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                      <Shield className="h-5 w-5 text-[#ED4235] mr-2" />
                      {permit.type} Permit - {permit.id}
                    </h3>
                    <p className="text-gray-600 mt-1">{permit.jurisdiction}</p>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-600">Expires: {permit.expiry}</span>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-700">Dimensions</h4>
                    <p className="text-gray-600">{permit.details.dimensions}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-700">Weight</h4>
                    <p className="text-gray-600">{permit.details.weight}</p>
                  </div>
                </div>

                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-700">Restrictions</h4>
                  <ul className="mt-2 space-y-1">
                    {permit.details.restrictions.map((restriction, index) => (
                      <li key={index} className="flex items-center text-gray-600">
                        <AlertTriangle className="h-4 w-4 text-[#ED4235] mr-2" />
                        {restriction}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6 flex justify-end space-x-3">
                  <button className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                    View Details
                  </button>
                  <button className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
                    Download PDF
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};