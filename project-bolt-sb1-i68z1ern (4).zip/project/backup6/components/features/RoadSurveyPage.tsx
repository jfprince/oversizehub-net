import React, { useState } from 'react';
import { 
  Camera, 
  Ruler, 
  FileText, 
  MapPin,
  Plus,
  Upload,
  Download,
  Trash,
  Image,
  Map,
  Compass,
  AlertTriangle,
  CheckCircle,
  Clock,
  Share,
  Plane,
  Zap,
  Laptop,
  ArrowRight,
  Calendar
} from 'lucide-react';
import { BookSurveyForm } from './survey/BookSurveyForm';

export const RoadSurveyPage: React.FC = () => {
  const [showBooking, setShowBooking] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const surveyTools = [
    {
      id: 'laser',
      name: 'Laser Measurement',
      icon: Zap,
      description: 'High-precision laser tools for accurate measurements',
      features: [
        'Millimeter accuracy',
        'Bridge clearance measurement',
        'Width verification',
        'Real-time data logging'
      ]
    },
    {
      id: 'drone',
      name: 'Aerial Survey',
      icon: Plane,
      description: 'Drone-based surveying for comprehensive route analysis',
      features: [
        'Aerial photography',
        'Terrain mapping',
        'Obstacle detection',
        'Route visualization'
      ]
    },
    {
      id: 'digital',
      name: 'Digital Tools',
      icon: Laptop,
      description: 'Advanced software for survey data processing',
      features: [
        '3D modeling',
        'Route simulation',
        'Clearance analysis',
        'Report generation'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Advanced Road Survey Solutions
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Precision surveying tools for oversized transport planning
          </p>
          <div className="mt-8">
            <button
              onClick={() => setShowBooking(true)}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-[#ED4235] hover:bg-opacity-90"
            >
              <Calendar className="mr-2 h-5 w-5" />
              Book a Survey
            </button>
          </div>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {surveyTools.map((tool) => (
            <div
              key={tool.id}
              className="bg-white rounded-xl shadow-lg p-8 border-2 border-transparent hover:border-[#ED4235] transition-all"
            >
              <div className="flex items-center mb-6">
                <tool.icon className="h-8 w-8 text-[#ED4235]" />
                <h3 className="ml-4 text-xl font-semibold text-gray-900">{tool.name}</h3>
              </div>
              <p className="text-gray-600 mb-6">{tool.description}</p>
              <ul className="space-y-3">
                {tool.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-[#ED4235] mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Process Steps */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb- lg p-8 mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Survey Process
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-[#ED4235]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Map className="h-8 w-8 text-[#ED4235]" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Route Planning</h3>
              <p className="text-gray-600">Define survey points and requirements</p>
            </div>
            <div className="text-center">
              <div className="bg-[#ED4235]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Ruler className="h-8 w-8 text-[#ED4235]" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Data Collection</h3>
              <p className="text-gray-600">Gather measurements and imagery</p>
            </div>
            <div className="text-center">
              <div className="bg-[#ED4235]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Laptop className="h-8 w-8 text-[#ED4235]" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Analysis</h3>
              <p className="text-gray-600">Process and verify collected data</p>
            </div>
            <div className="text-center">
              <div className="bg-[#ED4235]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-8 w-8 text-[#ED4235]" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Reporting</h3>
              <p className="text-gray-600">Generate comprehensive reports</p>
            </div>
          </div>
        </div>

        {/* Survey Management */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="border-b border-gray-200">
            <nav className="flex">
              {['overview', 'data', 'reports', 'settings'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-6 py-4 text-sm font-medium border-b-2 ${
                    activeTab === tab
                      ? 'border-[#ED4235] text-[#ED4235]'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Recent Surveys</h2>
              <button className="flex items-center text-[#ED4235] hover:text-[#ED4235]/80">
                <Plus className="h-5 w-5 mr-1" />
                New Survey
              </button>
            </div>

            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-gray-900">Montreal-Toronto Route Survey</h3>
                    <p className="text-sm text-gray-600 mt-1">Last updated: 2 hours ago</p>
                  </div>
                  <div className="flex space-x-2">
                    <button className="p-2 text-gray-400 hover:text-[#ED4235]">
                      <Share className="h-5 w-5" />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-[#ED4235]">
                      <Download className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showBooking && <BookSurveyForm onClose={() => setShowBooking(false)} />}
    </div>
  );
};