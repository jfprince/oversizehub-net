import React, { useState } from 'react';
import { 
  Layers, 
  Ruler, 
  Compass, 
  Map as MapIcon,
  Eye,
  Settings,
  Plus,
  Trash,
  Navigation,
  FileText,
  Globe,
  Shield
} from 'lucide-react';

export const AdvancedMappingPage: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState<string | null>(null);

  const features = [
    {
      id: 'measurement',
      title: 'Advanced Measurement Tools',
      icon: Ruler,
      description: 'Precise measurement tools for distances, areas, and heights',
      details: [
        'Distance calculation with elevation consideration',
        'Area measurement with terrain adjustment',
        'Height and clearance calculations',
        'Custom measurement units'
      ]
    },
    {
      id: 'routing',
      title: 'Intelligent Routing',
      icon: Navigation,
      description: 'Smart routing algorithms for oversized loads',
      details: [
        'Height restriction awareness',
        'Bridge and tunnel clearance',
        'Weight limit consideration',
        'Turn radius analysis'
      ]
    },
    {
      id: 'layers',
      title: 'Custom Map Layers',
      icon: Layers,
      description: 'Create and manage custom map overlays',
      details: [
        'Infrastructure layers',
        'Restriction zones',
        'Custom points of interest',
        'Real-time updates'
      ]
    },
    {
      id: 'compliance',
      title: 'Compliance Integration',
      icon: Shield,
      description: 'Built-in compliance checking and verification',
      details: [
        'Permit requirements',
        'Route restrictions',
        'Time-of-day limitations',
        'Documentation generation'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Advanced Mapping Solutions
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Professional-grade mapping tools for heavy transport operations
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {features.map((feature) => (
            <div
              key={feature.id}
              className={`bg-white rounded-xl shadow-lg p-8 border-2 transition-all duration-200 ${
                activeFeature === feature.id
                  ? 'border-[#ED4235] transform scale-[1.02]'
                  : 'border-transparent hover:border-[#ED4235] hover:scale-[1.01]'
              }`}
              onMouseEnter={() => setActiveFeature(feature.id)}
              onMouseLeave={() => setActiveFeature(null)}
            >
              <div className="flex items-start">
                <feature.icon className="h-8 w-8 text-[#ED4235] flex-shrink-0" />
                <div className="ml-4">
                  <h3 className="text-xl font-semibold text-gray-900">{feature.title}</h3>
                  <p className="mt-2 text-gray-600">{feature.description}</p>
                  <ul className="mt-4 space-y-2">
                    {feature.details.map((detail, index) => (
                      <li key={index} className="flex items-center text-gray-600">
                        <Shield className="h-4 w-4 text-[#ED4235] mr-2" />
                        {detail}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-[#ED4235]/5 via-[#ED4235]/10 to-[#ED4235]/5 rounded-2xl p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Ready to Experience Advanced Mapping?
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Access our full suite of professional mapping tools and start optimizing your transport operations today.
          </p>
          <div className="flex justify-center space-x-4">
            <button className="px-6 py-3 bg-[#ED4235] text-white rounded-xl hover:bg-opacity-90 flex items-center">
              <MapIcon className="h-5 w-5 mr-2" />
              Launch Advanced Map
            </button>
            <button className="px-6 py-3 border-2 border-[#ED4235] text-[#ED4235] rounded-xl hover:bg-[#ED4235] hover:text-white">
              <FileText className="h-5 w-5 mr-2 inline" />
              View Documentation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};