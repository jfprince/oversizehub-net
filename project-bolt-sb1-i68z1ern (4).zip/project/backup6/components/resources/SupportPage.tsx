import React, { useState } from 'react';
import { 
  MessageSquare, 
  Plus, 
  Filter,
  Search,
  Clock,
  AlertTriangle,
  CheckCircle,
  Tag,
  User,
  Paperclip,
  Send,
  Phone,
  FileText
} from 'lucide-react';
import { useSupportStore } from '../../stores/supportStore';
import { SupportTicket, TicketCategory, TicketPriority } from '../../types/support';
import { CreateTicketForm } from './support/CreateTicketForm';
import { TicketDetails } from './support/TicketDetails';
import { TicketFilters } from './support/TicketFilters';

export const SupportPage: React.FC = () => {
  const [showCreateTicket, setShowCreateTicket] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const { tickets, activeTicket, setActiveTicket } = useSupportStore();

  const filteredTickets = tickets.filter(ticket => 
    ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ticket.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">Support Center</h1>
          <p className="mt-4 text-xl text-gray-600">
            Get help with your questions and issues
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Tickets List */}
          <div className="md:col-span-1 space-y-6">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-lg font-semibold text-gray-900">My Tickets</h2>
                <button
                  onClick={() => setShowCreateTicket(true)}
                  className="px-3 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 flex items-center"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  New Ticket
                </button>
              </div>

              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search tickets..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  />
                </div>

                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center text-gray-600 hover:text-[#ED4235]"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Filters
                </button>

                {showFilters && <TicketFilters />}
              </div>

              <div className="mt-6 space-y-4">
                {filteredTickets.map((ticket) => (
                  <button
                    key={ticket.id}
                    onClick={() => setActiveTicket(ticket)}
                    className={`w-full text-left p-4 rounded-lg border ${
                      activeTicket?.id === ticket.id
                        ? 'border-[#ED4235] bg-red-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-gray-900">{ticket.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">
                          {ticket.description.slice(0, 100)}...
                        </p>
                      </div>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        ticket.status === 'open' ? 'bg-blue-100 text-blue-800' :
                        ticket.status === 'in-progress' ? 'bg-yellow-100 text-yellow-800' :
                        ticket.status === 'resolved' ? 'bg-green-100 text-green-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {ticket.status}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Ticket Details or Help Center */}
          <div className="md:col-span-2">
            {activeTicket ? (
              <TicketDetails ticket={activeTicket} />
            ) : (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Help Center</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="p-6 bg-gray-50 rounded-lg">
                    <Phone className="h-8 w-8 text-[#ED4235] mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Contact Support</h3>
                    <p className="text-gray-600 mb-4">
                      Need immediate assistance? Our support team is available 24/7.
                    </p>
                    <button className="text-[#ED4235] hover:text-[#ED4235]/90 font-medium">
                      Contact Us
                    </button>
                  </div>

                  <div className="p-6 bg-gray-50 rounded-lg">
                    <FileText className="h-8 w-8 text-[#ED4235] mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Documentation</h3>
                    <p className="text-gray-600 mb-4">
                      Browse our comprehensive documentation and guides.
                    </p>
                    <button className="text-[#ED4235] hover:text-[#ED4235]/90 font-medium">
                      View Docs
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {showCreateTicket && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="max-w-2xl w-full mx-4">
            <CreateTicketForm onClose={() => setShowCreateTicket(false)} />
          </div>
        </div>
      )}
    </div>
  );
};