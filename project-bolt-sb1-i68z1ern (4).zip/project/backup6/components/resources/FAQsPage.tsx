import React, { useState } from 'react';
import { ChevronDown, Search, Tag } from 'lucide-react';

interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export const FAQsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const faqs: FAQ[] = [
    {
      id: '1',
      category: 'general',
      question: 'What is OversizeHub?',
      answer: 'OversizeHub is a professional platform designed specifically for the heavy transport industry, offering advanced route planning, compliance management, and collaboration tools for oversized load transportation.'
    },
    {
      id: '2',
      category: 'route-planning',
      question: 'How does the route planning system work?',
      answer: 'Our route planning system uses advanced algorithms to analyze road networks, bridge clearances, weight restrictions, and other factors to determine the optimal route for oversized loads. It takes into account your vehicle dimensions and load specifications to ensure compliance.'
    },
    {
      id: '3',
      category: 'compliance',
      question: 'How do I ensure my route is compliant with local regulations?',
      answer: 'OversizeHub maintains an up-to-date database of regulations across different jurisdictions. Our system automatically checks your route against these regulations and highlights any permits or special requirements needed.'
    },
    {
      id: '4',
      category: 'surveys',
      question: 'What\'s the difference between a desktop and physical survey?',
      answer: 'A desktop survey uses digital tools and existing data to analyze a route, while a physical survey involves on-site measurements and verification. Desktop surveys are faster and more cost-effective, but physical surveys may be required for complex routes or specific permit requirements.'
    },
    {
      id: '5',
      category: 'partnerships',
      question: 'How can I become a partner?',
      answer: 'You can apply to become a partner through our partner application process. We welcome qualified surveyors, pilot car services, and permit services. Visit our "Become a Partner" page to learn more and submit your application.'
    },
    {
      id: '6',
      category: 'pricing',
      question: 'What payment methods do you accept?',
      answer: 'We accept all major credit cards, wire transfers, and ACH payments. For business accounts, we also offer NET-30 terms upon approval. Partners receive payment within 48 hours of invoice submission.'
    }
  ];

  const categories = [
    { id: 'all', label: 'All Categories' },
    { id: 'general', label: 'General' },
    { id: 'route-planning', label: 'Route Planning' },
    { id: 'compliance', label: 'Compliance' },
    { id: 'surveys', label: 'Surveys' },
    { id: 'partnerships', label: 'Partnerships' },
    { id: 'pricing', label: 'Pricing & Billing' }
  ];

  const filteredFaqs = faqs.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Frequently Asked Questions
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Find answers to common questions about our services
          </p>
        </div>

        {/* Search and Filters */}
        <div className="max-w-3xl mx-auto mb-12">
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search FAQs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium ${
                  selectedCategory === category.id
                    ? 'bg-[#ED4235] text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                } transition-colors`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>

        {/* FAQs List */}
        <div className="max-w-3xl mx-auto space-y-4">
          {filteredFaqs.map((faq) => (
            <div
              key={faq.id}
              className="bg-white rounded-lg shadow-md overflow-hidden"
            >
              <button
                onClick={() => setExpandedId(expandedId === faq.id ? null : faq.id)}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50"
              >
                <span className="font-medium text-gray-900">{faq.question}</span>
                <ChevronDown
                  className={`h-5 w-5 text-gray-500 transition-transform ${
                    expandedId === faq.id ? 'rotate-180' : ''
                  }`}
                />
              </button>
              
              {expandedId === faq.id && (
                <div className="px-6 py-4 bg-gray-50">
                  <p className="text-gray-700">{faq.answer}</p>
                  <div className="mt-4 flex items-center">
                    <Tag className="h-4 w-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-500 capitalize">{faq.category}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact Support */}
        <div className="max-w-3xl mx-auto mt-12 p-6 bg-white rounded-lg shadow-md text-center">
          <h3 className="text-lg font-medium text-gray-900">
            Can't find what you're looking for?
          </h3>
          <p className="mt-2 text-gray-600">
            Our support team is here to help with any questions you may have.
          </p>
          <button className="mt-4 px-6 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
            Contact Support
          </button>
        </div>
      </div>
    </div>
  );
};