import React, { useState } from 'react';
import { 
  MessageSquare,
  Paperclip,
  Send,
  Tag,
  Clock,
  User,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';
import { useSupportStore } from '../../../stores/supportStore';
import { SupportTicket, TicketMessage } from '../../../types/support';

interface TicketDetailsProps {
  ticket: SupportTicket;
}

export const TicketDetails: React.FC<TicketDetailsProps> = ({ ticket }) => {
  const [newMessage, setNewMessage] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);
  
  const addMessage = useSupportStore((state) => state.addMessage);
  const updateTicket = useSupportStore((state) => state.updateTicket);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;

    addMessage({
      ticketId: ticket.id,
      userId: 'current-user-id', // This should come from auth context
      content: newMessage,
      attachments: attachments.map(file => URL.createObjectURL(file)),
      isStaff: false
    });

    setNewMessage('');
    setAttachments([]);
  };

  const handleStatusChange = (status: string) => {
    updateTicket(ticket.id, { status: status as any });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-blue-100 text-blue-800';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'resolved':
        return 'bg-green-100 text-green-800';
      case 'closed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      case 'medium':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'low':
        return <Clock className="h-5 w-5 text-green-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">{ticket.title}</h2>
            <div className="mt-2 flex items-center space-x-4">
              <span className={`px-2 py-1 text-sm font-medium rounded-full ${getStatusColor(ticket.status)}`}>
                {ticket.status}
              </span>
              <span className="flex items-center text-sm text-gray-500">
                {getPriorityIcon(ticket.priority)}
                <span className="ml-1 capitalize">{ticket.priority} Priority</span>
              </span>
              <span className="flex items-center text-sm text-gray-500">
                <Tag className="h-4 w-4 mr-1" />
                {ticket.category}
              </span>
            </div>
          </div>

          <select
            value={ticket.status}
            onChange={(e) => handleStatusChange(e.target.value)}
            className="rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          >
            <option value="open">Open</option>
            <option value="in-progress">In Progress</option>
            <option value="resolved">Resolved</option>
            <option value="closed">Closed</option>
          </select>
        </div>

        <p className="mt-4 text-gray-600">{ticket.description}</p>

        {ticket.attachments && ticket.attachments.length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium text-gray-900">Attachments</h4>
            <div className="mt-2 space-y-2">
              {ticket.attachments.map((attachment, index) => (
                <a
                  key={index}
                  href={attachment}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-2 bg-gray-50 rounded-md hover:bg-gray-100"
                >
                  <Paperclip className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-600">Attachment {index + 1}</span>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Messages</h3>
        
        <div className="space-y-6 mb-6">
          {ticket.messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isStaff ? 'justify-start' : 'justify-end'}`}
            >
              <div className={`max-w-lg rounded-lg p-4 ${
                message.isStaff ? 'bg-gray-100' : 'bg-[#ED4235] text-white'
              }`}>
                <div className="flex items-center mb-2">
                  <User className="h-4 w-4 mr-2" />
                  <span className="text-sm font-medium">
                    {message.isStaff ? 'Support Staff' : 'You'}
                  </span>
                  <span className="text-xs ml-2 opacity-75">
                    {new Date(message.createdAt).toLocaleString()}
                  </span>
                </div>
                <p>{message.content}</p>
                {message.attachments && message.attachments.length > 0 && (
                  <div className="mt-2 space-y-1">
                    {message.attachments.map((attachment, index) => (
                      <a
                        key={index}
                        href={attachment}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-sm hover:underline"
                      >
                        <Paperclip className="h-4 w-4 mr-1" />
                        <span>Attachment {index + 1}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="sr-only">Message</label>
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              rows={3}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              placeholder="Type your message..."
              required
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <input
                type="file"
                id="attachments"
                multiple
                className="sr-only"
                onChange={(e) => {
                  if (e.target.files) {
                    setAttachments(Array.from(e.target.files));
                  }
                }}
              />
              <label
                htmlFor="attachments"
                className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 cursor-pointer"
              >
                <Paperclip className="h-4 w-4 mr-2" />
                Add Attachments
              </label>
            </div>

            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-[#ED4235] hover:bg-opacity-90"
            >
              <Send className="h-4 w-4 mr-2" />
              Send Message
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};