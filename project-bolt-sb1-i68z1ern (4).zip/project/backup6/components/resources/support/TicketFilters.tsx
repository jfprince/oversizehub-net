import React from 'react';
import { useSupportStore } from '../../../stores/supportStore';
import { TicketStatus, TicketPriority, TicketCategory } from '../../../types/support';

export const TicketFilters: React.FC = () => {
  const { filters, setFilters } = useSupportStore();

  const handleFilterChange = (key: string, value: any) => {
    setFilters({ ...filters, [key]: value });
  };

  return (
    <div className="p-4 space-y-4 bg-gray-50 rounded-lg mt-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Status</label>
        <select
          value={filters.status || ''}
          onChange={(e) => handleFilterChange('status', e.target.value || undefined)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="">All Statuses</option>
          <option value="open">Open</option>
          <option value="in-progress">In Progress</option>
          <option value="resolved">Resolved</option>
          <option value="closed">Closed</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Priority</label>
        <select
          value={filters.priority || ''}
          onChange={(e) => handleFilterChange('priority', e.target.value || undefined)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="">All Priorities</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
          <option value="urgent">Urgent</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Category</label>
        <select
          value={filters.category || ''}
          onChange={(e) => handleFilterChange('category', e.target.value || undefined)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="">All Categories</option>
          <option value="technical">Technical</option>
          <option value="billing">Billing</option>
          <option value="account">Account</option>
          <option value="route-planning">Route Planning</option>
          <option value="compliance">Compliance</option>
          <option value="survey">Survey</option>
          <option value="other">Other</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Date Range</label>
        <div className="grid grid-cols-2 gap-4 mt-1">
          <input
            type="date"
            value={filters.dateRange?.start?.toISOString().split('T')[0] || ''}
            onChange={(e) => handleFilterChange('dateRange', {
              ...filters.dateRange,
              start: e.target.value ? new Date(e.target.value) : undefined
            })}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
          <input
            type="date"
            value={filters.dateRange?.end?.toISOString().split('T')[0] || ''}
            onChange={(e) => handleFilterChange('dateRange', {
              ...filters.dateRange,
              end: e.target.value ? new Date(e.target.value) : undefined
            })}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
      </div>

      <button
        onClick={() => setFilters({})}
        className="w-full px-4 py-2 text-sm text-[#ED4235] hover:bg-red-50 rounded-md"
      >
        Clear Filters
      </button>
    </div>
  );
};