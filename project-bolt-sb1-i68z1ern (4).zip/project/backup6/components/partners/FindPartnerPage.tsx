import React, { useState } from 'react';
import { 
  Search, 
  MapPin, 
  Star, 
  Shield,
  Truck,
  FileText,
  Filter,
  Globe,
  Building2
} from 'lucide-react';

interface Partner {
  id: string;
  name: string;
  type: string;
  rating: number;
  reviews: number;
  location: string;
  regions: string[];
  services: string[];
  certifications: string[];
  experience: string;
}

export const FindPartnerPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedRegion, setSelectedRegion] = useState('all');

  const partners: Partner[] = [
    {
      id: '1',
      name: 'Elite Route Surveys Inc.',
      type: 'surveyor',
      rating: 4.9,
      reviews: 156,
      location: 'Toronto, ON',
      regions: ['Ontario', 'Quebec', 'New York'],
      services: ['Route Surveys', 'Height Analysis', 'Turn Studies'],
      certifications: ['DOT Certified', 'Professional Engineer'],
      experience: '15+ years'
    },
    {
      id: '2',
      name: 'SafeEscort Services',
      type: 'escort',
      rating: 4.8,
      reviews: 203,
      location: 'Montreal, QC',
      regions: ['Quebec', 'Ontario', 'Maritime Provinces'],
      services: ['Pilot Car', 'Route Planning', 'Height Pole'],
      certifications: ['Certified Pilot Car', 'Safety Training'],
      experience: '12+ years'
    },
    {
      id: '3',
      name: 'Express Permits LLC',
      type: 'permit',
      rating: 4.95,
      reviews: 178,
      location: 'Buffalo, NY',
      regions: ['New York', 'Pennsylvania', 'Ohio'],
      services: ['Permit Processing', 'Route Analysis', 'Compliance Check'],
      certifications: ['State DOT Certified', 'FMCSA Compliant'],
      experience: '20+ years'
    }
  ];

  const partnerTypes = [
    { id: 'all', label: 'All Partners' },
    { id: 'surveyor', label: 'Route Surveyors' },
    { id: 'escort', label: 'Pilot Car Services' },
    { id: 'permit', label: 'Permit Services' },
    { id: 'carrier', label: 'Transport Companies' }
  ];

  const regions = [
    { id: 'all', label: 'All Regions' },
    { id: 'on', label: 'Ontario' },
    { id: 'qc', label: 'Quebec' },
    { id: 'bc', label: 'British Columbia' },
    { id: 'ny', label: 'New York' },
    { id: 'mi', label: 'Michigan' }
  ];

  const filteredPartners = partners.filter(partner => {
    const matchesSearch = partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         partner.services.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = selectedType === 'all' || partner.type === selectedType;
    const matchesRegion = selectedRegion === 'all' || partner.regions.some(r => r.toLowerCase().includes(selectedRegion.toLowerCase()));
    
    return matchesSearch && matchesType && matchesRegion;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Find a Partner
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Connect with trusted professionals in the heavy transport industry
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search partners..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>

            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            >
              {partnerTypes.map(type => (
                <option key={type.id} value={type.id}>{type.label}</option>
              ))}
            </select>

            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            >
              {regions.map(region => (
                <option key={region.id} value={region.id}>{region.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Partners List */}
        <div className="space-y-6">
          {filteredPartners.map(partner => (
            <div key={partner.id} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{partner.name}</h3>
                  <div className="flex items-center mt-2">
                    <Star className="h-5 w-5 text-yellow-400" />
                    <span className="ml-1 text-sm font-medium">{partner.rating}</span>
                    <span className="ml-1 text-sm text-gray-500">({partner.reviews} reviews)</span>
                  </div>
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <MapPin className="h-4 w-4 mr-1" />
                    {partner.location}
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-[#ED4235]/10 text-[#ED4235]">
                    {partner.experience}
                  </span>
                </div>
              </div>

              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900">Services</h4>
                <div className="mt-2 flex flex-wrap gap-2">
                  {partner.services.map((service, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                    >
                      {service}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900">Certifications</h4>
                <div className="mt-2 flex flex-wrap gap-2">
                  {partner.certifications.map((cert, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800"
                    >
                      <Shield className="h-3 w-3 mr-1" />
                      {cert}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex justify-end space-x-4">
                <button className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                  View Profile
                </button>
                <button className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
                  Contact Partner
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};