import React, { useState } from 'react';
import { 
  HandshakeIcon, 
  CheckCircle, 
  Building2, 
  Truck, 
  Shield,
  MapPin,
  Mail,
  Phone,
  Send,
  FileText,
  Eye,
  Users,
  Wrench,
  RefreshCw
} from 'lucide-react';

export const BecomePartnerPage: React.FC = () => {
  const [formData, setFormData] = useState({
    companyName: '',
    contactName: '',
    email: '',
    phone: '',
    address: '',
    companyType: '',
    services: [],
    operatingRegions: '',
    experience: '',
    certifications: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const partnerBenefits = [
    {
      title: "Increased Visibility",
      description: "Get featured in our partner directory and gain exposure to thousands of potential clients",
      icon: Eye
    },
    {
      title: "Direct Referrals",
      description: "Receive qualified leads directly matched to your expertise and service area",
      icon: Users
    },
    {
      title: "Premium Tools Access", 
      description: "Get access to our professional route planning and analysis tools",
      icon: Wrench // Changed from Tool to Wrench
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Here you would send the form data to your backend
      await new Promise(resolve => setTimeout(resolve, 1000));
      alert('Thank you for your interest! We will contact you shortly.');
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('There was an error submitting your request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Become a Partner
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Join our network of professional service providers and grow your business
          </p>
        </div>

        {/* Partner Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {partnerBenefits.map((benefit, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8">
              <benefit.icon className="h-8 w-8 text-[#ED4235] mb-4" />
              <h3 className="text-xl font-semibold mb-4">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>

        {/* Partner Application Form */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Partner Application</h2>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Company Name</label>
                <input
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Contact Name</label>
                <input
                  type="text"
                  value={formData.contactName}
                  onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Phone</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700">Address</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Company Type</label>
                <select
                  value={formData.companyType}
                  onChange={(e) => setFormData({ ...formData, companyType: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  required
                >
                  <option value="">Select type</option>
                  <option value="surveyor">Route Surveyor</option>
                  <option value="escort">Pilot Car Service</option>
                  <option value="permit">Permit Service</option>
                  <option value="carrier">Transport Company</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Operating Regions</label>
                <input
                  type="text"
                  value={formData.operatingRegions}
                  onChange={(e) => setFormData({ ...formData, operatingRegions: e.target.value })}
                  placeholder="e.g., Ontario, Quebec, New York"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Years of Experience</label>
                <input
                  type="text"
                  value={formData.experience}
                  onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Certifications</label>
                <input
                  type="text"
                  value={formData.certifications}
                  onChange={(e) => setFormData({ ...formData, certifications: e.target.value })}
                  placeholder="e.g., DOT Certified, Safety Training"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700">Additional Information</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
                />
              </div>
            </div>

            <div className="flex justify-end pt-6">
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-3 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50 flex items-center"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="animate-spin h-5 w-5 mr-2" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send className="h-5 w-5 mr-2" />
                    Submit Application
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};