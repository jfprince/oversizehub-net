import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { I18nextProvider } from 'react-i18next';
import i18n from './i18n/config';
import { AuthProvider } from './components/auth/AuthProvider';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Footer } from './components/Footer';
import MapView from './components/map/MapView';
import { LoginForm } from './components/auth/LoginForm';
import { SignUpForm } from './components/auth/SignUpForm';
import { UserProfile } from './components/profile/UserProfile';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { useAuth } from './components/auth/AuthProvider';
import { CompliancePage } from './components/features/CompliancePage';
import { SafetyPage } from './components/features/SafetyPage';
import { TeamCollaborationPage } from './components/features/TeamCollaborationPage';
import { RoadSurveyPage } from './components/services/RoadSurveyPage';
import { DesktopSurveyPage } from './components/services/DesktopSurveyPage';
import { TruckingQuotePage } from './components/services/TruckingQuotePage';
import { SupportPage } from './components/resources/SupportPage';
import { FAQsPage } from './components/resources/FAQsPage';
import { BecomePartnerPage } from './components/partners/BecomePartnerPage';
import { FindPartnerPage } from './components/partners/FindPartnerPage';
import { Pricing } from './components/Pricing';

// Create a new QueryClient instance
const queryClient = new QueryClient();

const ProtectedRoute: React.FC<{ 
  children: React.ReactNode;
  requireAdmin?: boolean;
}> = ({ children, requireAdmin = false }) => {
  const { user, loading, isAdmin } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F7F9]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#79B3D2]"></div>
      </div>
    );
  }
  
  if (!user || (requireAdmin && !isAdmin)) {
    return <LoginForm />;
  }
  
  return <>{children}</>;
};

const App: React.FC = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nextProvider i18n={i18n}>
        <AuthProvider>
          <Router>
            <div className="min-h-screen bg-[#4B4947] flex flex-col">
              <Navbar />
              <main className="flex-grow">
                <Routes>
                  <Route path="/" element={
                    <>
                      <Hero />
                      <Features />
                      <Pricing />
                    </>
                  } />
                  <Route path="/pricing" element={<Pricing />} />
                  <Route path="/features/compliance" element={<CompliancePage />} />
                  <Route path="/features/safety" element={<SafetyPage />} />
                  <Route path="/features/team-collaboration" element={<TeamCollaborationPage />} />
                  <Route path="/services/road-survey" element={<RoadSurveyPage />} />
                  <Route path="/services/desktop-survey" element={<DesktopSurveyPage />} />
                  <Route path="/services/trucking-quote" element={<TruckingQuotePage />} />
                  <Route path="/resources/support" element={<SupportPage />} />
                  <Route path="/resources/faqs" element={<FAQsPage />} />
                  <Route path="/partners/join" element={<BecomePartnerPage />} />
                  <Route path="/partners/find" element={<FindPartnerPage />} />
                  <Route 
                    path="/map" 
                    element={
                      <ProtectedRoute>
                        <MapView />
                      </ProtectedRoute>
                    } 
                  />
                  <Route 
                    path="/profile" 
                    element={
                      <ProtectedRoute>
                        <UserProfile />
                      </ProtectedRoute>
                    } 
                  />
                  <Route 
                    path="/admin" 
                    element={
                      <ProtectedRoute requireAdmin>
                        <AdminDashboard />
                      </ProtectedRoute>
                    } 
                  />
                  <Route path="/login" element={<LoginForm />} />
                  <Route path="/signup" element={<SignUpForm />} />
                </Routes>
              </main>
              <Footer />
            </div>
          </Router>
        </AuthProvider>
      </I18nextProvider>
    </QueryClientProvider>
  );
};

export default App;