import React from 'react';
import { useTranslation } from 'react-i18next';
import { Globe } from 'lucide-react';

export const LanguageSelector: React.FC = () => {
  const { i18n } = useTranslation();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'fr' : 'en';
    i18n.changeLanguage(newLang);
    localStorage.setItem('i18nextLng', newLang);
  };

  return (
    <button
      onClick={toggleLanguage}
      className="flex items-center space-x-2 text-gray-600 hover:text-[#ED4235] transition-colors px-3 py-2 rounded-md"
    >
      <Globe className="h-5 w-5" />
      <span>{i18n.language === 'en' ? 'Français' : 'English'}</span>
    </button>
  );
};