import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { Logo } from './ui/Logo';
import { footerItems } from './navigation/config/footerItems';

export const Footer: React.FC = () => {
  const { t } = useTranslation();

  const renderFooterLink = (item: { label: string; href: string; external?: boolean; disabled?: boolean }) => {
    if (item.disabled) {
      return (
        <span className="text-gray-400 cursor-not-allowed">
          {item.label}
        </span>
      );
    }

    if (item.external) {
      return (
        <a
          href={item.href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-gray-600 hover:text-[#ED4235] transition-colors"
        >
          {item.label}
        </a>
      );
    }

    return (
      <Link
        to={item.href}
        className="text-gray-600 hover:text-[#ED4235] transition-colors"
      >
        {item.label}
      </Link>
    );
  };

  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {footerItems.map((section, index) => (
            <div key={index}>
              <h3 className="text-lg font-semibold mb-4 text-[#ED4235] flex items-center">
                <section.icon className="h-4 w-4 mr-2" />
                {section.title}
              </h3>
              <ul className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <li key={itemIndex}>
                    {renderFooterLink(item)}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Logo and Description */}
        <div className="mt-16 flex flex-col items-center text-center">
          <Logo className="mb-6" />
          <p className="text-gray-600 max-w-2xl">
            Professional solutions for heavy transport and advanced route planning. 
            Empowering transport professionals with cutting-edge tools for efficient 
            and compliant oversized load management.
          </p>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-200 mt-12 pt-8 text-center text-gray-600">
          <p>© {new Date().getFullYear()} OversizeHub. All rights reserved. Powered by <a href="https://soltec.ca" className="text-[#ED4235] hover:text-[#ED4235]/90 transition-colors">SolTec.ca</a> and in collaboration with <a href="https://novapermits.com/" target="_blank" rel="noopener noreferrer" className="text-[#ED4235] hover:text-[#ED4235]/90 transition-colors">Nova Permits</a></p>
        </div>
      </div>
    </footer>
  );
};