import React from 'react';
import { NavItem } from './NavItem';
import { mainNavItems } from './config/mainNavItems';
import { LanguageSelector } from '../LanguageSelector';

export const MainNav: React.FC = () => {
  return (
    <nav className="flex items-center justify-end space-x-4">
      {mainNavItems.map((item) => (
        <NavItem key={item.id} item={item} />
      ))}
      <LanguageSelector />
    </nav>
  );
};