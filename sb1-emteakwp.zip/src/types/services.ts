import { LucideIcon } from 'lucide-react';

export interface ServiceProvider {
  id: string;
  name: string;
  company: string;
  rating: number;
  reviews: number;
  regions: string[];
  services: string[];
  availability: string;
  experience: string;
  certifications: string[];
  description: string;
  specialties: string[];
  availabilityCalendar?: {
    [date: string]: {
      available: boolean;
      slots: string[];
    };
  };
  pricing?: {
    baseRate: number;
    currency: string;
    unit: string;
  };
  equipment?: string[];
  insuranceInfo?: {
    provider: string;
    coverage: number;
    expiryDate: string;
  };
  contactInfo: {
    phone: string;
    email: string;
    website?: string;
  };
  location: {
    address: string;
    coordinates: [number, number];
  };
  operatingHours: {
    [key: string]: string;
  };
}

export interface ServiceFeature {
  title: string;
  description: string;
  icon: LucideIcon;
  benefits: string[];
}

export interface ServiceCategory {
  id: string;
  name: string;
  description: string;
  features: ServiceFeature[];
  providers: ServiceProvider[];
}