import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { I18nextProvider } from 'react-i18next';
import i18n from './i18n/config';
import { AuthProvider } from './components/auth/AuthProvider';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Footer } from './components/Footer';
import MapView from './components/map/MapView';
import { LoginForm } from './components/auth/LoginForm';
import { SignUpForm } from './components/auth/SignUpForm';
import { UserProfile } from './components/profile/UserProfile';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Pricing } from './components/Pricing';
import { ContactPage } from './components/contact/ContactPage';
import { FAQsPage } from './components/resources/FAQsPage';
import { SupportPage } from './components/resources/SupportPage';
import { RoadSurveyPage } from './components/services/RoadSurveyPage';
import { DesktopSurveyPage } from './components/services/DesktopSurveyPage';
import { TruckingQuotePage } from './components/services/TruckingQuotePage';
import { BorderCrossingPage } from './components/features/BorderCrossingPage';
import { CompliancePage } from './components/features/CompliancePage';
import { SafetyPage } from './components/features/SafetyPage';
import { TeamCollaborationPage } from './components/features/TeamCollaborationPage';
import { EscortServicesPage } from './components/features/EscortServicesPage';
import { PermitManagementPage } from './components/features/PermitManagementPage';
import { RailServicesPage } from './components/services/RailServicesPage';
import { BargeServicesPage } from './components/services/BargeServicesPage';
import { PublicUtilitiesPage } from './components/services/PublicUtilitiesPage';
import { TechnicalServicesPage } from './components/services/TechnicalServicesPage';
import { EmergencyProceduresPage } from './components/emergency/EmergencyProceduresPage';
import { CostSimulatorPage } from './components/simulators/CostSimulatorPage';
import { StayUpdatedPage } from './components/updates/StayUpdatedPage';
import { StrategicPartnersPage } from './components/partners/StrategicPartnersPage';
import { FindPartnerPage } from './components/partners/FindPartnerPage';
import { BecomePartnerPage } from './components/partners/BecomePartnerPage';

const queryClient = new QueryClient();

const App: React.FC = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nextProvider i18n={i18n}>
        <AuthProvider>
          <Router>
            <div className="min-h-screen bg-[#4B4947] flex flex-col">
              <Navbar />
              <main className="flex-grow">
                <Routes>
                  <Route path="/" element={
                    <>
                      <Hero />
                      <Features />
                      <Pricing />
                    </>
                  } />
                  <Route path="/map/*" element={<MapView />} />
                  <Route path="/login" element={<LoginForm />} />
                  <Route path="/signup" element={<SignUpForm />} />
                  <Route path="/profile" element={<UserProfile />} />
                  <Route path="/admin" element={<AdminDashboard />} />
                  <Route path="/contact" element={<ContactPage />} />
                  <Route path="/resources/faqs" element={<FAQsPage />} />
                  <Route path="/resources/support" element={<SupportPage />} />
                  <Route path="/resources/emergency" element={<EmergencyProceduresPage />} />
                  <Route path="/resources/simulators" element={<CostSimulatorPage />} />
                  <Route path="/services/road-survey" element={<RoadSurveyPage />} />
                  <Route path="/services/desktop-survey" element={<DesktopSurveyPage />} />
                  <Route path="/services/quote" element={<TruckingQuotePage />} />
                  <Route path="/services/border" element={<BorderCrossingPage />} />
                  <Route path="/services/compliance" element={<CompliancePage />} />
                  <Route path="/services/safety" element={<SafetyPage />} />
                  <Route path="/services/collaboration" element={<TeamCollaborationPage />} />
                  <Route path="/services/escort" element={<EscortServicesPage />} />
                  <Route path="/services/permit-management" element={<PermitManagementPage />} />
                  <Route path="/services/rail" element={<RailServicesPage />} />
                  <Route path="/services/barge" element={<BargeServicesPage />} />
                  <Route path="/services/utilities" element={<PublicUtilitiesPage />} />
                  <Route path="/services/technical" element={<TechnicalServicesPage />} />
                  <Route path="/partners/find" element={<FindPartnerPage />} />
                  <Route path="/partners/join" element={<BecomePartnerPage />} />
                  <Route path="/partners/strategic" element={<StrategicPartnersPage />} />
                  <Route path="/updates" element={<StayUpdatedPage />} />
                </Routes>
              </main>
              <Footer />
            </div>
          </Router>
        </AuthProvider>
      </I18nextProvider>
    </QueryClientProvider>
  );
};

export default App;