export const MAPBOX_TOKEN = 'pk.eyJ1IjoiamZwcmluY2UiLCJhIjoiY200YTFhNzVlMDJ0ZTJrcTBuYWozazQwdiJ9.BpsA45NKl95L-D_2Mwqyqg';

export const MAPBOX_STYLES = {
  STREETS: 'mapbox://styles/mapbox/streets-v12',
  SATELLITE: 'mapbox://styles/mapbox/satellite-streets-v12',
  NAVIGATION: 'mapbox://styles/mapbox/navigation-night-v1',
};

export const DEFAULT_CENTER = [-73.5673, 45.5017]; // Montreal
export const DEFAULT_ZOOM = 12;