import { db } from '../firebase';
import { collection, doc, setDoc, getDocs, writeBatch, serverTimestamp, getDoc } from 'firebase/firestore';
import { COLLECTIONS, ADMIN_EMAIL } from './constants';
import { DatabaseError } from './errors';

export const initializeDatabase = async () => {
  const batch = writeBatch(db);

  try {
    // Initialize system settings
    await setDoc(doc(db, COLLECTIONS.SETTINGS, 'system'), {
      maxRoutesPerUser: 1000,
      requireEmailVerification: true,
      security: {
        passwordMinLength: 8,
        requireSpecialChars: true,
        sessionTimeout: 3600,
        maxLoginAttempts: 5,
        lockoutDuration: 900
      },
      maps: {
        defaultCenter: [-73.5673, 45.5017],
        defaultZoom: 12,
        maxOfflineArea: 100,
        providers: ['mapbox', 'google']
      },
      maintenance: {
        isEnabled: false
      },
      version: '1.0.0',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    }, { merge: true });

    // Ensure admin user exists
    await setDoc(doc(db, COLLECTIONS.USERS, 'admin'), {
      email: ADMIN_EMAIL,
      displayName: 'Admin',
      firstName: 'Admin',
      lastName: 'User',
      accountType: 'admin',
      role: 'admin',
      professional: {
        companyName: 'OversizeHub',
        jobTitle: 'System Administrator',
        companyType: 'admin',
        yearsExperience: 0,
        certifications: []
      },
      settings: {
        notifications: true,
        language: 'en',
        theme: 'light'
      },
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    }, { merge: true });

    // Initialize collections with config documents
    for (const collectionName of Object.values(COLLECTIONS)) {
      const configRef = doc(collection(db, collectionName), '_config');
      batch.set(configRef, {
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        version: '1.0.0'
      });
    }

    await batch.commit();

    return {
      success: true,
      collections: Object.values(COLLECTIONS),
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    throw new DatabaseError('Failed to initialize database', (error as Error).message);
  }
};

export const resetDatabase = async () => {
  try {
    // Delete all documents in each collection except admin user
    for (const collectionName of Object.values(COLLECTIONS)) {
      const collectionRef = collection(db, collectionName);
      const snapshot = await getDocs(collectionRef);
      
      const batch = writeBatch(db);
      snapshot.docs.forEach((doc) => {
        // Preserve admin user document
        if (!(collectionName === COLLECTIONS.USERS && doc.id === 'admin')) {
          batch.delete(doc.ref);
        }
      });
      
      await batch.commit();
    }

    // Reinitialize the database
    return await initializeDatabase();
  } catch (error) {
    throw new DatabaseError('Failed to reset database', (error as Error).message);
  }
};

export const verifyDatabase = async () => {
  const results = {
    collections: {} as Record<string, boolean>,
    adminUser: false,
    systemSettings: false,
    errors: [] as string[]
  };

  try {
    // Verify collections
    for (const collectionName of Object.values(COLLECTIONS)) {
      try {
        const collectionRef = collection(db, collectionName);
        const snapshot = await getDocs(collectionRef);
        results.collections[collectionName] = !snapshot.empty;
      } catch (error) {
        results.errors.push(`Failed to verify collection ${collectionName}`);
      }
    }

    // Verify admin user
    try {
      const adminDoc = await getDoc(doc(db, COLLECTIONS.USERS, 'admin'));
      if (adminDoc.exists()) {
        const adminData = adminDoc.data();
        results.adminUser = adminData.role === 'admin' && adminData.email === ADMIN_EMAIL;
      }
    } catch (error) {
      results.errors.push('Failed to verify admin user');
    }

    // Verify system settings
    try {
      const settingsDoc = await getDoc(doc(db, COLLECTIONS.SETTINGS, 'system'));
      results.systemSettings = settingsDoc.exists();
    } catch (error) {
      results.errors.push('Failed to verify system settings');
    }

    return results;
  } catch (error) {
    throw new DatabaseError('Failed to verify database', (error as Error).message);
  }
};