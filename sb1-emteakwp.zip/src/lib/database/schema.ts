import { Timestamp } from 'firebase/firestore';

export interface BaseSchema {
  id: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface UserSchema extends BaseSchema {
  email: string;
  displayName?: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  address?: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
  };
  role: 'user' | 'admin';
  accountType: 'personal' | 'business' | 'admin';
  professional?: {
    companyName: string;
    jobTitle: string;
    companyType: string;
    yearsExperience: number;
    certifications: string[];
  };
  logistics?: {
    fleetDetails: {
      vehicleTypes: string[];
      totalVehicles: number;
    };
    specialties: string[];
    maxDimensions: {
      length: number;
      width: number;
      height: number;
      weight: number;
    };
    routingExpertise: string[];
  };
  compliance?: {
    permitTypes: string[];
    insuranceInfo: {
      provider: string;
      policyNumber: string;
      coverage: number;
      expiryDate: Timestamp;
    };
  };
  settings?: {
    notifications: boolean;
    language: string;
    theme: 'light' | 'dark';
  };
}

export interface RouteSchema extends BaseSchema {
  userId: string;
  name: string;
  description?: string;
  origin: {
    address: string;
    coordinates: [number, number];
  };
  destination: {
    address: string;
    coordinates: [number, number];
  };
  waypoints: Array<{
    address: string;
    coordinates: [number, number];
  }>;
  routeData: any;
  vehicleType: string;
  routeType: string;
  isPublic: boolean;
  metadata?: {
    distance: number;
    duration: number;
    restrictions?: {
      height?: number;
      width?: number;
      weight?: number;
    };
  };
}

export interface SystemSettingsSchema extends BaseSchema {
  maxRoutesPerUser: number;
  requireEmailVerification: boolean;
  security: {
    passwordMinLength: number;
    requireSpecialChars: boolean;
    sessionTimeout: number;
    maxLoginAttempts: number;
    lockoutDuration: number;
  };
  maps: {
    defaultCenter: [number, number];
    defaultZoom: number;
    maxOfflineArea: number;
    providers: string[];
  };
  maintenance: {
    isEnabled: boolean;
    message?: string;
    scheduledStart?: Timestamp;
    scheduledEnd?: Timestamp;
  };
  version: string;
}

export interface DatabaseSchema {
  users: UserSchema;
  routes: RouteSchema;
  settings: SystemSettingsSchema;
}