import React, { useState } from 'react';
import { Mail, Bell, Smartphone } from 'lucide-react';

export const UpdatesForm: React.FC = () => {
  const [formData, setFormData] = useState({
    email: '',
    phone: '',
    name: '',
    company: '',
    notificationTypes: [] as string[]
  });

  const notificationTypes = [
    'Service Updates',
    'Industry News',
    'Regulatory Changes',
    'Safety Alerts',
    'Price Changes',
    'System Maintenance'
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Subscribe to Updates</h2>
      
      <form className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Company</label>
            <input
              type="text"
              value={formData.company}
              onChange={(e) => setFormData({ ...formData, company: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="pl-10 block w-full rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Phone (Optional)</label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Smartphone className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="pl-10 block w-full rounded-md border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]"
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-3">Update Types</h3>
          <div className="grid grid-cols-2 gap-4">
            {notificationTypes.map((type) => (
              <label key={type} className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.notificationTypes.includes(type)}
                  onChange={(e) => {
                    const types = e.target.checked
                      ? [...formData.notificationTypes, type]
                      : formData.notificationTypes.filter(t => t !== type);
                    setFormData({ ...formData, notificationTypes: types });
                  }}
                  className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
                />
                <span className="ml-2 text-sm text-gray-700">{type}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
          >
            Subscribe
          </button>
        </div>
      </form>
    </div>
  );
};