import React from 'react';
import { Settings, Bell, Mail, Smartphone } from 'lucide-react';

export const UpdatesPreferences: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Notification Preferences</h2>
      
      <div className="space-y-6">
        <div>
          <h3 className="text-sm font-medium text-gray-700 flex items-center">
            <Mail className="h-4 w-4 mr-2" />
            Email Notifications
          </h3>
          <div className="mt-2 space-y-2">
            <label className="flex items-center">
              <input
                type="checkbox"
                className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
              />
              <span className="ml-2 text-sm text-gray-600">Daily Digest</span>
            </label>
            <label className="flex items-center">
              <input
                type="checkbox"
                className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
              />
              <span className="ml-2 text-sm text-gray-600">Immediate Updates</span>
            </label>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 flex items-center">
            <Smartphone className="h-4 w-4 mr-2" />
            Mobile Notifications
          </h3>
          <div className="mt-2 space-y-2">
            <label className="flex items-center">
              <input
                type="checkbox"
                className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
              />
              <span className="ml-2 text-sm text-gray-600">Push Notifications</span>
            </label>
            <label className="flex items-center">
              <input
                type="checkbox"
                className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
              />
              <span className="ml-2 text-sm text-gray-600">SMS Alerts</span>
            </label>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-700 flex items-center">
            <Bell className="h-4 w-4 mr-2" />
            Alert Types
          </h3>
          <div className="mt-2 space-y-2">
            <label className="flex items-center">
              <input
                type="checkbox"
                className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
              />
              <span className="ml-2 text-sm text-gray-600">Emergency Alerts</span>
            </label>
            <label className="flex items-center">
              <input
                type="checkbox"
                className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
              />
              <span className="ml-2 text-sm text-gray-600">Service Updates</span>
            </label>
          </div>
        </div>

        <button className="w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">
          Save Preferences
        </button>
      </div>
    </div>
  );
};