import React from 'react';
import { Bell, Mail, Smartphone, Rss } from 'lucide-react';

export const UpdatesHero: React.FC = () => {
  return (
    <div className="relative py-16 bg-gradient-to-r from-[#ED4235] to-red-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-white sm:text-5xl">
            Stay Updated
          </h1>
          <p className="mt-4 text-xl text-white text-opacity-90">
            Get the latest updates, news, and alerts from OversizeHub
          </p>
          <div className="mt-8 flex justify-center space-x-8">
            <div className="text-center">
              <Bell className="h-8 w-8 text-white mx-auto" />
              <p className="mt-2 text-sm text-white text-opacity-90">Notifications</p>
            </div>
            <div className="text-center">
              <Mail className="h-8 w-8 text-white mx-auto" />
              <p className="mt-2 text-sm text-white text-opacity-90">Email Updates</p>
            </div>
            <div className="text-center">
              <Smartphone className="h-8 w-8 text-white mx-auto" />
              <p className="mt-2 text-sm text-white text-opacity-90">Mobile Alerts</p>
            </div>
            <div className="text-center">
              <Rss className="h-8 w-8 text-white mx-auto" />
              <p className="mt-2 text-sm text-white text-opacity-90">RSS Feed</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};