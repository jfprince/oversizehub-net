import React from 'react';
import { Rss, Mail, Bell, Smartphone, Linkedin, Twitter } from 'lucide-react';

export const UpdatesChannels: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold text-gray-900 mb-6">Communication Channels</h2>
      
      <div className="space-y-4">
        <a
          href="#"
          className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <Mail className="h-5 w-5 text-[#ED4235]" />
          <span className="ml-3 text-gray-700">Email Newsletter</span>
        </a>

        <a
          href="#"
          className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <Bell className="h-5 w-5 text-[#ED4235]" />
          <span className="ml-3 text-gray-700">Web Notifications</span>
        </a>

        <a
          href="#"
          className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <Smartphone className="h-5 w-5 text-[#ED4235]" />
          <span className="ml-3 text-gray-700">Mobile App</span>
        </a>

        <a
          href="#"
          className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <Rss className="h-5 w-5 text-[#ED4235]" />
          <span className="ml-3 text-gray-700">RSS Feed</span>
        </a>

        <a
          href="#"
          className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <Linkedin className="h-5 w-5 text-[#ED4235]" />
          <span className="ml-3 text-gray-700">LinkedIn</span>
        </a>

        <a
          href="#"
          className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <Twitter className="h-5 w-5 text-[#ED4235]" />
          <span className="ml-3 text-gray-700">Twitter</span>
        </a>
      </div>
    </div>
  );
};