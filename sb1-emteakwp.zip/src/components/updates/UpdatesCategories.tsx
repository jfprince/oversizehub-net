import React from 'react';
import { Bell, Truck, Shield, FileText, DollarSign, Settings } from 'lucide-react';

export const UpdatesCategories: React.FC = () => {
  const categories = [
    {
      icon: Truck,
      title: "Service Updates",
      description: "Stay informed about changes and improvements to our services"
    },
    {
      icon: Shield,
      title: "Safety & Compliance",
      description: "Important updates about regulations and safety requirements"
    },
    {
      icon: FileText,
      title: "Industry News",
      description: "Latest developments in the heavy transport industry"
    },
    {
      icon: DollarSign,
      title: "Pricing Updates",
      description: "Changes to service rates and special offers"
    },
    {
      icon: Settings,
      title: "System Updates",
      description: "Platform maintenance and new feature announcements"
    },
    {
      icon: Bell,
      title: "Emergency Alerts",
      description: "Critical notifications and emergency information"
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6">Update Categories</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {categories.map((category) => (
          <div
            key={category.title}
            className="flex items-start p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <category.icon className="h-6 w-6 text-[#ED4235] mt-1" />
            <div className="ml-4">
              <h3 className="text-lg font-medium text-gray-900">{category.title}</h3>
              <p className="mt-1 text-sm text-gray-600">{category.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};