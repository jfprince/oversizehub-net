```tsx
import React from 'react';
import { DirectoryTemplate } from './DirectoryTemplate';
import { allServiceProviders } from '../../data/serviceProviders';

export const PartnerDirectoryPage: React.FC = () => {
  // Combine all providers into a single array
  const allProviders = Object.values(allServiceProviders).flat();

  return <DirectoryTemplate providers={allProviders} />;
};
```