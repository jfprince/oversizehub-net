import React, { useState } from 'react';
import { 
  Laptop, 
  Map, 
  Star, 
  Clock, 
  Calendar,
  FileText,
  Users,
  CheckCircle,
  AlertTriangle,
  DollarSign,
  Send
} from 'lucide-react';
import { DesktopSurveyForm } from './survey/desktop/DesktopSurveyForm';

interface Surveyor {
  id: string;
  name: string;
  company: string;
  rating: number;
  reviews: number;
  experience: string;
  specialties: string[];
  leadTime: string;
  price: string;
  availability: string;
}

export const DesktopSurveyPage: React.FC = () => {
  const [selectedSurveyor, setSelectedSurveyor] = useState<string | null>(null);
  const [showRequestForm, setShowRequestForm] = useState(false);

  const surveyors: Surveyor[] = [
    {
      id: '1',
      name: 'John Smith',
      company: 'Digital Route Analysis Inc.',
      rating: 4.9,
      reviews: 127,
      experience: '15+ years',
      specialties: ['Route Analysis', 'Bridge Clearance', 'Turn Radius'],
      leadTime: '2-3 business days',
      price: '$250',
      availability: 'Available next week'
    },
    {
      id: '2',
      name: 'Sarah Johnson',
      company: 'Precision Route Planning',
      rating: 4.8,
      reviews: 98,
      experience: '12+ years',
      specialties: ['Height Analysis', 'Weight Restrictions', 'Permit Requirements'],
      leadTime: '1-2 business days',
      price: '$275',
      availability: 'Available this week'
    },
    {
      id: '3',
      name: 'Michael Chen',
      company: 'Expert Route Solutions',
      rating: 4.95,
      reviews: 156,
      experience: '18+ years',
      specialties: ['Complex Routes', 'Multi-State Planning', 'Regulatory Compliance'],
      leadTime: '2-4 business days',
      price: '$300',
      availability: 'Available next week'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Desktop Survey Service
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Professional route analysis and planning from your desktop
          </p>
        </div>

        {/* Service Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <Map className="h-8 w-8 text-[#ED4235] mb-4" />
            <h3 className="text-xl font-semibold mb-4">Route Analysis</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>Detailed clearance analysis</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>Turn radius verification</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>Weight restriction check</span>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <Clock className="h-8 w-8 text-[#ED4235] mb-4" />
            <h3 className="text-xl font-semibold mb-4">Fast Turnaround</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>24-48 hour delivery</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>Priority processing</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>Real-time updates</span>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <FileText className="h-8 w-8 text-[#ED4235] mb-4" />
            <h3 className="text-xl font-semibold mb-4">Comprehensive Reports</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>Detailed documentation</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>Visual route maps</span>
              </li>
              <li className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <span>Permit requirements</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Surveyors List */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-16">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Available Surveyors</h2>
          </div>

          <div className="divide-y divide-gray-200">
            {surveyors.map((surveyor) => (
              <div key={surveyor.id} className="p-6 hover:bg-gray-50">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{surveyor.name}</h3>
                    <p className="text-sm text-gray-500">{surveyor.company}</p>
                    <div className="flex items-center mt-2">
                      <Star className="h-5 w-5 text-yellow-400" />
                      <span className="ml-1 text-sm font-medium">{surveyor.rating}</span>
                      <span className="ml-1 text-sm text-gray-500">({surveyor.reviews} reviews)</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-semibold text-[#ED4235]">{surveyor.price}</p>
                    <p className="text-sm text-gray-500">{surveyor.leadTime}</p>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="flex flex-wrap gap-2">
                    {surveyor.specialties.map((specialty) => (
                      <span
                        key={specialty}
                        className="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-800 rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6 flex justify-end space-x-4">
                  <button
                    onClick={() => {
                      setSelectedSurveyor(surveyor.id);
                      setShowRequestForm(true);
                    }}
                    className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 flex items-center"
                  >
                    <Calendar className="h-5 w-5 mr-2" />
                    Request Survey
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showRequestForm && <DesktopSurveyForm onClose={() => setShowRequestForm(false)} />}
    </div>
  );
};