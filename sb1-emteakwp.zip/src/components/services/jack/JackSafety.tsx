import React from 'react';
import { Shield, AlertTriangle, CheckCircle } from 'lucide-react';

export const JackSafety: React.FC = () => {
  const safetyMeasures = [
    {
      title: "Pre-Operation Safety",
      items: [
        "Site assessment and planning",
        "Equipment inspection",
        "Load calculation verification",
        "Safety briefing",
        "PPE requirements check"
      ]
    },
    {
      title: "Operation Safety",
      items: [
        "Continuous load monitoring",
        "Communication protocols",
        "Emergency procedures",
        "Safety zone maintenance",
        "Regular equipment checks"
      ]
    },
    {
      title: "Personnel Safety",
      items: [
        "Certified operators only",
        "Safety training verification",
        "Clear communication channels",
        "Emergency response team",
        "First aid provisions"
      ]
    }
  ];

  return (
    <div className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">
            Safety Protocols
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Comprehensive safety measures for every operation
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
          {safetyMeasures.map((measure) => (
            <div key={measure.title} className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Shield className="h-5 w-5 text-[#ED4235] mr-2" />
                {measure.title}
              </h3>
              <ul className="space-y-3">
                {measure.items.map((item) => (
                  <li key={item} className="flex items-center text-gray-600">
                    <CheckCircle className="h-5 w-5 text-[#ED4235] mr-2" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-yellow-50 rounded-lg p-6">
          <div className="flex items-start">
            <AlertTriangle className="h-6 w-6 text-yellow-400 mt-1" />
            <div className="ml-4">
              <h4 className="text-lg font-medium text-yellow-800">Safety First</h4>
              <p className="mt-2 text-yellow-700">
                All operations are conducted under strict safety protocols and supervision. Our team maintains the highest safety standards in the industry.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};