import React from 'react';
import { ArrowUpDown, Calculator, Shield, Phone } from 'lucide-react';

export const JackHero: React.FC = () => {
  return (
    <div className="relative py-20 overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1581094288338-2314dddb7ece?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80)',
        }}
      >
        <div className="absolute inset-0 bg-gray-900 opacity-75" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Jack & Slide Systems
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-300">
            Professional heavy load movement and positioning solutions
          </p>
          <div className="mt-10 flex justify-center space-x-6">
            <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-[#ED4235] hover:bg-opacity-90">
              <Calculator className="h-5 w-5 mr-2" />
              Get Quote
            </button>
            <button className="inline-flex items-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-gray-900">
              <Phone className="h-5 w-5 mr-2" />
              Contact Us
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};