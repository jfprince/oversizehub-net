import React from 'react';
import { ArrowUpDown, Tool, Shield, Users, FileCheck, Clock } from 'lucide-react';

export const JackFeatures: React.FC = () => {
  const features = [
    {
      icon: ArrowUpDown,
      title: "Precision Movement",
      description: "Accurate positioning and movement of heavy loads"
    },
    {
      icon: Tool,
      title: "Professional Equipment",
      description: "State-of-the-art hydraulic systems and slide tracks"
    },
    {
      icon: Shield,
      title: "Safety First",
      description: "Comprehensive safety protocols and certified operators"
    },
    {
      icon: Users,
      title: "Expert Team",
      description: "Experienced professionals for every project"
    },
    {
      icon: FileCheck,
      title: "Documentation",
      description: "Complete lift plans and engineering documentation"
    },
    {
      icon: Clock,
      title: "24/7 Service",
      description: "Round-the-clock availability for urgent projects"
    }
  ];

  return (
    <div className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Professional Jack & Slide Solutions
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Advanced equipment and expertise for heavy load movement
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="relative group bg-white p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-[#ED4235] rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <div>
                <span className="rounded-lg inline-flex p-3 bg-[#ED4235] bg-opacity-10">
                  <feature.icon className="h-6 w-6 text-[#ED4235]" />
                </span>
              </div>
              <div className="mt-8">
                <h3 className="text-lg font-medium">
                  <span className="absolute inset-0" aria-hidden="true" />
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm text-gray-500">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};