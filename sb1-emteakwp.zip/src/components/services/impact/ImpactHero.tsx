import React from 'react';
import { Zap, Shield, BarChart2, Smartphone } from 'lucide-react';

export const ImpactHero: React.FC = () => {
  return (
    <div className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-gray-900 to-gray-800" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Impact Recording Solutions
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-300">
            Professional impact monitoring and analysis for sensitive cargo transport
          </p>
          <div className="mt-10 flex justify-center space-x-6">
            <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-[#ED4235] hover:bg-opacity-90">
              Request Demo
            </button>
            <button className="inline-flex items-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white hover:bg-opacity-10">
              View Equipment
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};