import React from 'react';
import { Check } from 'lucide-react';

interface QuoteStepsProps {
  currentStep: number;
}

export const QuoteSteps: React.FC<QuoteStepsProps> = ({ currentStep }) => {
  const steps = [
    { label: 'Route Details', description: 'Origin and destination' },
    { label: 'Load Information', description: 'Dimensions and requirements' },
    { label: 'Contact Details', description: 'Your information' }
  ];

  return (
    <div className="mb-8">
      <div className="flex justify-between">
        {steps.map((step, index) => (
          <div
            key={index}
            className={`flex items-center ${
              index < currentStep
                ? 'text-[#ED4235]'
                : index === currentStep
                ? 'text-[#ED4235]'
                : 'text-gray-300'
            }`}
          >
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center ${
                index <= currentStep ? 'bg-[#ED4235] text-white' : 'bg-gray-100'
              }`}
            >
              {index < currentStep ? (
                <Check className="h-6 w-6" />
              ) : (
                index + 1
              )}
            </div>
            <div className="ml-3 hidden md:block">
              <p className="text-sm font-medium">{step.label}</p>
              <p className="text-xs text-gray-500">{step.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};