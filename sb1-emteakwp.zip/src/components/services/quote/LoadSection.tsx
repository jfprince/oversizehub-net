import React from 'react';
import { 
  Shield, 
  Truck, 
  AlertTriangle, 
  Zap, 
  Navigation, 
  Ruler,
  Package
} from 'lucide-react';
import { TrailerSelection } from './TrailerSelection';
import { MultiLoadForm } from './MultiLoadForm';

interface LoadSectionProps {
  formData: {
    loadType: string;
    dimensions: {
      length: string;
      width: string;
      height: string;
      weight: string;
    };
    specialRequirements: {
      basic: string[];
      services: {
        specialPermit: boolean;
        pilotCar: boolean;
        cseEscort: boolean;
        policeEscort: boolean;
        publicUtilities: boolean;
        impactRecorder: boolean;
        turningRadiusSimulation: boolean;
        roadSurvey: boolean;
      };
    };
    isMultiLoad: boolean;
    additionalLoads: Array<{
      origin: string;
      destination: string;
      dimensions: {
        length: string;
        width: string;
        height: string;
        weight: string;
      };
    }>;
  };
  onChange: (formData: any) => void;
}

export const LoadSection: React.FC<LoadSectionProps> = ({ formData, onChange }) => {
  const loadTypes = [
    'General Freight',
    'Heavy Equipment',
    'Construction Materials',
    'Industrial Machinery',
    'Wind Energy Components',
    'Modular Buildings',
    'Other'
  ];

  return (
    <div className="space-y-6">
      {/* Load Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <Package className="h-4 w-4 inline mr-2" />
          Load Type
        </label>
        <select
          value={formData.loadType}
          onChange={(e) => onChange({ ...formData, loadType: e.target.value })}
          className="w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        >
          <option value="">Select load type</option>
          {loadTypes.map((type) => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>

      {/* Multiple Loads Option */}
      <div>
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={formData.isMultiLoad}
            onChange={(e) => onChange({ ...formData, isMultiLoad: e.target.checked })}
            className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
          />
          <span className="text-sm text-gray-700">Multiple loads/shipments</span>
        </label>
      </div>

      <TrailerSelection
        value={formData.loadType}
        onChange={(value) => onChange({ ...formData, loadType: value })}
      />

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Length (ft)</label>
          <input
            type="number"
            value={formData.dimensions.length}
            onChange={(e) => onChange({
              ...formData,
              dimensions: { ...formData.dimensions, length: e.target.value }
            })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Width (ft)</label>
          <input
            type="number"
            value={formData.dimensions.width}
            onChange={(e) => onChange({
              ...formData,
              dimensions: { ...formData.dimensions, width: e.target.value }
            })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Height (ft)</label>
          <input
            type="number"
            value={formData.dimensions.height}
            onChange={(e) => onChange({
              ...formData,
              dimensions: { ...formData.dimensions, height: e.target.value }
            })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Weight (lbs)</label>
          <input
            type="number"
            value={formData.dimensions.weight}
            onChange={(e) => onChange({
              ...formData,
              dimensions: { ...formData.dimensions, weight: e.target.value }
            })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
          />
        </div>
      </div>

      {/* Additional Loads Form */}
      {formData.isMultiLoad && (
        <MultiLoadForm
          loads={formData.additionalLoads}
          onAddLoad={() => onChange({
            ...formData,
            additionalLoads: [
              ...formData.additionalLoads,
              {
                origin: '',
                destination: '',
                dimensions: { length: '', width: '', height: '', weight: '' }
              }
            ]
          })}
          onRemoveLoad={(index) => onChange({
            ...formData,
            additionalLoads: formData.additionalLoads.filter((_, i) => i !== index)
          })}
          onUpdateLoad={(index, load) => onChange({
            ...formData,
            additionalLoads: formData.additionalLoads.map((l, i) => i === index ? load : l)
          })}
        />
      )}

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Special Requirements</label>
        <div className="space-y-4">
          {/* Basic Requirements */}
          <div className="space-y-2">
            {[
              'Tarps Required',
              'Chains Required',
              'Team Drivers',
              'Lift Gate',
              'Inside Delivery',
              'Residential Delivery'
            ].map((requirement) => (
              <label key={requirement} className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.specialRequirements.basic.includes(requirement)}
                  onChange={(e) => {
                    const newRequirements = e.target.checked
                      ? [...formData.specialRequirements.basic, requirement]
                      : formData.specialRequirements.basic.filter(r => r !== requirement);
                    onChange({
                      ...formData,
                      specialRequirements: {
                        ...formData.specialRequirements,
                        basic: newRequirements
                      }
                    });
                  }}
                  className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
                />
                <span className="ml-2 text-sm text-gray-700">{requirement}</span>
              </label>
            ))}
          </div>

          {/* Additional Services */}
          <div className="border-t pt-4">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Additional Services</h4>
            <div className="grid grid-cols-2 gap-4">
              {[
                { key: 'specialPermit', label: 'Special Permit', icon: Shield },
                { key: 'pilotCar', label: 'Pilot Car', icon: Truck },
                { key: 'cseEscort', label: 'CSE Escort', icon: Shield },
                { key: 'policeEscort', label: 'Police Escort', icon: AlertTriangle },
                { key: 'publicUtilities', label: 'Public Utilities', icon: Zap },
                { key: 'impactRecorder', label: 'Impact Recorder', icon: Zap },
                { key: 'turningRadiusSimulation', label: 'Turning Radius Simulation', icon: Navigation },
                { key: 'roadSurvey', label: 'Road Survey', icon: Ruler }
              ].map(({ key, label, icon: Icon }) => (
                <label key={key} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.specialRequirements.services[key as keyof typeof formData.specialRequirements.services]}
                    onChange={(e) => {
                      onChange({
                        ...formData,
                        specialRequirements: {
                          ...formData.specialRequirements,
                          services: {
                            ...formData.specialRequirements.services,
                            [key]: e.target.checked
                          }
                        }
                      });
                    }}
                    className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
                  />
                  <Icon className="h-4 w-4 mx-2 text-gray-500" />
                  <span className="text-sm text-gray-700">{label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};