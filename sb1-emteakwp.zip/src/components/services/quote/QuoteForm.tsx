import React, { useState } from 'react';
import { Clock, Send, Calculator, Cpu, DollarSign } from 'lucide-react';
import { QuoteSteps } from './QuoteSteps';
import { QuoteIntro } from './QuoteIntro';
import { QuoteInfo } from './QuoteInfo';
import { CarrierSelection } from './CarrierSelection';
import { RouteSection } from './RouteSection';
import { LoadSection } from './LoadSection';
import { ContactBillingSection } from './ContactBillingSection';
import { useQuoteForm } from './hooks/useQuoteForm';

export const QuoteForm: React.FC = () => {
  const { formData, setFormData, handleSubmit, isSubmitting } = useQuoteForm();
  const [step, setStep] = useState(1);
  const [showCarrierSelection, setShowCarrierSelection] = useState(true);
  const [budgetaryPrice, setBudgetaryPrice] = useState<number | null>(null);
  const [aiPrice, setAiPrice] = useState<number | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculateBudgetaryPrice = async () => {
    setIsCalculating(true);
    try {
      // Simulate API call - replace with actual calculation logic
      await new Promise(resolve => setTimeout(resolve, 1500));
      const baseRate = 2.5; // $/mile
      const distance = 500; // miles (replace with actual distance calculation)
      const price = Math.round(baseRate * distance);
      setBudgetaryPrice(price);
    } catch (error) {
      console.error('Error calculating budgetary price:', error);
      alert('Failed to calculate budgetary price. Please try again.');
    } finally {
      setIsCalculating(false);
    }
  };

  const calculateAiPrice = async () => {
    setIsCalculating(true);
    try {
      // Simulate AI API call - replace with actual AI pricing model
      await new Promise(resolve => setTimeout(resolve, 2000));
      const basePrice = budgetaryPrice || 1250;
      const adjustmentFactor = 0.85 + (Math.random() * 0.3); // Random adjustment between -15% and +15%
      const aiEstimate = Math.round(basePrice * adjustmentFactor);
      setAiPrice(aiEstimate);
    } catch (error) {
      console.error('Error calculating AI price:', error);
      alert('Failed to calculate AI price estimate. Please try again.');
    } finally {
      setIsCalculating(false);
    }
  };

  return (
    <>
      {/* Introduction */}
      <QuoteIntro />

      {/* Quote Form */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="p-8">
          {/* Progress Steps */}
          <QuoteSteps currentStep={step} />

          <form onSubmit={handleSubmit} className="mt-8 space-y-8">
            {step === 1 && (
              <>
                {showCarrierSelection ? (
                  <CarrierSelection
                    selectedCarrier={formData.selectedCarrier}
                    onSelectCarrier={(carrierId) => {
                      setFormData({
                        ...formData,
                        selectedCarrier: carrierId,
                        requestMultipleQuotes: !carrierId
                      });
                      setShowCarrierSelection(false);
                    }}
                    onRequestMultiple={() => {
                      setFormData({
                        ...formData,
                        selectedCarrier: null,
                        requestMultipleQuotes: true
                      });
                      setShowCarrierSelection(false);
                    }}
                  />
                ) : (
                  <RouteSection 
                    formData={formData} 
                    onChange={setFormData} 
                  />
                )}
              </>
            )}

            {step === 2 && (
              <LoadSection 
                formData={formData} 
                onChange={setFormData} 
              />
            )}

            {step === 3 && (
              <ContactBillingSection 
                formData={formData} 
                onChange={setFormData} 
              />
            )}

            {/* Price Estimation Section */}
            {step === 3 && (
              <div className="mt-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Budgetary Price */}
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-medium text-gray-900 flex items-center">
                        <Calculator className="h-5 w-5 text-[#ED4235] mr-2" />
                        Budgetary Price
                      </h3>
                      <button
                        type="button"
                        onClick={calculateBudgetaryPrice}
                        disabled={isCalculating}
                        className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
                      >
                        Calculate
                      </button>
                    </div>
                    {budgetaryPrice !== null && (
                      <div className="text-2xl font-bold text-gray-900">
                        ${budgetaryPrice.toLocaleString()}
                      </div>
                    )}
                  </div>

                  {/* AI Price Estimation */}
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-medium text-gray-900 flex items-center">
                        <Cpu className="h-5 w-5 text-[#ED4235] mr-2" />
                        AI Price Estimate
                      </h3>
                      <button
                        type="button"
                        onClick={calculateAiPrice}
                        disabled={isCalculating || budgetaryPrice === null}
                        className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
                      >
                        Get AI Estimate
                      </button>
                    </div>
                    {aiPrice !== null && (
                      <div className="text-2xl font-bold text-gray-900">
                        ${aiPrice.toLocaleString()}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-between pt-6">
              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep(step - 1)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Back
                </button>
              )}
              {step < 3 ? (
                <button
                  type="button"
                  onClick={() => setStep(step + 1)}
                  className="ml-auto px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
                >
                  Next
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="ml-auto px-6 py-3 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50 flex items-center"
                >
                  {isSubmitting ? (
                    <>
                      <Clock className="animate-spin h-5 w-5 mr-2" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <DollarSign className="h-5 w-5 mr-2" />
                      Get Quote
                    </>
                  )}
                </button>
              )}
            </div>
          </form>
        </div>
      </div>

      {/* Additional Information */}
      <QuoteInfo />
    </>
  );
};