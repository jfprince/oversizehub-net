import React from 'react';
import { CheckCircle, AlertTriangle } from 'lucide-react';

export const QuoteInfo: React.FC = () => {
  return (
    <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="bg-white rounded-xl shadow-lg p-6">
        <CheckCircle className="h-8 w-8 text-green-500 mb-4" />
        <h3 className="text-lg font-semibold mb-2">Why Choose Our Platform</h3>
        <ul className="space-y-2 text-gray-600">
          <li className="flex items-center">
            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
            Verified carriers with proven track records
          </li>
          <li className="flex items-center">
            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
            Competitive quotes from qualified providers
          </li>
          <li className="flex items-center">
            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
            Automated carrier matching based on requirements
          </li>
          <li className="flex items-center">
            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
            Secure and confidential quote process
          </li>
        </ul>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <AlertTriangle className="h-8 w-8 text-[#ED4235] mb-4" />
        <h3 className="text-lg font-semibold mb-2">Important Information</h3>
        <ul className="space-y-2 text-gray-600">
          <li className="flex items-start">
            <AlertTriangle className="h-4 w-4 text-[#ED4235] mr-2 mt-1" />
            All carriers are pre-screened for insurance and safety
          </li>
          <li className="flex items-start">
            <AlertTriangle className="h-4 w-4 text-[#ED4235] mr-2 mt-1" />
            Quotes are typically provided within 24 hours
          </li>
          <li className="flex items-start">
            <AlertTriangle className="h-4 w-4 text-[#ED4235] mr-2 mt-1" />
            Additional services may affect final pricing
          </li>
          <li className="flex items-start">
            <AlertTriangle className="h-4 w-4 text-[#ED4235] mr-2 mt-1" />
            Permits and escorts quoted separately if required
          </li>
        </ul>
      </div>
    </div>
  );
};