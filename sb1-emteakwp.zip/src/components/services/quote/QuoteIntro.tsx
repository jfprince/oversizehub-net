import React from 'react';
import { Building2, Shield, Clock } from 'lucide-react';

export const QuoteIntro: React.FC = () => {
  return (
    <>
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900">
          Get Your Trucking Quote
        </h1>
        <p className="mt-4 text-xl text-gray-600">
          Fast, reliable quotes for your oversized and heavy haul needs
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="bg-[#ED4235]/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
            <Building2 className="h-6 w-6 text-[#ED4235]" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Choose Your Carrier</h3>
          <p className="text-gray-600 text-sm">
            Select a specific carrier or get quotes from up to 3 qualified companies
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="bg-[#ED4235]/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
            <Shield className="h-6 w-6 text-[#ED4235]" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Verified Partners</h3>
          <p className="text-gray-600 text-sm">
            All carriers are pre-screened and verified for quality and reliability
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="bg-[#ED4235]/10 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
            <Clock className="h-6 w-6 text-[#ED4235]" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Quick Response</h3>
          <p className="text-gray-600 text-sm">
            Receive your quotes within 24 hours or less
          </p>
        </div>
      </div>
    </>
  );
};