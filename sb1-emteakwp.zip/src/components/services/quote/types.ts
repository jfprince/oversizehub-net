```typescript
export interface QuoteFormData {
  origin: string;
  destination: string;
  pickupDate: string;
  deliveryDate: string;
  dueDateForQuote: string;
  loadType: string;
  dimensions: {
    length: string;
    width: string;
    height: string;
    weight: string;
  };
  specialRequirements: {
    basic: string[];
    services: {
      specialPermit: boolean;
      pilotCar: boolean;
      cseEscort: boolean;
      policeEscort: boolean;
      publicUtilities: boolean;
      impactRecorder: boolean;
      turningRadiusSimulation: boolean;
      roadSurvey: boolean;
    };
  };
  contactInfo: {
    name: string;
    email: string;
    phone: string;
    company: string;
    address: {
      street: string;
      city: string;
      state: string;
      country: string;
      postalCode: string;
    };
  };
  billingInfo: {
    name: string;
    email: string;
    phone: string;
    company: string;
    address: {
      street: string;
      city: string;
      state: string;
      country: string;
      postalCode: string;
    };
    paymentTerms: 'net30' | 'net15' | 'cod' | 'prepaid';
    paymentType: 'creditCard' | 'bankTransfer' | 'check';
  };
  selectedCarrier: string | null;
  requestMultipleQuotes: boolean;
  isMultiLoad: boolean;
  additionalLoads: Array<{
    origin: string;
    destination: string;
    dimensions: {
      length: string;
      width: string;
      height: string;
      weight: string;
    };
  }>;
}
```