import React from 'react';
import { 
  Shield, 
  FileText, 
  Truck, 
  Map,
  Users,
  Clock
} from 'lucide-react';
import { ServicePageLayout } from './shared/ServicePageLayout';

export const SampleServicePage: React.FC = () => {
  // Sample service providers data
  const sampleProviders = [
    {
      id: 'SP1',
      name: 'Sample Provider 1',
      company: 'Sample Company Inc.',
      rating: 4.9,
      reviews: 156,
      regions: ['Ontario', 'Quebec', 'New York'],
      services: ['Service 1', 'Service 2', 'Service 3'],
      availability: 'Available Now',
      experience: '15+ years',
      certifications: ['Cert 1', 'Cert 2', 'Cert 3'],
      description: 'Leading provider of sample services.',
      specialties: ['Specialty 1', 'Specialty 2', 'Specialty 3'],
      contactInfo: {
        phone: '+1 (555) 123-4567',
        email: 'info@sample.com',
        website: 'www.sample.com'
      },
      location: {
        address: '123 Sample St, Toronto, ON',
        coordinates: [43.6532, -79.3832]
      },
      operatingHours: {
        'Monday-Friday': '8:00 AM - 6:00 PM'
      }
    }
  ];

  const services = [
    {
      title: "Service 1",
      icon: Shield,
      description: "Professional service description",
      features: [
        "Feature 1",
        "Feature 2",
        "Feature 3",
        "Feature 4"
      ]
    },
    {
      title: "Service 2",
      icon: Map,
      description: "Another service description",
      features: [
        "Feature 1",
        "Feature 2",
        "Feature 3",
        "Feature 4"
      ]
    },
    {
      title: "Service 3",
      icon: Truck,
      description: "Third service description",
      features: [
        "Feature 1",
        "Feature 2",
        "Feature 3",
        "Feature 4"
      ]
    },
    {
      title: "Service 4",
      icon: Users,
      description: "Fourth service description",
      features: [
        "Feature 1",
        "Feature 2",
        "Feature 3",
        "Feature 4"
      ]
    }
  ];

  return (
    <ServicePageLayout
      title="Sample Service"
      description="Professional sample services for your needs"
      services={services}
      providers={sampleProviders}
      serviceType="Sample"
      regulationLink="/services/compliance"
    />
  );
};