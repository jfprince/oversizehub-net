import React from 'react';
import { Ship, FileText, Shield, Map, Ruler } from 'lucide-react';
import { ServiceProviderList } from './shared/ServiceProviderList';
import { bargeServiceProviders } from '../../data/serviceProviders';

export const BargeServicesPage: React.FC = () => {
  const services = [
    {
      title: "Environmental Permit Applications",
      icon: Shield,
      description: "Complete environmental permit application assistance",
      features: [
        "Documentation preparation",
        "Regulatory compliance",
        "Application tracking",
        "Expert consultation"
      ]
    },
    {
      title: "Technical Drawings",
      icon: Ruler,
      description: "Professional technical drawing services",
      features: [
        "Detailed barge plans",
        "Load configurations",
        "3D modeling",
        "Technical specifications"
      ]
    },
    {
      title: "Ballast & Load Planning",
      icon: Map,
      description: "Comprehensive ballast and load planning",
      features: [
        "Weight distribution analysis",
        "Stability calculations",
        "Trim optimization",
        "Safety assessments"
      ]
    },
    {
      title: "Service Directory",
      icon: FileText,
      description: "Comprehensive directory of barge services",
      features: [
        "Verified providers",
        "Service ratings",
        "Contact information",
        "Availability status"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Barge Services
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Professional barge transport solutions and documentation
          </p>
        </div>

        {/* Service Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex items-center mb-6">
                <service.icon className="h-8 w-8 text-[#ED4235]" />
                <h3 className="ml-4 text-xl font-semibold text-gray-900">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <ul className="space-y-3">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-700">
                    <Ship className="h-5 w-5 text-[#ED4235] mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Service Providers Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">
            Barge Service Providers
          </h2>
          <ServiceProviderList 
            providers={bargeServiceProviders}
            serviceType="Barge"
          />
        </div>

        {/* Call to Action */}
        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Contact our barge services team for expert assistance with your water transport needs.
          </p>
          <button className="px-6 py-3 bg-[#ED4235] text-white rounded-xl hover:bg-opacity-90">
            Request Consultation
          </button>
        </div>
      </div>
    </div>
  );
};