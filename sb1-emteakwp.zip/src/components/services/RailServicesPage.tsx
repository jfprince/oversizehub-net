import React, { useState } from 'react';
import { Train, Shield, FileText, Users, Book, AlertTriangle, Search, Filter } from 'lucide-react';
import { ServiceProviderList } from './shared/ServiceProviderList';
import { railServiceProviders } from '../../data/serviceProviders';

export const RailServicesPage: React.FC = () => {
  const services = [
    {
      title: "CN Clearance Application",
      icon: Shield,
      description: "Complete clearance application process for CN rail crossings",
      features: [
        "Online application submission",
        "Document verification",
        "Real-time status tracking",
        "Expert assistance"
      ]
    },
    {
      title: "Load & Ballast Plans",
      icon: FileText,
      description: "Professional load and ballast planning services",
      features: [
        "Detailed load diagrams",
        "Weight distribution analysis",
        "Stability calculations",
        "Technical documentation"
      ]
    },
    {
      title: "eRailSafe Training",
      icon: Users,
      description: "Comprehensive eRailSafe certification training",
      features: [
        "Official certification program",
        "Interactive learning modules",
        "Safety protocols",
        "Compliance requirements"
      ]
    },
    {
      title: "Rail Safety Training",
      icon: AlertTriangle,
      description: "Essential rail safety training and certification",
      features: [
        "Safety procedures",
        "Emergency protocols",
        "Equipment operation",
        "Risk assessment"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Rail Services
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Comprehensive rail transport solutions and certifications
          </p>
        </div>

        {/* Service Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex items-center mb-6">
                <service.icon className="h-8 w-8 text-[#ED4235]" />
                <h3 className="ml-4 text-xl font-semibold text-gray-900">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <ul className="space-y-3">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-gray-700">
                    <Train className="h-5 w-5 text-[#ED4235] mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Service Providers Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">
            Rail Service Providers
          </h2>
          <ServiceProviderList 
            providers={railServiceProviders}
            serviceType="Rail"
          />
        </div>

        {/* Call to Action */}
        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Need Rail Transport Solutions?
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Contact our rail services team for expert assistance with your rail transport needs.
          </p>
          <button className="px-6 py-3 bg-[#ED4235] text-white rounded-xl hover:bg-opacity-90">
            Contact Rail Services Team
          </button>
        </div>
      </div>
    </div>
  );
};