import React from 'react';
import { 
  ArrowUpDown, 
  MoveHorizontal, 
  Shield, 
  Calculator,
  Wrench,
  Users
} from 'lucide-react';
import { ServicePageLayout } from './shared/ServicePageLayout';

export const JackSlidesPage: React.FC = () => {
  const services = [
    {
      title: "Jack & Slide Systems",
      icon: ArrowUpDown,
      description: "Professional heavy load movement solutions",
      features: [
        "Hydraulic jacking",
        "Slide systems",
        "Load monitoring",
        "Safety controls"
      ]
    },
    {
      title: "Engineering Support",
      icon: Calculator,
      description: "Comprehensive engineering and planning",
      features: [
        "Load calculations",
        "Site surveys",
        "Method statements",
        "Risk assessments"
      ]
    },
    {
      title: "Equipment Rental",
      icon: Wrench,
      description: "Professional equipment rental services",
      features: [
        "Certified equipment",
        "Technical support",
        "Maintenance included",
        "Emergency backup"
      ]
    },
    {
      title: "Operator Services",
      icon: Users,
      description: "Skilled operator and supervision services",
      features: [
        "Certified operators",
        "Project supervision",
        "Safety management",
        "24/7 support"
      ]
    }
  ];

  return (
    <ServicePageLayout
      title="Jack & Slides Services"
      description="Professional heavy load movement and positioning solutions"
      services={services}
      serviceType="jackSlides"
      regulationLink="/services/compliance"
    />
  );
};