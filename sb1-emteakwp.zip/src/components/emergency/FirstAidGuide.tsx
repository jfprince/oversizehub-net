import React from 'react';
import { Heart, AlertTriangle, ThermometerSun, Droplets, Stethoscope } from 'lucide-react';

export const FirstAidGuide: React.FC = () => {
  const firstAidSteps = [
    {
      condition: "Bleeding",
      icon: Droplets,
      steps: [
        "Apply direct pressure with clean cloth",
        "Elevate injured area if possible",
        "Apply pressure bandage",
        "Seek medical attention if severe"
      ]
    },
    {
      condition: "Burns",
      icon: AlertTriangle,
      steps: [
        "Cool burn with clean water",
        "Cover with sterile dressing",
        "Don't break blisters",
        "Seek medical attention for severe burns"
      ]
    },
    {
      condition: "Heat Exhaustion",
      icon: ThermometerSun,
      steps: [
        "Move to cool area",
        "Loosen clothing",
        "Provide water",
        "Apply cool, wet cloths"
      ]
    },
    {
      condition: "Fractures",
      icon: Stethoscope,
      steps: [
        "Don't move injured person",
        "Immobilize injured area",
        "Apply cold pack",
        "Call emergency services"
      ]
    }
  ];

  return (
    <div className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">
            First Aid Guide
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Quick reference guide for common medical emergencies
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2">
          {firstAidSteps.map((condition) => (
            <div
              key={condition.condition}
              className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-red-600"
            >
              <div className="flex items-center mb-4">
                <condition.icon className="h-8 w-8 text-red-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">
                  {condition.condition}
                </h3>
              </div>
              <ol className="space-y-3">
                {condition.steps.map((step, index) => (
                  <li key={index} className="flex items-start">
                    <span className="flex-shrink-0 h-6 w-6 flex items-center justify-center rounded-full bg-red-100 text-red-600 font-semibold text-sm mr-3">
                      {index + 1}
                    </span>
                    <span className="text-gray-600">{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-sm text-gray-500">
            Note: This guide is for reference only. Always seek professional medical help in emergencies.
          </p>
        </div>
      </div>
    </div>
  );
};