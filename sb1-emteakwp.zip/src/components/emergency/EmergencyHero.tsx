import React from 'react';
import { AlertTriangle, Phone, Download, BookOpen } from 'lucide-react';

export const EmergencyHero: React.FC = () => {
  return (
    <div className="relative py-20 overflow-hidden bg-red-600">
      <div className="absolute inset-0 bg-black bg-opacity-50" />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Emergency Procedures
          </h1>
          <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-100">
            Critical information and procedures for emergency situations
          </p>
          <div className="mt-10 flex justify-center space-x-6">
            <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-red-700 hover:bg-red-800">
              <Phone className="h-5 w-5 mr-2" />
              Emergency Contacts
            </button>
            <button className="inline-flex items-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-red-600">
              <Download className="h-5 w-5 mr-2" />
              Download Procedures
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};