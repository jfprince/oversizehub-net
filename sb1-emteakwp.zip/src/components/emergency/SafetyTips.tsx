import React from 'react';
import { Shield, AlertTriangle, Eye, Radio, Map, Sun } from 'lucide-react';

export const SafetyTips: React.FC = () => {
  const tips = [
    {
      category: "Prevention",
      icon: Shield,
      items: [
        "Regular vehicle maintenance checks",
        "Weather monitoring before trips",
        "Route planning and hazard identification",
        "Load security verification",
        "Emergency kit inspection"
      ]
    },
    {
      category: "Communication",
      icon: Radio,
      items: [
        "Maintain working communication devices",
        "Keep emergency contacts updated",
        "Regular check-ins with dispatch",
        "Know radio protocols",
        "Backup communication plan"
      ]
    },
    {
      category: "Awareness",
      icon: Eye,
      items: [
        "Monitor weather conditions",
        "Watch for road hazards",
        "Check bridge clearances",
        "Observe weight restrictions",
        "Stay alert for traffic changes"
      ]
    }
  ];

  return (
    <div className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">
            Safety Tips & Best Practices
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Essential guidelines for preventing emergencies
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
          {tips.map((category) => (
            <div
              key={category.category}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <div className="flex items-center mb-6">
                <category.icon className="h-8 w-8 text-red-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">
                  {category.category}
                </h3>
              </div>
              <ul className="space-y-3">
                {category.items.map((item, index) => (
                  <li key={index} className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-red-600 mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};