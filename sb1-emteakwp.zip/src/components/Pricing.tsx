import React, { useState } from 'react';
import { Lock, Shield, Users, Building2, Globe, GraduationCap } from 'lucide-react';
import { DemoRequest } from './DemoRequest';
import { PricingTabs } from './pricing/PricingTabs';
import { PricingPlans } from './pricing/PricingPlans';

export const Pricing: React.FC = () => {
  const [showDemoRequest, setShowDemoRequest] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'users' | 'partners' | 'government' | 'training'>('users');

  return (
    <section id="pricing" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Why Join OversizeHub */}
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl mb-6">
            Transform Your Transport Operations
          </h2>
          <div className="max-w-3xl mx-auto">
            <p className="text-lg text-gray-600 mb-8">
             Be among the first to revolutionize oversized transport logistics with OversizeHub.
As an early supporter, you'll lock in exclusive pricing and enjoy priority access to future features at no extra cost. Our platform is designed with startups and industry pioneers in mind, combining cutting-edge technology with deep expertise to solve real-world challenges. Join us now and grow alongside a community shaping the future of oversized transportation.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-6 bg-gray-50 rounded-xl">
                <Users className="h-8 w-8 text-[#ED4235] mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Industry Network</h3>
                <p className="text-gray-600">
                  Connect with verified partners and grow your professional network
                </p>
              </div>
              
              <div className="p-6 bg-gray-50 rounded-xl">
                <Building2 className="h-8 w-8 text-[#ED4235] mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Professional Tools</h3>
                <p className="text-gray-600">
                  Access advanced route planning and compliance management tools
                </p>
              </div>
              
              <div className="p-6 bg-gray-50 rounded-xl">
                <Globe className="h-8 w-8 text-[#ED4235] mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Global Reach</h3>
                <p className="text-gray-600">
                  Expand your operations across North America with confidence
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Privacy Notice */}
        <div className="mb-16 text-center">
          <div className="inline-flex items-center space-x-2 text-sm text-gray-600 bg-gray-50 px-4 py-2 rounded-full">
            <Lock className="h-4 w-4 text-[#ED4235]" />
            <span>Privacy-first platform • No ads • Your data stays yours</span>
          </div>
        </div>

        {/* Plan Selection */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Choose Your Plan
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            All plans include a 30-day free trial. No credit card required.
          </p>
        </div>

        {/* Pricing Tabs */}
        <PricingTabs 
          activeTab={selectedTab}
          onTabChange={(tab) => setSelectedTab(tab)}
        />

        {/* Pricing Plans */}
        <PricingPlans 
          type={selectedTab}
          onRequestDemo={() => setShowDemoRequest(true)}
        />

        {/* Start Your Journey Section */}
        <div className="mt-16 bg-gradient-to-r from-[#ED4235]/5 via-[#ED4235]/10 to-[#ED4235]/5 rounded-2xl p-8">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <h3 className="text-2xl font-bold text-gray-900">
              Ready to Transform Your Operations?
            </h3>
            <p className="text-lg text-gray-600">
              Join industry leaders who trust OversizeHub for their transport management needs.
              Start your 30-day free trial today and experience the difference.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mt-8">
              <div className="flex items-center text-gray-600">
                <Shield className="h-5 w-5 text-green-500 mr-2" />
                Full Feature Access
              </div>
              <div className="flex items-center text-gray-600">
                <Shield className="h-5 w-5 text-green-500 mr-2" />
                No Credit Card Required
              </div>
              <div className="flex items-center text-gray-600">
                <Shield className="h-5 w-5 text-green-500 mr-2" />
                Cancel Anytime
              </div>
            </div>
          </div>
        </div>
      </div>

      {showDemoRequest && (
        <DemoRequest onClose={() => setShowDemoRequest(false)} />
      )}
    </section>
  );
};