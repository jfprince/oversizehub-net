import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../auth/AuthProvider';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { 
  User, Building2, Truck, Shield, Globe, 
  Briefcase, MapPin, Phone, Mail, Calendar,
  Languages, Award, CreditCard, Settings
} from 'lucide-react';
import { AddressInput } from './AddressInput';
import { PhoneInput } from './PhoneInput';
import { EmailInput } from './EmailInput';
import { validateField } from './validation';

interface UserData {
  // Basic Information
  firstName: string;
  lastName: string;
  displayName: string;
  email: string;
  phone: string;
  profilePicture?: string;

  // Professional Information
  companyName: string;
  jobTitle: string;
  companyType: string;
  yearsExperience: number;
  certifications: string[];

  // Contact Information
  address: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
  };
  operatingRegions: string[];
  timeZone: string;

  // Logistics Information
  fleetDetails: {
    vehicleTypes: string[];
    totalVehicles: number;
  };
  specialties: string[];
  maxDimensions: {
    length: number;
    width: number;
    height: number;
    weight: number;
  };
  routingExpertise: string[];

  // Compliance Information
  permitTypes: string[];
  insuranceInfo: {
    provider: string;
    policyNumber: string;
    coverage: number;
    expiryDate: string;
  };

  // Additional Information
  languages: string[];
  role: string;
  createdAt: Date;
}

export const UserProfile: React.FC = () => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [userData, setUserData] = useState<UserData>({
    firstName: '',
    lastName: '',
    displayName: '',
    email: '',
    phone: '',
    companyName: '',
    jobTitle: '',
    companyType: '',
    yearsExperience: 0,
    certifications: [],
    address: {
      street: '',
      city: '',
      state: '',
      country: '',
      postalCode: ''
    },
    operatingRegions: [],
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    fleetDetails: {
      vehicleTypes: [],
      totalVehicles: 0
    },
    specialties: [],
    maxDimensions: {
      length: 0,
      width: 0,
      height: 0,
      weight: 0
    },
    routingExpertise: [],
    permitTypes: [],
    insuranceInfo: {
      provider: '',
      policyNumber: '',
      coverage: 0,
      expiryDate: ''
    },
    languages: [],
    role: '',
    createdAt: new Date()
  });
  const [errors, setErrors] = useState<Partial<UserData>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (user) {
      loadUserData();
    }
  }, [user]);

  const loadUserData = async () => {
    setIsLoading(true);
    try {
      const userDoc = await getDoc(doc(db, 'users', user!.uid));
      if (userDoc.exists()) {
        const data = userDoc.data();
        setUserData({
          ...userData,
          ...data,
          createdAt: data.createdAt?.toDate() || new Date()
        });
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        ...userData,
        updatedAt: new Date()
      });
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleChange = (field: string, value: any) => {
    setUserData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#ED4235]"></div>
      </div>
    );
  }

  const renderSection = (
    title: string, 
    icon: React.ElementType, 
    children: React.ReactNode
  ) => (
    <div className="bg-white rounded-lg shadow p-6 space-y-4">
      <h3 className="text-lg font-semibold text-gray-900 flex items-center">
        {React.createElement(icon, { className: "h-5 w-5 mr-2 text-[#ED4235]" })}
        {title}
      </h3>
      {children}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <User className="h-6 w-6 mr-2 text-[#ED4235]" />
            {t('navigation.profile')}
          </h2>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="px-4 py-2 text-[#ED4235] hover:bg-red-50 rounded-md"
          >
            {isEditing ? 'Cancel' : 'Edit Profile'}
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          {renderSection("Basic Information", User, (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">First Name</label>
                <input
                  type="text"
                  value={userData.firstName}
                  onChange={(e) => handleChange('firstName', e.target.value)}
                  disabled={!isEditing}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Last Name</label>
                <input
                  type="text"
                  value={userData.lastName}
                  onChange={(e) => handleChange('lastName', e.target.value)}
                  disabled={!isEditing}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                />
              </div>
              <PhoneInput
                value={userData.phone}
                onChange={(value) => handleChange('phone', value)}
                disabled={!isEditing}
              />
              <EmailInput
                value={userData.email}
                onChange={(value) => handleChange('email', value)}
                disabled={!isEditing}
              />
            </div>
          ))}

          {/* Professional Information */}
          {renderSection("Professional Information", Briefcase, (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Company Name</label>
                  <input
                    type="text"
                    value={userData.companyName}
                    onChange={(e) => handleChange('companyName', e.target.value)}
                    disabled={!isEditing}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Job Title</label>
                  <input
                    type="text"
                    value={userData.jobTitle}
                    onChange={(e) => handleChange('jobTitle', e.target.value)}
                    disabled={!isEditing}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Company Type</label>
                <select
                  value={userData.companyType}
                  onChange={(e) => handleChange('companyType', e.target.value)}
                  disabled={!isEditing}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                >
                  <option value="">Select company type</option>
                  <option value="carrier">Carrier</option>
                  <option value="broker">Broker</option>
                  <option value="shipper">Shipper</option>
                  <option value="3pl">3PL</option>
                </select>
              </div>
            </div>
          ))}

          {/* Contact Information */}
          {renderSection("Contact Information", MapPin, (
            <AddressInput
              value={userData.address}
              onChange={(value) => handleChange('address', value)}
              disabled={!isEditing}
            />
          ))}

          {/* Logistics Information */}
          {renderSection("Logistics Information", Truck, (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Vehicle Types</label>
                <input
                  type="text"
                  value={userData.fleetDetails.vehicleTypes.join(', ')}
                  onChange={(e) => handleChange('fleetDetails', {
                    ...userData.fleetDetails,
                    vehicleTypes: e.target.value.split(',').map(s => s.trim())
                  })}
                  disabled={!isEditing}
                  placeholder="e.g., Flatbed, Step Deck, RGN"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Max Length (ft)</label>
                  <input
                    type="number"
                    value={userData.maxDimensions.length}
                    onChange={(e) => handleChange('maxDimensions', {
                      ...userData.maxDimensions,
                      length: parseFloat(e.target.value)
                    })}
                    disabled={!isEditing}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Max Width (ft)</label>
                  <input
                    type="number"
                    value={userData.maxDimensions.width}
                    onChange={(e) => handleChange('maxDimensions', {
                      ...userData.maxDimensions,
                      width: parseFloat(e.target.value)
                    })}
                    disabled={!isEditing}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Max Height (ft)</label>
                  <input
                    type="number"
                    value={userData.maxDimensions.height}
                    onChange={(e) => handleChange('maxDimensions', {
                      ...userData.maxDimensions,
                      height: parseFloat(e.target.value)
                    })}
                    disabled={!isEditing}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Max Weight (lbs)</label>
                  <input
                    type="number"
                    value={userData.maxDimensions.weight}
                    onChange={(e) => handleChange('maxDimensions', {
                      ...userData.maxDimensions,
                      weight: parseFloat(e.target.value)
                    })}
                    disabled={!isEditing}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                  />
                </div>
              </div>
            </div>
          ))}

          {/* Compliance Information */}
          {renderSection("Compliance Information", Shield, (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Permit Types</label>
                <input
                  type="text"
                  value={userData.permitTypes.join(', ')}
                  onChange={(e) => handleChange('permitTypes', e.target.value.split(',').map(s => s.trim()))}
                  disabled={!isEditing}
                  placeholder="e.g., Oversize, Overweight, Super Load"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Insurance Provider</label>
                  <input
                    type="text"
                    value={userData.insuranceInfo.provider}
                    onChange={(e) => handleChange('insuranceInfo', {
                      ...userData.insuranceInfo,
                      provider: e.target.value
                    })}
                    disabled={!isEditing}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Policy Number</label>
                  <input
                    type="text"
                    value={userData.insuranceInfo.policyNumber}
                    onChange={(e) => handleChange('insuranceInfo', {
                      ...userData.insuranceInfo,
                      policyNumber: e.target.value
                    })}
                    disabled={!isEditing}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                  />
                </div>
              </div>
            </div>
          ))}

          {/* Additional Information */}
          {renderSection("Additional Information", Globe, (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Languages</label>
                <input
                  type="text"
                  value={userData.languages.join(', ')}
                  onChange={(e) => handleChange('languages', e.target.value.split(',').map(s => s.trim()))}
                  disabled={!isEditing}
                  placeholder="e.g., English, French, Spanish"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235] disabled:bg-gray-50"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Role</label>
                  <div className="mt-1 p-2 bg-gray-50 rounded-md capitalize">
                    {userData.role || 'User'}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Member Since</label>
                  <div className="mt-1 p-2 bg-gray-50 rounded-md">
                    {userData.createdAt.toLocaleDateString()}
                  </div>
                </div>
              </div>
            </div>
          ))}

          {isEditing && (
            <div className="flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 disabled:opacity-50"
              >
                {isSaving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};