import { Timestamp } from 'firebase/firestore';

export interface BaseUserInfo {
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  phone: string;
  profilePicture?: string;
}

export interface ProfessionalInfo {
  companyName: string;
  jobTitle: string;
  companyType: string;
  yearsOfExperience: number;
  certifications: string[];
}

export interface ContactInfo {
  headquarters: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
  };
  operatingRegions: string[];
  timeZone: string;
}

export interface LogisticsInfo {
  fleetDetails: {
    vehicleTypes: string[];
    totalVehicles: number;
  };
  specialties: string[];
  capacityInfo: {
    maxLength: number;
    maxWidth: number;
    maxHeight: number;
    maxWeight: number;
  };
  routingExpertise: string[];
}

export interface ComplianceInfo {
  permitTypes: string[];
  insuranceInfo: {
    provider: string;
    policyNumber: string;
    coverage: number;
    expiryDate: Date;
  };
  certifications: {
    name: string;
    issuedBy: string;
    expiryDate: Date;
  }[];
}

export interface CollaborationInfo {
  languages: string[];
  partnerCompanies: string[];
  availabilityStatus: 'available' | 'busy' | 'unavailable';
}

export interface PortfolioInfo {
  pastProjects: {
    name: string;
    description: string;
    date: Date;
    client: string;
  }[];
  testimonials: {
    text: string;
    author: string;
    company: string;
    date: Date;
  }[];
}

export interface PaymentInfo {
  paymentMethods: string[];
  taxId: string;
  bankingDetails?: {
    accountHolder: string;
    bankName: string;
    accountNumber: string;
    routingNumber: string;
  };
}

export interface PreferencesInfo {
  dashboardLayout: {
    showMap: boolean;
    showStats: boolean;
    showNotifications: boolean;
  };
  notifications: {
    email: boolean;
    sms: boolean;
    push: boolean;
  };
  searchFilters: {
    regions: string[];
    loadTypes: string[];
    vehicleTypes: string[];
  };
}

export interface SecurityInfo {
  twoFactorEnabled: boolean;
  lastPasswordChange: Date;
  loginHistory: {
    date: Date;
    ip: string;
    device: string;
  }[];
  role: string;
  permissions: string[];
}

export interface UserProfile {
  id: string;
  baseInfo: BaseUserInfo;
  professionalInfo: ProfessionalInfo;
  contactInfo: ContactInfo;
  logisticsInfo: LogisticsInfo;
  complianceInfo: ComplianceInfo;
  collaborationInfo: CollaborationInfo;
  portfolioInfo: PortfolioInfo;
  paymentInfo: PaymentInfo;
  preferencesInfo: PreferencesInfo;
  securityInfo: SecurityInfo;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}