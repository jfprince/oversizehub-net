import React, { useState, useEffect } from 'react';
import { useDebounce } from 'use-debounce';
import { MapPin, Check, AlertCircle } from 'lucide-react';
import { validatePostalCode, validateCity, validateState, validateCountry } from './validation/addressValidation';

interface AddressInputProps {
  value: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
  };
  onChange: (value: any) => void;
  disabled?: boolean;
}

export const AddressInput: React.FC<AddressInputProps> = ({ value, onChange, disabled }) => {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const [debouncedStreet] = useDebounce(value.street, 500);

  useEffect(() => {
    if (debouncedStreet && debouncedStreet.length > 3) {
      // Simulated address suggestions
      const mockSuggestions = [
        `${debouncedStreet} Street`,
        `${debouncedStreet} Avenue`,
        `${debouncedStreet} Boulevard`,
        `${debouncedStreet} Road`
      ];
      setSuggestions(mockSuggestions);
    } else {
      setSuggestions([]);
    }
  }, [debouncedStreet]);

  const validateField = (field: string, value: string) => {
    let error = null;
    switch (field) {
      case 'postalCode':
        error = validatePostalCode(value);
        break;
      case 'city':
        error = validateCity(value);
        break;
      case 'state':
        error = validateState(value);
        break;
      case 'country':
        error = validateCountry(value);
        break;
    }
    setErrors(prev => ({ ...prev, [field]: error }));
    return error;
  };

  const handleChange = (field: string, newValue: string) => {
    const error = validateField(field, newValue);
    onChange({
      ...value,
      [field]: newValue,
      isValid: !error
    });
  };

  const getInputClassName = (field: string) => `
    mt-1 block w-full rounded-md 
    ${errors[field] 
      ? 'border-red-300 focus:border-red-500 focus:ring-red-500' 
      : 'border-gray-300 focus:border-[#ED4235] focus:ring-[#ED4235]'}
    shadow-sm disabled:bg-gray-50
  `;

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 flex items-center">
          <MapPin className="h-4 w-4 mr-2" />
          Street Address
        </label>
        <div className="relative">
          <input
            type="text"
            value={value.street}
            onChange={(e) => onChange({ ...value, street: e.target.value })}
            disabled={disabled}
            className={getInputClassName('street')}
          />
          {suggestions.length > 0 && !disabled && (
            <div className="absolute z-10 w-full mt-1 bg-white rounded-md shadow-lg">
              {suggestions.map((suggestion, index) => (
                <button
                  key={index}
                  className="w-full text-left px-4 py-2 hover:bg-gray-100"
                  onClick={() => onChange({ ...value, street: suggestion })}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">City</label>
          <input
            type="text"
            value={value.city}
            onChange={(e) => handleChange('city', e.target.value)}
            disabled={disabled}
            className={getInputClassName('city')}
          />
          {errors.city && (
            <p className="mt-1 text-sm text-red-600 flex items-center">
              <AlertCircle className="h-4 w-4 mr-1" />
              {errors.city}
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">State/Province</label>
          <input
            type="text"
            value={value.state}
            onChange={(e) => handleChange('state', e.target.value)}
            disabled={disabled}
            className={getInputClassName('state')}
          />
          {errors.state && (
            <p className="mt-1 text-sm text-red-600 flex items-center">
              <AlertCircle className="h-4 w-4 mr-1" />
              {errors.state}
            </p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Country</label>
          <input
            type="text"
            value={value.country}
            onChange={(e) => handleChange('country', e.target.value)}
            disabled={disabled}
            className={getInputClassName('country')}
          />
          {errors.country && (
            <p className="mt-1 text-sm text-red-600 flex items-center">
              <AlertCircle className="h-4 w-4 mr-1" />
              {errors.country}
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Postal Code</label>
          <input
            type="text"
            value={value.postalCode}
            onChange={(e) => handleChange('postalCode', e.target.value)}
            disabled={disabled}
            className={getInputClassName('postalCode')}
          />
          {errors.postalCode && (
            <p className="mt-1 text-sm text-red-600 flex items-center">
              <AlertCircle className="h-4 w-4 mr-1" />
              {errors.postalCode}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};