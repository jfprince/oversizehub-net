import React, { useState, useEffect } from 'react';
import { collection, getDocs, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth, db } from '../../lib/firebase';
import { COLLECTIONS } from '../../lib/database/constants';
import { UserProfile } from '../../types/user';
import { Users, Trash2, Lock, Eye, Ban, RefreshCw } from 'lucide-react';

export const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [actionStatus, setActionStatus] = useState<{
    type: 'success' | 'error' | null;
    message: string;
  }>({ type: null, message: '' });

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, COLLECTIONS.USERS));
      const userData = querySnapshot.docs.map(doc => ({
        uid: doc.id,
        ...doc.data()
      })) as UserProfile[];
      setUsers(userData);
    } catch (error) {
      console.error('Error loading users:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateRole = async (userId: string, newRole: string) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, userId), { 
        role: newRole,
        updatedAt: new Date()
      });
      await loadUsers();
      setActionStatus({
        type: 'success',
        message: 'User role updated successfully'
      });
    } catch (error) {
      setActionStatus({
        type: 'error',
        message: 'Failed to update user role'
      });
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    
    try {
      await deleteDoc(doc(db, COLLECTIONS.USERS, userId));
      await loadUsers();
      setActionStatus({
        type: 'success',
        message: 'User deleted successfully'
      });
    } catch (error) {
      setActionStatus({
        type: 'error',
        message: 'Failed to delete user'
      });
    }
  };

  const handleResetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
      setActionStatus({
        type: 'success',
        message: 'Password reset email sent'
      });
    } catch (error) {
      setActionStatus({
        type: 'error',
        message: 'Failed to send password reset email'
      });
    }
  };

  const handleSuspendUser = async (userId: string, isSuspended: boolean) => {
    try {
      await updateDoc(doc(db, COLLECTIONS.USERS, userId), {
        suspended: isSuspended,
        updatedAt: new Date()
      });
      await loadUsers();
      setActionStatus({
        type: 'success',
        message: `User ${isSuspended ? 'suspended' : 'unsuspended'} successfully`
      });
    } catch (error) {
      setActionStatus({
        type: 'error',
        message: `Failed to ${isSuspended ? 'suspend' : 'unsuspend'} user`
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <RefreshCw className="h-8 w-8 text-blue-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-900">User Management</h2>

      {actionStatus.type && (
        <div className={`p-4 rounded-md ${
          actionStatus.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
        }`}>
          {actionStatus.message}
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                User
              </th>
              <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Role
              </th>
              <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Created At
              </th>
              <th className="px-6 py-3 bg-gray-50"></th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {users.map((user) => (
              <tr key={user.uid}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Users className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {user.displayName || 'N/A'}
                      </div>
                      <div className="text-sm text-gray-500">{user.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <select
                    value={user.role || 'user'}
                    onChange={(e) => handleUpdateRole(user.uid, e.target.value)}
                    className="text-sm border-gray-300 rounded-md focus:ring-[#ED4235] focus:border-[#ED4235]"
                  >
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                  </select>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    user.suspended
                      ? 'bg-red-100 text-red-800'
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {user.suspended ? 'Suspended' : 'Active'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Date(user.createdAt).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleResetPassword(user.email)}
                      className="text-blue-600 hover:text-blue-900"
                      title="Reset Password"
                    >
                      <Lock className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => {
                        setSelectedUser(user);
                        setShowDetails(true);
                      }}
                      className="text-gray-600 hover:text-gray-900"
                      title="View Details"
                    >
                      <Eye className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleSuspendUser(user.uid, !user.suspended)}
                      className={`${
                        user.suspended
                          ? 'text-green-600 hover:text-green-900'
                          : 'text-yellow-600 hover:text-yellow-900'
                      }`}
                      title={user.suspended ? 'Unsuspend User' : 'Suspend User'}
                    >
                      <Ban className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDeleteUser(user.uid)}
                      className="text-red-600 hover:text-red-900"
                      title="Delete User"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showDetails && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">User Details</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium">Basic Information</h4>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div>
                    <label className="text-sm text-gray-500">Name</label>
                    <p>{selectedUser.displayName || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Email</label>
                    <p>{selectedUser.email}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Role</label>
                    <p className="capitalize">{selectedUser.role || 'user'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Account Type</label>
                    <p className="capitalize">{selectedUser.accountType}</p>
                  </div>
                </div>
              </div>

              {selectedUser.professional && (
                <div>
                  <h4 className="font-medium">Professional Information</h4>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <label className="text-sm text-gray-500">Company</label>
                      <p>{selectedUser.professional.companyName || 'N/A'}</p>
                    </div>
                    <div>
                      <label className="text-sm text-gray-500">Job Title</label>
                      <p>{selectedUser.professional.jobTitle || 'N/A'}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-end mt-6">
                <button
                  onClick={() => setShowDetails(false)}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};