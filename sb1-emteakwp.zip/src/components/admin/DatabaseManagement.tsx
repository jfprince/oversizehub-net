import React, { useState } from 'react';
import { Database, AlertTriangle, RefreshCw } from 'lucide-react';
import { initializeDatabase, resetDatabase, verifyDatabase } from '../../lib/database/initialize';

export const DatabaseManagement: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');
  const [verificationResults, setVerificationResults] = useState<any>(null);

  const handleInitialize = async () => {
    if (!window.confirm('Are you sure you want to initialize the database?')) return;
    
    setStatus('loading');
    setMessage('Initializing database...');
    
    try {
      await initializeDatabase();
      const results = await verifyDatabase();
      setVerificationResults(results);
      setStatus('success');
      setMessage('Database initialized successfully!');
    } catch (error) {
      setStatus('error');
      setMessage(`Error: ${(error as Error).message}`);
    }
  };

  const handleReset = async () => {
    if (!window.confirm('WARNING: This will delete ALL data. Are you sure?')) return;
    
    setStatus('loading');
    setMessage('Resetting database...');
    
    try {
      await resetDatabase();
      setStatus('success');
      setMessage('Database reset successfully!');
    } catch (error) {
      setStatus('error');
      setMessage(`Error: ${(error as Error).message}`);
    }
  };

  const handleVerify = async () => {
    setStatus('loading');
    setMessage('Verifying database...');
    
    try {
      const results = await verifyDatabase();
      setVerificationResults(results);
      setStatus('success');
      setMessage('Database verification complete');
    } catch (error) {
      setStatus('error');
      setMessage(`Error: ${(error as Error).message}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="p-4 bg-yellow-50 rounded-md flex items-start space-x-3">
        <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="text-sm font-medium text-yellow-800">Warning</h3>
          <p className="text-sm text-yellow-700 mt-1">
            These actions affect the database structure and data. Use with caution.
          </p>
        </div>
      </div>

      <div className="flex space-x-4">
        <button
          onClick={handleInitialize}
          disabled={status === 'loading'}
          className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50"
        >
          Initialize Database
        </button>
        <button
          onClick={handleVerify}
          disabled={status === 'loading'}
          className="flex-1 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 disabled:opacity-50"
        >
          Verify Database
        </button>
        <button
          onClick={handleReset}
          disabled={status === 'loading'}
          className="flex-1 px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 disabled:opacity-50"
        >
          Reset Database
        </button>
      </div>

      {status === 'loading' && (
        <div className="flex justify-center">
          <RefreshCw className="h-8 w-8 text-blue-500 animate-spin" />
        </div>
      )}

      {message && (
        <div className={`p-4 rounded-md ${
          status === 'success' ? 'bg-green-50 text-green-700' :
          status === 'error' ? 'bg-red-50 text-red-700' :
          'bg-gray-50 text-gray-700'
        }`}>
          {message}
        </div>
      )}

      {verificationResults && (
        <div className="space-y-4">
          <h4 className="font-medium text-gray-900">Verification Results</h4>
          
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className={`w-2 h-2 rounded-full ${verificationResults.adminUser ? 'bg-green-500' : 'bg-red-500'}`} />
              <span>Admin User</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className={`w-2 h-2 rounded-full ${verificationResults.systemSettings ? 'bg-green-500' : 'bg-red-500'}`} />
              <span>System Settings</span>
            </div>
          </div>

          <div>
            <h5 className="font-medium text-gray-900 mb-2">Collections</h5>
            <div className="space-y-2">
              {Object.entries(verificationResults.collections).map(([name, exists]) => (
                <div key={name} className="flex items-center space-x-2">
                  <span className={`w-2 h-2 rounded-full ${exists ? 'bg-green-500' : 'bg-red-500'}`} />
                  <span>{name}</span>
                </div>
              ))}
            </div>
          </div>

          {verificationResults.errors.length > 0 && (
            <div>
              <h5 className="font-medium text-red-600 mb-2">Errors</h5>
              <ul className="list-disc list-inside space-y-1 text-red-600">
                {verificationResults.errors.map((error: string, index: number) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};