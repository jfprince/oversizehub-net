import React from 'react';
import { SubMenuItem } from './types';

interface SubMenuProps {
  items: SubMenuItem[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

export const SubMenu: React.FC<SubMenuProps> = ({ items, activeTab, onTabChange }) => {
  return (
    <div 
      className="absolute left-0 mt-1 w-56 bg-white border border-gray-200 rounded-lg shadow-lg z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200"
      role="menu"
      aria-orientation="vertical"
    >
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => onTabChange(item.id)}
          className={`flex items-center w-full px-4 py-2 text-sm ${
            activeTab === item.id
              ? 'text-[#ED4235] bg-red-50'
              : 'text-gray-700 hover:bg-gray-50'
          }`}
          role="menuitem"
        >
          <item.icon className="h-4 w-4 mr-2" />
          {item.label}
        </button>
      ))}
    </div>
  );
};