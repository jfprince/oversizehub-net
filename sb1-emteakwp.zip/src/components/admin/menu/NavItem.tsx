import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { MenuItem } from './types';
import { SubMenu } from './SubMenu';

interface NavItemProps {
  item: MenuItem;
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

export const NavItem: React.FC<NavItemProps> = ({ item, activeTab, onTabChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const isActive = activeTab === item.id || item.subItems?.some(sub => sub.id === activeTab);

  return (
    <div className="relative">
      <button
        onClick={() => {
          onTabChange(item.id);
          setIsOpen(!isOpen);
        }}
        className={`flex items-center px-6 py-4 text-sm font-medium border-b-2 ${
          isActive
            ? 'border-[#ED4235] text-[#ED4235]'
            : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
        }`}
      >
        <item.icon className="h-5 w-5 mr-2" />
        {item.label}
        {item.subItems && (
          <ChevronDown className={`ml-2 h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        )}
      </button>

      {isOpen && item.subItems && (
        <SubMenu 
          items={item.subItems} 
          activeTab={activeTab}
          onTabChange={(id) => {
            onTabChange(id);
            setIsOpen(false);
          }}
        />
      )}
    </div>
  );
};