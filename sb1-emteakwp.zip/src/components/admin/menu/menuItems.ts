import { Database, Settings, Activity, Wrench, Users, Shield } from 'lucide-react';
import { DatabaseManagement } from '../DatabaseManagement';
import { SystemStatus } from '../SystemStatus';
import { Settings as SettingsComponent } from '../Settings';
import { UserManagement } from '../UserManagement';
import { MaintenanceMode } from '../maintenance/MaintenanceMode';

export const menuItems = [
  {
    id: 'users',
    label: 'User Management',
    icon: Users,
    component: UserManagement,
    subItems: [
      { id: 'all-users', label: 'All Users', icon: Users, component: UserManagement },
      { id: 'roles', label: 'Roles & Permissions', icon: Shield },
      { id: 'verification', label: 'Verification Requests', icon: FileText }
    ]
  },
  {
    id: 'maintenance',
    label: 'Maintenance',
    icon: Wrench,
    component: MaintenanceMode
  },
  {
    id: 'system',
    label: 'System',
    icon: Activity,
    subItems: [
      { id: 'database', label: 'Database', icon: Database, component: DatabaseManagement },
      { id: 'status', label: 'System Status', icon: Activity, component: SystemStatus },
      { id: 'settings', label: 'Settings', icon: Settings, component: SettingsComponent }
    ]
  }
];