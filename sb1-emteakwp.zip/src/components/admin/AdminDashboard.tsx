import React, { useState } from 'react';
import { useAuth } from '../auth/AuthProvider';
import { AdminMenu, menuItems } from './menu/AdminMenu';

export const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('maintenance');
  const { user, isAdmin } = useAuth();

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600">You don't have permission to access this area.</p>
        </div>
      </div>
    );
  }

  const activeMenu = menuItems.find(item => 
    item.id === activeTab || item.subItems?.some(sub => sub.id === activeTab)
  );
  
  const ActiveComponent = activeMenu?.component || 
    activeMenu?.subItems?.find(sub => sub.id === activeTab)?.component;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <AdminMenu activeTab={activeTab} onTabChange={setActiveTab} />
          <div className="p-6">
            {ActiveComponent && <ActiveComponent />}
          </div>
        </div>
      </div>
    </div>
  );
};