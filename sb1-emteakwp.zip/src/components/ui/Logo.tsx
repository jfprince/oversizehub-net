import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src="https://soltec.ca/Fichier%204logoseulBlack2.png" 
        alt="OversizeHub Logo" 
        className="h-16 w-auto"
      />
    </div>
  );
};