import React from 'react';
import { Mail, Phone, MapPin, Clock, Globe } from 'lucide-react';

export const ContactInfo: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-start space-x-4">
        <MapPin className="h-6 w-6 text-[#ED4235] flex-shrink-0 mt-1" />
        <div>
          <h3 className="font-medium text-gray-900">Address</h3>
          <p className="text-gray-600">
            123 Transport Avenue<br />
            Montreal, QC H3Z 2Y7<br />
            Canada
          </p>
        </div>
      </div>

      <div className="flex items-start space-x-4">
        <Phone className="h-6 w-6 text-[#ED4235] flex-shrink-0 mt-1" />
        <div>
          <h3 className="font-medium text-gray-900">Phone</h3>
          <p className="text-gray-600">
            <a href="tel:+1-514-555-0123" className="hover:text-[#ED4235]">+1 (514) 555-0123</a>
          </p>
          <p className="text-sm text-gray-500">Monday to Friday, 8am to 6pm EST</p>
        </div>
      </div>

      <div className="flex items-start space-x-4">
        <Mail className="h-6 w-6 text-[#ED4235] flex-shrink-0 mt-1" />
        <div>
          <h3 className="font-medium text-gray-900">Email</h3>
          <p className="text-gray-600">
            <a href="mailto:contact@oversizehub.net" className="hover:text-[#ED4235]">
              contact@oversizehub.net
            </a>
          </p>
          <p className="text-sm text-gray-500">We aim to respond within 24 hours</p>
        </div>
      </div>

      <div className="flex items-start space-x-4">
        <Clock className="h-6 w-6 text-[#ED4235] flex-shrink-0 mt-1" />
        <div>
          <h3 className="font-medium text-gray-900">Hours of Operation</h3>
          <div className="text-gray-600">
            <p>Monday - Friday: 8:00 AM - 6:00 PM EST</p>
            <p>Saturday: 9:00 AM - 2:00 PM EST</p>
            <p>Sunday: Closed</p>
          </div>
        </div>
      </div>

      <div className="flex items-start space-x-4">
        <Globe className="h-6 w-6 text-[#ED4235] flex-shrink-0 mt-1" />
        <div>
          <h3 className="font-medium text-gray-900">Service Areas</h3>
          <div className="text-gray-600">
            <p>Canada & United States</p>
            <p className="text-sm text-gray-500">Specialized in cross-border transportation</p>
          </div>
        </div>
      </div>
    </div>
  );
};