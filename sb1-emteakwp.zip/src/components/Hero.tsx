import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  MapPin, 
  Truck, 
  Shield, 
  Globe, 
  Lock, 
  Ban, 
  Database, 
  Eye,
  Map,
  Users,
  Star,
  DollarSign,
  HandshakeIcon,
  Briefcase,
  Newspaper
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const Hero: React.FC = () => {
  const { t } = useTranslation();

  const mainFeatures = [
    {
      title: "Advanced Route Planning",
      icon: Map,
      description: "Intelligent mapping and optimization specifically designed for oversized loads and heavy transport vehicles."
    },
    {
      title: "Compliance & Safety",
      icon: Shield,
      description: "Built-in regulation compliance tools and real-time safety alerts for your transport operations."
    },
    {
      title: "Seamless Integration",
      icon: Database,
      description: "Import and export data in multiple formats, with offline access for uninterrupted operations."
    },
    {
      title: "Team Collaboration",
      icon: Users,
      description: "Real-time collaboration tools for efficient fleet management and route coordination."
    }
  ];

  const StatCard: React.FC<{
    icon: React.ElementType;
    number: string;
    label: string;
    description: string;
  }> = ({ icon: Icon, number, label, description }) => (
    <div className="group bg-white/5 backdrop-blur-sm rounded-xl p-6 transform hover:scale-[1.02] transition-all duration-300 hover:bg-white/10">
      <div className="flex flex-col items-center text-center space-y-2">
        <Icon className="h-8 w-8 text-[#ED4235] mb-2" />
        <div className="text-3xl font-bold text-white">{number}</div>
        <div className="text-sm uppercase tracking-wider text-[#ED4235] font-semibold">{label}</div>
        <p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">
          {description}
        </p>
      </div>
    </div>
  );

  return (
    <div className="relative">
      {/* Background image and overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://soltec.ca/DJI_0260.JPG)',
          backgroundAttachment: 'fixed'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/75 to-black/90"></div>
      </div>
















      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-24 md:py-32">
          <div className="max-w-4xl mx-auto text-center">
            {/* Main heading */}
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-8 leading-tight">
              <span className="block">Professional Solutions for</span>
              <span className="block text-[#ED4235] mt-2">Heavy Transport Industry</span>
                <span className="text-xl font-medium leading-relaxed">Join the pioneers of digital transport management and AI POWERED Tools</span>
                   
            </h1>

            {/* Main Features */}
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-12">
              <div className="space-y-4 text-white">
                <p className="text-xl font-medium leading-relaxed">
                  Be among the first to revolutionize oversized transport logistics with OversizeHub.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                  {mainFeatures.map((feature, index) => (
                    <div key={index} className="space-y-2">
                      <h3 className="text-lg font-semibold flex items-center">
                        <feature.icon className="h-5 w-5 text-[#ED4235] mr-2" />
                        {feature.title}
                      </h3>
                      <p className="text-gray-300">
                        {feature.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Stats Section */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
              <StatCard
                icon={Globe}
                number="Coverage"
                label="Across"
                description="USA & Canada"
              />
              <StatCard
                icon={Briefcase}
                number="Jobs"
                label="Available"
                description="Find your next opportunity"
              />
              <StatCard
                icon={Newspaper}
                number="News"
                label="Industry"
                description="Stay informed daily"
              />
              <StatCard
                icon={DollarSign}
                number="$1.89"
                label="Fuel Surcharge"
                description="Updated daily"
              />
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link 
                to="/signup" 
                className="px-8 py-4 bg-[#ED4235] text-white font-semibold rounded-xl hover:bg-opacity-90 transition-all transform hover:-translate-y-1 shadow-lg hover:shadow-xl"
              >
                Start Free Trial
              </Link>
              <Link 
                to="/pricing" 
                className="px-8 py-4 bg-white text-[#ED4235] font-semibold rounded-xl hover:bg-opacity-90 transition-all transform hover:-translate-y-1 shadow-lg hover:shadow-xl"
              >
                View Pricing
              </Link>
              <a 
                href="#features" 
                className="px-8 py-4 border-2 border-white text-white font-semibold rounded-xl hover:bg-white hover:text-[#ED4235] transition-all transform hover:-translate-y-1 shadow-lg hover:shadow-xl"
              >
                Explore Features
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;