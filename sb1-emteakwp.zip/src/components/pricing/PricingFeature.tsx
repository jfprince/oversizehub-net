import React from 'react';
import { Check } from 'lucide-react';

interface PricingFeatureProps {
  feature: string;
}

export const PricingFeature: React.FC<PricingFeatureProps> = ({ feature }) => (
  <li className="flex items-center">
    <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
    <span className="text-gray-600">{feature}</span>
  </li>
);