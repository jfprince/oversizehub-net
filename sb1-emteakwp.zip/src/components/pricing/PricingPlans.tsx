import React from 'react';
import { PricingCard } from './PricingCard';
import { 
  Users, 
  Building2, 
  Truck, 
  Building,
  Globe,
  Scale,
  Award,
  Star,
  HandshakeIcon,
  GraduationCap,
  BookOpen,
  Video
} from 'lucide-react';

interface PricingPlansProps {
  type: 'users' | 'partners' | 'government' | 'training';
  onRequestDemo: () => void;
}

export const PricingPlans: React.FC<PricingPlansProps> = ({ type, onRequestDemo }) => {
  const userPlans = [
    {
      name: "Pro Solo",
      description: "Perfect for independent professionals",
      price: 20,
      interval: "month",
      features: [
        "Advanced route planning",
        "Custom map creation",
        "Data import/export",
        "Offline access",
        "Basic support",
        "1 user included",
        "Standard response time (72h)"
      ],
      addons: {
        priority: [
          { name: "Next in Line Priority", price: 50 },
          { name: "48h Response", price: 25 },
          { name: "24h Response", price: 35 }
        ],
        features: [
          { name: "CAD File Access", price: 15 },
          { name: "Document Templates", price: 10 }
        ]
      },
      cta: "Start Free Trial",
      link: "/signup/personal",
      icon: Users
    },
    {
      name: "Pro Team",
      description: "Ideal for small teams",
      price: 100,
      interval: "month",
      features: [
        "All Pro Solo features",
        "Team collaboration",
        "Role-based access",
        "Priority support (48h)",
        "Custom branding",
        "Up to 5 users",
        "CAD file export included"
      ],
      addons: {
        priority: [
          { name: "Next in Line Priority", price: 100 },
          { name: "24h Response", price: 50 }
        ],
        features: [
          { name: "Document Templates", price: 25 },
          { name: "Custom Reports", price: 30 }
        ]
      },
      cta: "Start Free Trial",
      link: "/signup/business",
      highlight: true,
      icon: Building2
    },
    {
      name: "Enterprise",
      description: "For large organizations",
      price: "Custom",
      features: [
        "All Pro Team features",
        "Unlimited users",
        "Custom integration",
        "Dedicated support",
        "Next in Line Priority",
        "24/7 emergency support",
        "Full CAD & document access"
      ],
      cta: "Contact Sales",
      link: "#",
      icon: Truck
    }
  ];

  const partnerPlans = [
    {
      name: "Basic Partner",
      description: "For service providers starting out",
      price: 50,
      interval: "month",
      features: [
        "Basic listing in directory",
        "Standard lead notifications",
        "Basic analytics",
        "Email support",
        "Standard visibility",
        "Basic profile customization"
      ],
      cta: "Join as Partner",
      link: "/partners/join",
      icon: HandshakeIcon
    },
    {
      name: "Premium Partner",
      description: "For established service providers",
      price: 150,
      interval: "month",
      features: [
        "Featured listing placement",
        "Priority lead notifications",
        "Advanced analytics",
        "Priority support",
        "Enhanced visibility",
        "Full profile customization",
        "Customer reviews management"
      ],
      highlight: true,
      cta: "Upgrade to Premium",
      link: "/partners/join?plan=premium",
      icon: Star
    },
    {
      name: "Elite Partner",
      description: "For industry leaders",
      price: "Custom",
      features: [
        "Top listing placement",
        "Instant lead notifications",
        "Real-time analytics",
        "24/7 dedicated support",
        "Maximum visibility",
        "Custom profile features",
        "Marketing opportunities"
      ],
      cta: "Contact Sales",
      link: "#",
      icon: Award
    }
  ];

  const governmentPlans = [
    {
      name: "Municipal",
      description: "For city and local governments",
      price: "Custom",
      features: [
        "Permit management system",
        "Route planning tools",
        "Local regulations integration",
        "Custom workflow automation",
        "Department-specific access",
        "Data export capabilities",
        "Training included"
      ],
      cta: "Request Info",
      link: "#",
      icon: Building
    },
    {
      name: "State/Provincial",
      description: "For state and provincial authorities",
      price: "Custom",
      features: [
        "Multi-jurisdiction management",
        "Advanced permit system",
        "Regional regulations",
        "Custom integrations",
        "Department collaboration",
        "Analytics & reporting",
        "API access"
      ],
      highlight: true,
      cta: "Request Info",
      link: "#",
      icon: Globe
    },
    {
      name: "Federal",
      description: "For federal agencies",
      price: "Custom",
      features: [
        "National system integration",
        "Cross-border management",
        "Federal compliance tools",
        "Custom security features",
        "Enterprise-grade support",
        "Advanced analytics",
        "Full API access"
      ],
      cta: "Contact Us",
      link: "#",
      icon: Scale
    }
  ];

  const trainingPlans = [
    {
      name: "Basic Training",
      description: "Self-paced online learning",
      price: 299,
      interval: "one-time",
      features: [
        "Core system training",
        "Basic route planning",
        "Video tutorials",
        "Practice exercises",
        "Online documentation",
        "3 months access",
        "Email support"
      ],
      cta: "Start Learning",
      link: "/training/basic",
      icon: BookOpen
    },
    {
      name: "Professional Training",
      description: "Instructor-led virtual training",
      price: 799,
      interval: "one-time",
      features: [
        "Live online sessions",
        "Advanced route planning",
        "Interactive workshops",
        "Real-world scenarios",
        "Certification included",
        "6 months access",
        "Priority support"
      ],
      highlight: true,
      cta: "Enroll Now",
      link: "/training/pro",
      icon: GraduationCap
    },
    {
      name: "Enterprise Training",
      description: "Custom training solutions",
      price: "Custom",
      features: [
        "On-site training",
        "Custom curriculum",
        "Team workshops",
        "Train-the-trainer",
        "Custom materials",
        "Unlimited access",
        "Dedicated support"
      ],
      cta: "Contact Us",
      link: "#",
      icon: Video
    }
  ];

  const plans = {
    users: userPlans,
    partners: partnerPlans,
    government: governmentPlans,
    training: trainingPlans
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3 lg:gap-8">
      {plans[type].map((plan, index) => (
        <PricingCard
          key={index}
          plan={plan}
          onRequestDemo={onRequestDemo}
        />
      ))}
    </div>
  );
};