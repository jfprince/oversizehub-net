import React, { useState } from 'react';
import { 
  Check, 
  Ban, 
  Database, 
  Eye, 
  Lock, 
  Shield, 
  Building2, 
  Users, 
  Truck,
  Map,
  FileText,
  Zap,
  Clock,
  Star,
  Download,
  HandshakeIcon,
  Globe,
  Scale,
  Building,
  Award
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { DemoRequest } from '../DemoRequest';

export const PricingTemplate: React.FC = () => {
  const [showDemoRequest, setShowDemoRequest] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'users' | 'partners' | 'government'>('users');

  const userPlans = [
    {
      name: "Pro Solo",
      description: "Perfect for independent professionals",
      price: 20,
      interval: "month",
      features: [
        "Advanced route planning",
        "Custom map creation",
        "Data import/export",
        "Offline access",
        "Basic support",
        "1 user included",
        "Standard response time (72h)"
      ],
      addons: {
        priority: [
          { name: "Next in Line Priority", price: 50 },
          { name: "48h Response", price: 25 },
          { name: "24h Response", price: 35 }
        ],
        features: [
          { name: "CAD File Access", price: 15 },
          { name: "Document Templates", price: 10 }
        ]
      },
      cta: "Start Free Trial",
      link: "/signup/personal",
      icon: Users
    },
    {
      name: "Pro Team",
      description: "Ideal for small teams",
      price: 100,
      interval: "month",
      features: [
        "All Pro Solo features",
        "Team collaboration",
        "Role-based access",
        "Priority support (48h)",
        "Custom branding",
        "Up to 5 users",
        "CAD file export included"
      ],
      addons: {
        priority: [
          { name: "Next in Line Priority", price: 100 },
          { name: "24h Response", price: 50 }
        ],
        features: [
          { name: "Document Templates", price: 25 },
          { name: "Custom Reports", price: 30 }
        ]
      },
      cta: "Start Free Trial",
      link: "/signup/business",
      highlight: true,
      icon: Building2
    },
    {
      name: "Enterprise",
      description: "For large organizations",
      price: "Custom",
      features: [
        "All Pro Team features",
        "Unlimited users",
        "Custom integration",
        "Dedicated support",
        "Next in Line Priority",
        "24/7 emergency support",
        "Full CAD & document access"
      ],
      cta: "Contact Sales",
      link: "#",
      icon: Truck
    }
  ];

  const partnerPlans = [
    {
      name: "Basic Partner",
      description: "For service providers starting out",
      price: 50,
      interval: "month",
      features: [
        "Basic listing in directory",
        "Standard lead notifications",
        "Basic analytics",
        "Email support",
        "Standard visibility",
        "Basic profile customization"
      ],
      icon: HandshakeIcon
    },
    {
      name: "Premium Partner",
      description: "For established service providers",
      price: 150,
      interval: "month",
      features: [
        "Featured listing placement",
        "Priority lead notifications",
        "Advanced analytics",
        "Priority support",
        "Enhanced visibility",
        "Full profile customization",
        "Customer reviews management"
      ],
      highlight: true,
      icon: Star
    },
    {
      name: "Elite Partner",
      description: "For industry leaders",
      price: "Custom",
      features: [
        "Top listing placement",
        "Instant lead notifications",
        "Real-time analytics",
        "24/7 dedicated support",
        "Maximum visibility",
        "Custom profile features",
        "Marketing opportunities"
      ],
      icon: Award
    }
  ];

  const governmentPlans = [
    {
      name: "Municipal",
      description: "For city and local governments",
      price: "Custom",
      features: [
        "Permit management system",
        "Route planning tools",
        "Local regulations integration",
        "Custom workflow automation",
        "Department-specific access",
        "Data export capabilities",
        "Training included"
      ],
      icon: Building
    },
    {
      name: "State/Provincial",
      description: "For state and provincial authorities",
      price: "Custom",
      features: [
        "Multi-jurisdiction management",
        "Advanced permit system",
        "Regional regulations",
        "Custom integrations",
        "Department collaboration",
        "Analytics & reporting",
        "API access"
      ],
      highlight: true,
      icon: Globe
    },
    {
      name: "Federal",
      description: "For federal agencies",
      price: "Custom",
      features: [
        "National system integration",
        "Cross-border management",
        "Federal compliance tools",
        "Custom security features",
        "Enterprise-grade support",
        "Advanced analytics",
        "Full API access"
      ],
      icon: Scale
    }
  ];

  const renderPlans = () => {
    const plans = selectedTab === 'users' ? userPlans : 
                 selectedTab === 'partners' ? partnerPlans : 
                 governmentPlans;

    return (
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3 lg:gap-8">
        {plans.map((plan, index) => (
          <div
            key={index}
            className={`bg-white rounded-lg shadow-lg overflow-hidden ${
              plan.highlight ? 'border-2 border-[#ED4235] ring-2 ring-[#ED4235] ring-opacity-20' : ''
            }`}
          >
            {/* Plan content */}
            <div className="px-6 py-8">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                <plan.icon className="h-8 w-8 text-[#ED4235]" />
              </div>
              <p className="mt-4 text-gray-600">{plan.description}</p>
              <p className="mt-8">
                {typeof plan.price === 'number' ? (
                  <>
                    <span className="text-4xl font-bold text-gray-900">${plan.price}</span>
                    <span className="text-gray-600">/month</span>
                  </>
                ) : (
                  <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                )}
              </p>

              <ul className="mt-8 space-y-4">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>

              {plan.addons && (
                <div className="mt-8 space-y-6">
                  {/* Priority Service Add-ons */}
                  {plan.addons.priority && (
                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-3">Priority Service Options</h4>
                      <div className="space-y-2">
                        {plan.addons.priority.map((addon, idx) => (
                          <div key={idx} className="flex items-center justify-between text-sm">
                            <span className="text-gray-600">{addon.name}</span>
                            <span className="text-[#ED4235]">+${addon.price}/mo</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Feature Add-ons */}
                  {plan.addons.features && (
                    <div>
                      <h4 className="text-sm font-medium text-gray-900 mb-3">Additional Features</h4>
                      <div className="space-y-2">
                        {plan.addons.features.map((addon, idx) => (
                          <div key={idx} className="flex items-center justify-between text-sm">
                            <span className="text-gray-600">{addon.name}</span>
                            <span className="text-[#ED4235]">+${addon.price}/mo</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="px-6 py-4 bg-gray-50">
              <button
                onClick={() => plan.price === 'Custom' ? setShowDemoRequest(true) : null}
                className="block w-full text-center px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
              >
                {plan.price === 'Custom' ? 'Contact Sales' : 'Get Started'}
              </button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Mission Statement */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            Professional Solutions for Heavy Transport
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            OversizeHub.net is dedicated to transforming the heavy transport industry through innovative technology and professional tools. Our mission is to make complex transport operations simpler, safer, and more efficient.
          </p>
        </div>

        {/* Privacy-First Banner */}
        <div className="mb-16 bg-gray-50 rounded-2xl p-8 border border-gray-200">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <Lock className="h-6 w-6 text-[#ED4235] mr-2" />
            Privacy-First and Ad-Free Platform
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="flex items-start space-x-3">
              <Ban className="h-6 w-6 text-[#ED4235] flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-gray-900">No Advertisements</h4>
                <p className="text-gray-600 text-sm">Clean, distraction-free experience across all plans</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Database className="h-6 w-6 text-[#ED4235] flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-gray-900">Your Data is Yours</h4>
                <p className="text-gray-600 text-sm">No data sharing with third parties</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Eye className="h-6 w-6 text-[#ED4235] flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-gray-900">No Tracking</h4>
                <p className="text-gray-600 text-sm">No analytics or social media tracking</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Shield className="h-6 w-6 text-[#ED4235] flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-gray-900">Subscription Only</h4>
                <p className="text-gray-600 text-sm">Transparent pricing, no hidden fees</p>
              </div>
            </div>
          </div>
        </div>

        {/* Plan Type Tabs */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex rounded-lg border border-gray-200 p-1">
            <button
              onClick={() => setSelectedTab('users')}
              className={`px-6 py-2 rounded-md ${
                selectedTab === 'users' 
                  ? 'bg-[#ED4235] text-white' 
                  : 'text-gray-600 hover:text-[#ED4235]'
              }`}
            >
              User Plans
            </button>
            <button
              onClick={() => setSelectedTab('partners')}
              className={`px-6 py-2 rounded-md ${
                selectedTab === 'partners' 
                  ? 'bg-[#ED4235] text-white' 
                  : 'text-gray-600 hover:text-[#ED4235]'
              }`}
            >
              Partner Plans
            </button>
            <button
              onClick={() => setSelectedTab('government')}
              className={`px-6 py-2 rounded-md ${
                selectedTab === 'government' 
                  ? 'bg-[#ED4235] text-white' 
                  : 'text-gray-600 hover:text-[#ED4235]'
              }`}
            >
              Government Plans
            </button>
          </div>
        </div>

        {/* Plan Description */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            {selectedTab === 'users' ? 'Choose Your Plan' :
             selectedTab === 'partners' ? 'Partner With Us' :
             'Government Solutions'}
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            {selectedTab === 'users' ? 'All plans include a 30-day free trial. No credit card required.' :
             selectedTab === 'partners' ? 'Join our network of verified service providers.' :
             'Custom solutions for government agencies.'}
          </p>
        </div>

        {/* Plans Grid */}
        {renderPlans()}

        {/* Start Your Journey Section */}
        <div className="mt-16 bg-gradient-to-r from-[#ED4235]/5 via-[#ED4235]/10 to-[#ED4235]/5 rounded-2xl p-8">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <h3 className="text-2xl font-bold text-gray-900">
              Start Your Journey Today
            </h3>
            <p className="text-lg text-gray-600">
              Join the leading platform for heavy transport professionals and transform your operations.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-6">
              <div className="flex items-center text-gray-600">
                <Check className="h-5 w-5 text-green-500 mr-2" />
                Full Feature Access
              </div>
              <div className="flex items-center text-gray-600">
                <Check className="h-5 w-5 text-green-500 mr-2" />
                No Credit Card Required
              </div>
              <div className="flex items-center text-gray-600">
                <Check className="h-5 w-5 text-green-500 mr-2" />
                Cancel Anytime
              </div>
            </div>
          </div>
        </div>

        {showDemoRequest && (
          <DemoRequest onClose={() => setShowDemoRequest(false)} />
        )}
      </div>
    </div>
  );
};