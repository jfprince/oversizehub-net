import React from 'react';
import { PricingTemplate } from './PricingTemplate';

export const PricingPage: React.FC = () => {
  return <PricingTemplate />;
};