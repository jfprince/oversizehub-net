import React, { useState } from 'react';
import { Users, Building2, Globe, GraduationCap } from 'lucide-react';

interface PricingTabsProps {
  onTabChange: (tab: 'users' | 'partners' | 'government' | 'training') => void;
  activeTab: string;
}

export const PricingTabs: React.FC<PricingTabsProps> = ({ onTabChange, activeTab }) => {
  const tabs = [
    { id: 'users', label: 'Users', icon: Users },
    { id: 'partners', label: 'Service Providers', icon: Building2 },
    { id: 'government', label: 'Government', icon: Globe },
    { id: 'training', label: 'Training', icon: GraduationCap }
  ];

  return (
    <div className="flex justify-center mb-12">
      <div className="inline-flex rounded-lg border border-gray-200 p-1 bg-white">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id as any)}
            className={`flex items-center px-6 py-3 rounded-md ${
              activeTab === tab.id 
                ? 'bg-[#ED4235] text-white' 
                : 'text-gray-600 hover:text-[#ED4235]'
            }`}
          >
            <tab.icon className="h-5 w-5 mr-2" />
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
};