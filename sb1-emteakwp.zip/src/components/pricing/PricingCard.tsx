import React from 'react';
import { LucideIcon } from 'lucide-react';
import { PricingFeature } from './PricingFeature';
import { Link } from 'react-router-dom';

interface PricingCardProps {
  plan: {
    name: string;
    description: string;
    price: number | string;
    interval?: string;
    features: string[];
    cta: string;
    link: string;
    highlight?: boolean;
    icon: LucideIcon;
    addons?: {
      priority?: Array<{ name: string; price: number }>;
      features?: Array<{ name: string; price: number }>;
    };
  };
  onRequestDemo?: () => void;
}

export const PricingCard: React.FC<PricingCardProps> = ({ plan, onRequestDemo }) => {
  return (
    <div className={`bg-white rounded-lg shadow-lg overflow-hidden ${
      plan.highlight ? 'border-2 border-[#ED4235] ring-2 ring-[#ED4235] ring-opacity-20' : ''
    }`}>
      <div className="px-6 py-8">
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
          <plan.icon className="h-8 w-8 text-[#ED4235]" />
        </div>
        <p className="mt-4 text-gray-600">{plan.description}</p>
        <p className="mt-8">
          {typeof plan.price === 'number' ? (
            <>
              <span className="text-4xl font-bold text-gray-900">${plan.price}</span>
              {plan.interval && <span className="text-gray-600">/{plan.interval}</span>}
            </>
          ) : (
            <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
          )}
        </p>

        <ul className="mt-8 space-y-4">
          {plan.features.map((feature, index) => (
            <PricingFeature key={index} feature={feature} />
          ))}
        </ul>

        {plan.addons && (
          <div className="mt-8 space-y-6">
            {plan.addons.priority && (
              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-3">Priority Service Options</h4>
                <div className="space-y-2">
                  {plan.addons.priority.map((addon, idx) => (
                    <div key={idx} className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">{addon.name}</span>
                      <span className="text-[#ED4235]">+${addon.price}/mo</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {plan.addons.features && (
              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-3">Additional Features</h4>
                <div className="space-y-2">
                  {plan.addons.features.map((addon, idx) => (
                    <div key={idx} className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">{addon.name}</span>
                      <span className="text-[#ED4235]">+${addon.price}/mo</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="px-6 py-4 bg-gray-50">
        {plan.price === 'Custom' ? (
          <button
            onClick={onRequestDemo}
            className="w-full text-center px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
          >
            {plan.cta}
          </button>
        ) : (
          <Link
            to={plan.link}
            className="block w-full text-center px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90"
          >
            {plan.cta}
          </Link>
        )}
      </div>
    </div>
  );
};