import React from 'react';
import { useTranslation } from 'react-i18next';

export const LanguageSelector: React.FC = () => {
  const { i18n } = useTranslation();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'fr' : 'en';
    i18n.changeLanguage(newLang);
    localStorage.setItem('i18nextLng', newLang);
  };

  return (
    <button
      onClick={toggleLanguage}
      className="flex items-center justify-center w-8 h-8 rounded-full overflow-hidden hover:opacity-80 transition-opacity"
      title={i18n.language === 'en' ? 'Français' : 'English'}
    >
      <img
        src={i18n.language === 'en' 
          ? 'https://flagcdn.com/w40/fr.png'
          : 'https://flagcdn.com/w40/gb.png'
        }
        alt={i18n.language === 'en' ? 'Français' : 'English'}
        className="w-full h-full object-cover"
      />
    </button>
  );
};