import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from './ui/Logo';
import {
  MapPin,
  Phone,
  Mail,
  Globe,
  Facebook,
  Twitter,
  Linkedin,
  Youtube,
  Clock,
  Shield,
  Users,
  Map,
  FileText,
  HelpCircle,
  Heart
} from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const legalLinks = [
    { label: 'Privacy Policy', href: '/privacy' },
    { label: 'Terms of Service', href: '/terms' },
    { label: 'Cookie Policy', href: '/cookies' },
    { label: 'Accessibility', href: '/accessibility' }
  ];

  const footerSections = [
    {
      title: 'Services',
      links: [
        { label: 'Route Planning', href: '/map' },
        { label: 'Road Survey', href: '/services/road-survey' },
        { label: 'Desktop Survey', href: '/services/desktop-survey' },
        { label: 'Permit Management', href: '/services/permit-management' }
      ]
    },
    {
      title: 'Resources',
      links: [
        { label: 'Documentation', href: '/docs' },
        { label: 'FAQs', href: '/resources/faqs' },
        { label: 'Support', href: '/resources/support' },
        { label: 'Training', href: '/training' }
      ]
    },
    {
      title: 'Company',
      links: [
        { label: 'About Us', href: '/about' },
        { label: 'Careers', href: '/careers' },
        { label: 'Partners', href: '/partners' },
        { label: 'Contact', href: '/contact' }
      ]
    }
  ];

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Logo and Description */}
          <div className="col-span-1 md:col-span-1">
            <Logo className="mb-4" />
            <p className="text-sm text-gray-400">
              Professional solutions for heavy transport and advanced route planning.
              Empowering transport professionals with cutting-edge tools.
            </p>
          </div>

          {/* Footer Sections */}
          {footerSections.map((section, index) => (
            <div key={index}>
              <h3 className="text-lg font-semibold mb-4 text-white">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link
                      to={link.href}
                      className="text-gray-400 hover:text-[#ED4235] transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Social Links */}
        <div className="flex justify-center space-x-6 mb-8">
          {[
            { icon: Facebook, href: '#' },
            { icon: Twitter, href: '#' },
            { icon: Linkedin, href: '#' },
            { icon: Youtube, href: '#' }
          ].map((social, index) => (
            <a
              key={index}
              href={social.href}
              className="text-gray-400 hover:text-[#ED4235] transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              <social.icon className="h-6 w-6" />
            </a>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-gray-400">
              © {currentYear} OversizeHub. All rights reserved. Powered by{' '}
              <a 
                href="https://soltec.ca" 
                className="text-[#ED4235] hover:text-[#ED4235]/90 transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                SolTec.ca
              </a>{' '}
              in partnership with{' '}
              <a 
                href="https://novapermits.com" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#ED4235] hover:text-[#ED4235]/90 transition-colors"
              >
                NovaPermits.com
              </a>{' '}
              and{' '}
              <a 
                href="https://odsna.com" 
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#ED4235] hover:text-[#ED4235]/90 transition-colors"
              >
                ODSna.com
              </a>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              {legalLinks.map((link, index) => (
                <Link
                  key={index}
                  to={link.href}
                  className="text-sm text-gray-400 hover:text-[#ED4235] transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};