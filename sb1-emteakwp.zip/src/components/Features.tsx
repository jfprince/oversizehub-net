import React from 'react';
import {
  Map,
  Truck,
  Users,
  Navigation,
  Shield,
  Database,
  Mountain,
  Eye,
  Layers,
  FileJson,
  Lock,
  Ruler,
  Compass,
  Scale,
  Cloud,
  Zap
} from 'lucide-react';

export const Features: React.FC = () => {
  const features = [
    {
      title: "Advanced Mapping",
      icon: Map,
      description: "Professional-grade mapping solutions",
      items: [
        {
          icon: Layers,
          text: "Multi-layer mapping with custom overlays",
          description: "Create sophisticated maps with multiple data layers and custom visualizations"
        },
        {
          icon: FileJson,
          text: "Universal data compatibility",
          description: "Import/export support for GeoJSON, KML, GPX, and more"
        },
        {
          icon: Eye,
          text: "Enhanced visualization",
          description: "High-resolution satellite imagery and street-level views"
        },
        {
          icon: Mountain,
          text: "Terrain analysis",
          description: "Advanced elevation profiling and gradient analysis"
        }
      ]
    },
    {
      title: "Transport Solutions",
      icon: Truck,
      description: "Comprehensive transport management",
      items: [
        {
          icon: Navigation,
          text: "Intelligent routing",
          description: "Advanced algorithms for optimal heavy transport routing"
        },
        {
          icon: Shield,
          text: "Compliance management",
          description: "Real-time regulation tracking and permit requirements"
        },
        {
          icon: Ruler,
          text: "Precision measurements",
          description: "Accurate clearance and restriction calculations"
        },
        {
          icon: Scale,
          text: "Load optimization",
          description: "Smart weight distribution and capacity planning"
        }
      ]
    },
    {
      title: "Collaboration",
      icon: Users,
      description: "Seamless team coordination",
      items: [
        {
          icon: Cloud,
          text: "Real-time synchronization",
          description: "Instant updates and changes across team members"
        },
        {
          icon: Database,
          text: "Centralized data",
          description: "Unified storage for routes, permits, and documentation"
        },
        {
          icon: Lock,
          text: "Secure sharing",
          description: "Enterprise-grade security for sensitive data"
        },
        {
          icon: Zap,
          text: "Live tracking",
          description: "Real-time fleet and asset monitoring"
        }
      ]
    }
  ];

  return (
    <section id="features" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Professional Transport Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everything you need to plan, manage, and optimize your transport operations
            with industry-leading tools and technology.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 hover:shadow-2xl transition-shadow duration-300"
            >
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="bg-[#ED4235]/10 p-3 rounded-xl">
                    <feature.icon className="h-8 w-8 text-[#ED4235]" />
                  </div>
                  <div className="ml-4">
                    <h3 className="text-2xl font-bold text-gray-900">{feature.title}</h3>
                    <p className="text-gray-600 mt-1">{feature.description}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  {feature.items.map((item, itemIndex) => (
                    <div key={itemIndex} className="group">
                      <div className="flex items-start">
                        <div className="bg-gray-50 p-2 rounded-lg group-hover:bg-[#ED4235]/10 transition-colors">
                          <item.icon className="h-5 w-5 text-[#ED4235]" />
                        </div>
                        <div className="ml-4">
                          <h4 className="text-base font-semibold text-gray-900">
                            {item.text}
                          </h4>
                          <p className="text-sm text-gray-600 mt-1">
                            {item.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;