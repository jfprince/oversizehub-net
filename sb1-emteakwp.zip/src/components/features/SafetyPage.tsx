import React, { useState } from 'react';
import { Shield, FileCheck, AlertTriangle, Scale, Truck, FileText, ChevronDown, Info, MapPin, Globe, Zap } from 'lucide-react';
import { safetyRequirements, generalSafetyInfo } from '../../data/safety';
import { Take5Form } from './Take5Form';

export const SafetyPage: React.FC = () => {
  const [expandedJurisdiction, setExpandedJurisdiction] = useState<string | null>(null);
  const [expandedSection, setExpandedSection] = useState<string>("general");
  const [region, setRegion] = useState<'canada' | 'usa'>('canada');

  const renderJurisdictionContent = (jurisdiction: any) => {
    if (jurisdiction.dataStatus === 'pending') {
      return (
        <div className="p-6 text-center text-gray-500">
          <p>Detailed safety information for {jurisdiction.name} is coming soon.</p>
          <p className="text-sm mt-2">Please check back later or contact local authorities for current requirements.</p>
        </div>
      );
    }

    return (
      <div className="p-6 space-y-6">
        {/* Pre-Trip Requirements */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Truck className="h-5 w-5 text-[#ED4235] mr-2" />
            Pre-Trip Requirements
          </h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <ul className="space-y-2">
              {jurisdiction.requirements.preTrip.map((requirement: string, index: number) => (
                <li key={index} className="flex items-start">
                  <FileCheck className="h-5 w-5 text-[#ED4235] mr-2 mt-0.5" />
                  <span className="text-gray-700">{requirement}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Equipment Requirements */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Shield className="h-5 w-5 text-[#ED4235] mr-2" />
            Equipment Requirements
          </h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <ul className="space-y-2">
              {jurisdiction.requirements.equipment.map((requirement: string, index: number) => (
                <li key={index} className="flex items-start">
                  <FileCheck className="h-5 w-5 text-[#ED4235] mr-2 mt-0.5" />
                  <span className="text-gray-700">{requirement}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Documentation Requirements */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <FileText className="h-5 w-5 text-[#ED4235] mr-2" />
            Documentation Requirements
          </h3>
          <div className="bg-gray-50 p-4 rounded-lg">
            <ul className="space-y-2">
              {jurisdiction.requirements.documentation.map((requirement: string, index: number) => (
                <li key={index} className="flex items-start">
                  <FileCheck className="h-5 w-5 text-[#ED4235] mr-2 mt-0.5" />
                  <span className="text-gray-700">{requirement}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    );
  };

  const getStatusBadge = (jurisdiction: any) => {
    if (jurisdiction.dataStatus === 'pending') {
      return (
        <span className="ml-3 px-2 py-1 text-xs font-medium text-gray-500 bg-gray-100 rounded">
          Coming Soon
        </span>
      );
    }

    const lastUpdate = jurisdiction.lastUpdate ? new Date(jurisdiction.lastUpdate) : null;
    const now = new Date();
    const daysSinceUpdate = lastUpdate ? Math.floor((now.getTime() - lastUpdate.getTime()) / (1000 * 60 * 60 * 24)) : null;

    if (daysSinceUpdate !== null && daysSinceUpdate <= 45) {
      return (
        <span className="ml-3 px-2 py-1 text-xs font-medium text-green-700 bg-green-100 rounded">
          Recently Updated
        </span>
      );
    }

    if (lastUpdate) {
      return (
        <span className="ml-3 px-2 py-1 text-xs font-medium text-blue-700 bg-blue-100 rounded">
          Updated: {lastUpdate.toLocaleDateString()}
        </span>
      );
    }

    return null;
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">
            Safety Requirements
          </h1>
          <p className="mt-4 text-xl text-gray-600">
            Comprehensive guide to safety regulations and requirements
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-4 mb-8">
          <button
            onClick={() => setExpandedSection("general")}
            className={`px-4 py-2 rounded-lg ${
              expandedSection === "general"
                ? "bg-[#ED4235] text-white"
                : "bg-white text-gray-700 hover:bg-gray-50"
            }`}
          >
            <div className="flex items-center">
              <Info className="h-5 w-5 mr-2" />
              General Information
            </div>
          </button>
          <button
            onClick={() => setExpandedSection("jurisdictions")}
            className={`px-4 py-2 rounded-lg ${
              expandedSection === "jurisdictions"
                ? "bg-[#ED4235] text-white"
                : "bg-white text-gray-700 hover:bg-gray-50"
            }`}
          >
            <div className="flex items-center">
              <Globe className="h-5 w-5 mr-2" />
              Regional Requirements
            </div>
          </button>
          <button
            onClick={() => setExpandedSection("powerlines")}
            className={`px-4 py-2 rounded-lg ${
              expandedSection === "powerlines"
                ? "bg-[#ED4235] text-white"
                : "bg-white text-gray-700 hover:bg-gray-50"
            }`}
          >
            <div className="flex items-center">
              <Zap className="h-5 w-5 mr-2" />
              Power Line Safety
            </div>
          </button>
        </div>

        {/* General Information Section */}
        {expandedSection === "general" && (
          <div className="space-y-8">
            {generalSafetyInfo.sections.map((section, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                  <Shield className="h-6 w-6 text-[#ED4235] mr-3" />
                  {section.title}
                </h2>
                <ul className="space-y-3">
                  {section.items.map((item, itemIndex) => (
                    <li key={itemIndex} className="flex items-start">
                      <FileCheck className="h-5 w-5 text-[#ED4235] mr-3 mt-0.5" />
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>

                {section.title === "Operating Procedures" && (
                  <div className="mt-8 border-t border-gray-200 pt-8">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Take 5 Safety Checklist</h3>
                    <Take5Form />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Jurisdictions Section */}
        {expandedSection === "jurisdictions" && (
          <>
            {/* Region Toggle */}
            <div className="flex space-x-4 mb-8">
              <button
                onClick={() => setRegion('canada')}
                className={`px-6 py-3 rounded-lg flex items-center ${
                  region === 'canada'
                    ? 'bg-[#ED4235] text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                Canadian Provinces
              </button>
              <button
                onClick={() => setRegion('usa')}
                className={`px-6 py-3 rounded-lg flex items-center ${
                  region === 'usa'
                    ? 'bg-[#ED4235] text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                US States
              </button>
            </div>

            <div className="space-y-6">
              {(region === 'canada' ? safetyRequirements.canada.provinces : safetyRequirements.usa.states).map((jurisdiction) => (
                <div key={jurisdiction.name} className="bg-white rounded-lg shadow-lg overflow-hidden">
                  <button
                    onClick={() => setExpandedJurisdiction(
                      expandedJurisdiction === jurisdiction.name ? null : jurisdiction.name
                    )}
                    className="w-full px-6 py-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center">
                      <Shield className="h-6 w-6 text-[#ED4235] mr-3" />
                      <h2 className="text-xl font-semibold text-gray-900">{jurisdiction.name}</h2>
                      {getStatusBadge(jurisdiction)}
                    </div>
                    <ChevronDown 
                      className={`h-5 w-5 text-gray-500 transition-transform ${
                        expandedJurisdiction === jurisdiction.name ? 'rotate-180' : ''
                      }`} 
                    />
                  </button>

                  {expandedJurisdiction === jurisdiction.name && renderJurisdictionContent(jurisdiction)}
                </div>
              ))}
            </div>
          </>
        )}

        {/* Power Line Safety Section */}
        {expandedSection === "powerlines" && (
          <div className="space-y-8">
            {/* Introduction */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <Zap className="h-7 w-7 text-[#ED4235] mr-3" />
                Power Line Safety Guidelines
              </h2>
              <div className="prose max-w-none">
                <p className="text-gray-600 mb-4">
                  Power lines present a critical safety consideration for oversized load transport. 
                  Proper clearance and safety protocols must be followed to prevent potentially fatal accidents.
                </p>
              </div>
            </div>

            {/* Canada Section */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Canadian Requirements</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Minimum Clearance Requirements</h4>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>High voltage lines (over 750V): Minimum 3 meters (10 feet) clearance</li>
                    <li>Distribution lines (under 750V): Distance requirements vary by province</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Safety Protocols</h4>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Mandatory route surveys to identify power line hazards</li>
                    <li>Safety escorts required for loads near minimum clearance</li>
                    <li>Temporary line disconnection may be required for certain routes</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* USA Section */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">United States Requirements</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">OSHA Requirements</h4>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Lines over 50kV: Minimum 10 feet (3.05 meters) clearance</li>
                    <li>Lines under 50kV: Minimum 4 feet (1.22 meters) clearance</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Safety Measures</h4>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Advance coordination with utility companies</li>
                    <li>Special permits for routes with power line crossings</li>
                    <li>Mandatory safety briefings for transport teams</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Best Practices */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Best Practices</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Pre-Transport Planning</h4>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Complete route survey for power line locations</li>
                    <li>Obtain necessary permits and clearances</li>
                    <li>Coordinate with utility companies</li>
                    <li>Plan alternative routes if needed</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">During Transport</h4>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Maintain minimum clearance distances</li>
                    <li>Use spotters for guidance</li>
                    <li>Monitor weather conditions</li>
                    <li>Follow established emergency procedures</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Emergency Procedures */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <AlertTriangle className="h-6 w-6 text-[#ED4235] mr-2" />
                Emergency Procedures
              </h3>
              <div className="bg-red-50 border-l-4 border-red-400 p-4">
                <p className="text-red-700 font-medium">In case of contact with power lines:</p>
                <ul className="list-disc list-inside mt-2 space-y-1 text-red-600">
                  <li>Stay in the vehicle unless there's immediate danger</li>
                  <li>Keep others away from the vehicle</li>
                  <li>Contact emergency services immediately</li>
                  <li>Wait for utility company personnel to confirm it's safe</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};