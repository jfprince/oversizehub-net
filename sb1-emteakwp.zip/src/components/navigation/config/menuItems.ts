import {
  Home,
  Map,
  LayoutGrid,
  Users,
  Settings,
  HelpCircle,
  FileText,
  Building2,
  Mail,
  DollarSign,
  Truck,
  Shield,
  Navigation
} from 'lucide-react';
import { NavItemType } from '../types';

export const mainNavItems: NavItemType[] = [
  {
    id: 'home',
    label: 'Home',
    link: '/',
    icon: Home
  },
  {
    id: 'map',
    label: 'Map',
    link: '/map',
    icon: Map
  },
  {
    id: 'features',
    label: 'Features',
    icon: LayoutGrid,
    subItems: [
      { id: 'mapping', label: 'Route Planning', link: '/features/mapping', icon: Navigation },
      { id: 'transport', label: 'Transport Solutions', link: '/features/transport', icon: Truck },
      { id: 'compliance', label: 'Compliance', link: '/features/compliance', icon: Shield },
      { id: 'safety', label: 'Safety', link: '/features/safety', icon: Shield },
      { id: 'collaboration', label: 'Team Collaboration', link: '/features/collaboration', icon: Users }
    ]
  },
  {
    id: 'pricing',
    label: 'Pricing',
    link: '/pricing',
    icon: DollarSign,
    subItems: [
      { id: 'pro-solo', label: 'Pro Solo', link: '/pricing#pro-solo', icon: Users },
      { id: 'pro-team', label: 'Pro Team', link: '/pricing#pro-team', icon: Building2 },
      { id: 'enterprise', label: 'Enterprise', link: '/pricing#enterprise', icon: Shield }
    ]
  },
  {
    id: 'resources',
    label: 'Resources',
    icon: HelpCircle,
    subItems: [
      { id: 'documentation', label: 'Documentation', link: '/docs', icon: FileText },
      { id: 'support', label: 'Support', link: '/support', icon: Mail },
      { id: 'settings', label: 'Settings', link: '/settings', icon: Settings }
    ]
  }
];