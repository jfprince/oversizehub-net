import React, { useState } from 'react';
import { Upload, Download, FileText, Image as ImageIcon } from 'lucide-react';

export const DataManagement: React.FC = () => {
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    // Handle the dropped files
    const files = Array.from(e.dataTransfer.files);
    console.log('Dropped files:', files);
  };

  const supportedFormats = [
    { label: 'PDF', ext: '.pdf', icon: FileText },
    { label: 'GeoJSON', ext: '.geojson', icon: FileText },
    { label: 'KML/KMZ', ext: '.kml,.kmz', icon: FileText },
    { label: 'GPX', ext: '.gpx', icon: FileText },
    { label: 'Excel', ext: '.xlsx,.xls,.ods,.csv', icon: FileText },
    { label: 'Shapefile ZIP', ext: '.zip', icon: FileText },
    { label: 'Images', ext: '.jpg,.png', icon: ImageIcon }
  ];

  return (
    <div className="space-y-6">
      {/* Import Section */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-2">Import Data</h3>
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-lg p-6 text-center ${
            dragActive
              ? 'border-[#ED4235] bg-[#ED4235]/5'
              : 'border-gray-300 hover:border-[#ED4235] hover:bg-gray-50'
          }`}
        >
          <Upload className="h-8 w-8 mx-auto text-gray-400 mb-4" />
          <p className="text-sm text-gray-600">
            Drag and drop files here or{' '}
            <button className="text-[#ED4235] hover:text-[#ED4235]/80 font-medium">
              browse files
            </button>
          </p>
          <p className="text-xs text-gray-500 mt-2">
            Supported formats: PDF, GeoJSON, KML/KMZ, GPX, Excel, Shapefile ZIP, Images
          </p>
        </div>
      </div>

      {/* Cross Connections */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-2">Cross Connections</h3>
        <div className="bg-gray-50 rounded-lg p-4">
          <p className="text-sm text-gray-600">
            Images / XLS cross connections for laser measurement device
          </p>
          <button className="mt-2 px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90 text-sm">
            Configure Cross Connections
          </button>
        </div>
      </div>

      {/* Export Section */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-2">Export Data</h3>
        <div className="space-y-2">
          {supportedFormats.map((format) => (
            <button
              key={format.ext}
              className="w-full flex items-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              <format.icon className="h-4 w-4 text-gray-400 mr-2" />
              <span className="text-sm text-gray-700">Export as {format.label}</span>
            </button>
          ))}
          <button className="w-full flex items-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
            <FileText className="h-4 w-4 text-gray-400 mr-2" />
            <span className="text-sm text-gray-700">Export as OversizeHub Archive ZIP</span>
          </button>
        </div>
      </div>
    </div>
  );
};