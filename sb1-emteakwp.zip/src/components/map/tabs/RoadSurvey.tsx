import React, { useState } from 'react';
import { 
  Camera, 
  Ruler, 
  FileText, 
  MapPin,
  Plus,
  Upload,
  Download,
  Trash,
  Image
} from 'lucide-react';

interface SurveyPoint {
  id: string;
  type: 'measurement' | 'photo' | 'note';
  location: string;
  data: string;
  timestamp: Date;
}

export const RoadSurvey: React.FC = () => {
  const [surveyPoints, setSurveyPoints] = useState<SurveyPoint[]>([]);
  const [activePoint, setActivePoint] = useState<string | null>(null);

  const addSurveyPoint = (type: SurveyPoint['type']) => {
    const newPoint: SurveyPoint = {
      id: Date.now().toString(),
      type,
      location: '45.5017° N, 73.5673° W',
      data: '',
      timestamp: new Date()
    };
    setSurveyPoints([...surveyPoints, newPoint]);
    setActivePoint(newPoint.id);
  };

  const removeSurveyPoint = (id: string) => {
    setSurveyPoints(surveyPoints.filter(point => point.id !== id));
    if (activePoint === id) {
      setActivePoint(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Tools Section */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-3">Survey Tools</h3>
        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => addSurveyPoint('measurement')}
            className="flex items-center justify-center p-3 bg-gray-100 rounded-md hover:bg-gray-200"
          >
            <Ruler className="h-5 w-5 mr-2" />
            Add Measurement
          </button>
          <button
            onClick={() => addSurveyPoint('photo')}
            className="flex items-center justify-center p-3 bg-gray-100 rounded-md hover:bg-gray-200"
          >
            <Camera className="h-5 w-5 mr-2" />
            Add Photo
          </button>
          <button
            onClick={() => addSurveyPoint('note')}
            className="flex items-center justify-center p-3 bg-gray-100 rounded-md hover:bg-gray-200"
          >
            <FileText className="h-5 w-5 mr-2" />
            Add Note
          </button>
        </div>
      </div>

      {/* Survey Points List */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-3">Survey Points</h3>
        <div className="space-y-2">
          {surveyPoints.map((point) => (
            <div
              key={point.id}
              className={`p-3 rounded-md border ${
                activePoint === point.id
                  ? 'border-[#ED4235] bg-red-50'
                  : 'border-gray-200 hover:border-gray-300 bg-white'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {point.type === 'measurement' && <Ruler className="h-4 w-4 text-[#ED4235] mr-2" />}
                  {point.type === 'photo' && <Image className="h-4 w-4 text-[#ED4235] mr-2" />}
                  {point.type === 'note' && <FileText className="h-4 w-4 text-[#ED4235] mr-2" />}
                  <div>
                    <div className="text-sm font-medium">
                      {point.type.charAt(0).toUpperCase() + point.type.slice(1)}
                    </div>
                    <div className="text-xs text-gray-500">{point.location}</div>
                  </div>
                </div>
                <button
                  onClick={() => removeSurveyPoint(point.id)}
                  className="text-gray-400 hover:text-red-500"
                >
                  <Trash className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
          {surveyPoints.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No survey points added yet
            </div>
          )}
        </div>
      </div>

      {/* Export/Import */}
      <div className="flex space-x-3">
        <button className="flex-1 flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
          <Upload className="h-4 w-4 mr-2" />
          Import Survey
        </button>
        <button className="flex-1 flex items-center justify-center px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
          <Download className="h-4 w-4 mr-2" />
          Export Survey
        </button>
      </div>
    </div>
  );
};