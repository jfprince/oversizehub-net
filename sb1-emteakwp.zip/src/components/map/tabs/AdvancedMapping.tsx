import React, { useState } from 'react';
import { 
  Layers, 
  Ruler, 
  Compass, 
  Map as MapIcon,
  Eye,
  Settings,
  Plus,
  Trash
} from 'lucide-react';

export const AdvancedMapping: React.FC = () => {
  const [activeTool, setActiveTool] = useState<string | null>(null);
  const [layers, setLayers] = useState<string[]>(['Base Layer']);
  const [measurements, setMeasurements] = useState<any[]>([]);

  const tools = [
    { id: 'measure', label: 'Measure', icon: Ruler },
    { id: 'compass', label: 'Bearing', icon: Compass },
    { id: 'overlay', label: 'Overlay', icon: Layers },
    { id: 'visibility', label: 'Visibility', icon: Eye }
  ];

  return (
    <div className="space-y-6">
      {/* Tools Section */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-3">Mapping Tools</h3>
        <div className="grid grid-cols-2 gap-3">
          {tools.map((tool) => (
            <button
              key={tool.id}
              onClick={() => setActiveTool(activeTool === tool.id ? null : tool.id)}
              className={`flex items-center justify-center p-3 rounded-md ${
                activeTool === tool.id
                  ? 'bg-[#ED4235] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <tool.icon className="h-5 w-5 mr-2" />
              {tool.label}
            </button>
          ))}
        </div>
      </div>

      {/* Layer Management */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-gray-700">Custom Layers</h3>
          <button
            onClick={() => setLayers([...layers, `Layer ${layers.length + 1}`])}
            className="text-[#ED4235] hover:text-[#ED4235]/80 text-sm font-medium"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-2">
          {layers.map((layer, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-2 bg-gray-50 rounded-md"
            >
              <div className="flex items-center">
                <MapIcon className="h-4 w-4 text-gray-400 mr-2" />
                <span className="text-sm text-gray-700">{layer}</span>
              </div>
              {index > 0 && (
                <button
                  onClick={() => setLayers(layers.filter((_, i) => i !== index))}
                  className="text-gray-400 hover:text-red-500"
                >
                  <Trash className="h-4 w-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Settings */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center">
          <Settings className="h-4 w-4 mr-2" />
          Advanced Settings
        </h3>
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium text-gray-700">Measurement Units</label>
            <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]">
              <option value="metric">Metric (meters)</option>
              <option value="imperial">Imperial (feet)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Bearing Format</label>
            <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]">
              <option value="degrees">Degrees</option>
              <option value="mils">Mils</option>
              <option value="cardinal">Cardinal Directions</option>
            </select>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end space-x-3">
        <button className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
          Reset
        </button>
        <button className="px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
          Apply Changes
        </button>
      </div>
    </div>
  );
};