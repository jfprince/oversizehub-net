import React, { useState } from 'react';
import { Link2, Image, FileText, Video, MapPin, FolderPlus } from 'lucide-react';

interface Group {
  id: string;
  name: string;
  visible: boolean;
  subgroups: {
    id: string;
    name: string;
    visible: boolean;
  }[];
}

export const ItemManager: React.FC = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [link, setLink] = useState('');
  const [markerColor, setMarkerColor] = useState('#ED4235');
  const [markerType, setMarkerType] = useState('pin');
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);

  const handleAddGroup = () => {
    const newGroup = {
      id: Date.now().toString(),
      name: 'New Group',
      visible: true,
      subgroups: []
    };
    setGroups([...groups, newGroup]);
  };

  const handleAddSubgroup = (groupId: string) => {
    setGroups(groups.map(group => {
      if (group.id === groupId) {
        return {
          ...group,
          subgroups: [
            ...group.subgroups,
            {
              id: Date.now().toString(),
              name: 'New Subgroup',
              visible: true
            }
          ]
        };
      }
      return group;
    }));
  };

  return (
    <div className="space-y-6">
      {/* Basic Info */}
      <div>
        <label className="block text-sm font-medium text-gray-700">Title</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Description</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        />
      </div>

      {/* Link */}
      <div>
        <label className="block text-sm font-medium text-gray-700 flex items-center">
          <Link2 className="h-4 w-4 mr-2" />
          Link to
        </label>
        <input
          type="url"
          value={link}
          onChange={(e) => setLink(e.target.value)}
          placeholder="http://"
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        />
      </div>

      {/* Media Upload */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-700">Add Media</h3>
        <div className="grid grid-cols-2 gap-4">
          <button className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
            <Image className="h-4 w-4 mr-2" />
            Add Image
          </button>
          <button className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
            <FileText className="h-4 w-4 mr-2" />
            Add PDF
          </button>
          <button className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
            <Video className="h-4 w-4 mr-2" />
            Add Video
          </button>
        </div>
      </div>

      {/* Marker Settings */}
      <div className="space-y-4">
        <h3 className="text-sm font-medium text-gray-700">Marker Settings</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Color</label>
            <input
              type="color"
              value={markerColor}
              onChange={(e) => setMarkerColor(e.target.value)}
              className="mt-1 block w-full h-10 rounded-md border-gray-300"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Type</label>
            <select
              value={markerType}
              onChange={(e) => setMarkerType(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
            >
              <option value="pin">Pin</option>
              <option value="circle">Circle</option>
              <option value="square">Square</option>
            </select>
          </div>
        </div>
      </div>

      {/* Groups */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-700">Groups</h3>
          <button
            onClick={handleAddGroup}
            className="text-[#ED4235] hover:text-[#ED4235]/80 text-sm font-medium flex items-center"
          >
            <FolderPlus className="h-4 w-4 mr-1" />
            Add Group
          </button>
        </div>

        <div className="space-y-2">
          {groups.map(group => (
            <div key={group.id} className="space-y-2">
              <div className="flex items-center justify-between bg-gray-50 p-2 rounded-md">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={group.visible}
                    onChange={(e) => {
                      setGroups(groups.map(g => 
                        g.id === group.id ? { ...g, visible: e.target.checked } : g
                      ));
                    }}
                    className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
                  />
                  <span className="ml-2 text-sm text-gray-700">{group.name}</span>
                </div>
                <button
                  onClick={() => handleAddSubgroup(group.id)}
                  className="text-gray-400 hover:text-[#ED4235]"
                >
                  <FolderPlus className="h-4 w-4" />
                </button>
              </div>

              {/* Subgroups */}
              <div className="ml-6 space-y-2">
                {group.subgroups.map(subgroup => (
                  <div key={subgroup.id} className="flex items-center justify-between bg-gray-50 p-2 rounded-md">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        checked={subgroup.visible}
                        onChange={(e) => {
                          setGroups(groups.map(g => 
                            g.id === group.id ? {
                              ...g,
                              subgroups: g.subgroups.map(s =>
                                s.id === subgroup.id ? { ...s, visible: e.target.checked } : s
                              )
                            } : g
                          ));
                        }}
                        className="rounded border-gray-300 text-[#ED4235] focus:ring-[#ED4235]"
                      />
                      <span className="ml-2 text-sm text-gray-700">{subgroup.name}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Save Button */}
      <div>
        <button className="w-full px-4 py-2 bg-[#ED4235] text-white rounded-md hover:bg-opacity-90">
          Save Item
        </button>
      </div>
    </div>
  );
};