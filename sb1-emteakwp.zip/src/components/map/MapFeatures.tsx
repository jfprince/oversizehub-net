import React, { useState } from 'react';
import { 
  Map as MapIcon, 
  Layers, 
  Image, 
  FileText, 
  Download, 
  Upload,
  Plus,
  Edit3,
  Type,
  Circle,
  Square,
  Pencil
} from 'lucide-react';

interface MapFeature {
  id: string;
  type: 'point' | 'line' | 'polygon';
  coordinates: number[][];
  properties: {
    label?: string;
    media?: {
      type: 'image' | 'video' | 'document';
      url: string;
    }[];
  };
}

export const MapFeatures: React.FC = () => {
  const [activeLayer, setActiveLayer] = useState('default');
  const [drawingMode, setDrawingMode] = useState<'point' | 'line' | 'polygon' | null>(null);
  const [features, setFeatures] = useState<MapFeature[]>([]);

  const drawingTools = [
    { id: 'point', label: 'Add Point', icon: Circle },
    { id: 'line', label: 'Draw Line', icon: Pencil },
    { id: 'polygon', label: 'Draw Area', icon: Square }
  ];

  const supportedFormats = [
    { label: 'GeoJSON', ext: '.geojson' },
    { label: 'Shapefile', ext: '.shp' },
    { label: 'KML', ext: '.kml' },
    { label: 'GPX', ext: '.gpx' },
    { label: 'CSV', ext: '.csv' },
    { label: 'PDF', ext: '.pdf' }
  ];

  return (
    <div className="absolute left-4 top-[calc(4rem+24rem)] bg-white rounded-lg shadow-lg p-4 w-96">
      <div className="space-y-4">
        {/* Drawing Tools */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center">
            <Edit3 className="h-4 w-4 mr-2" />
            Drawing Tools
          </h3>
          <div className="grid grid-cols-3 gap-2">
            {drawingTools.map((tool) => (
              <button
                key={tool.id}
                onClick={() => setDrawingMode(tool.id as any)}
                className={`flex items-center justify-center p-3 rounded-md space-x-2 ${
                  drawingMode === tool.id 
                    ? 'bg-[#ED4235] text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                title={tool.label}
              >
                <tool.icon className="h-4 w-4" />
                <span className="text-sm">{tool.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Layer Management */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center">
            <Layers className="h-4 w-4 mr-2" />
            Map Layers
          </h3>
          <div className="space-y-2">
            <button
              onClick={() => setActiveLayer('default')}
              className={`w-full flex items-center px-3 py-2 rounded-md ${
                activeLayer === 'default'
                  ? 'bg-[#ED4235] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <MapIcon className="h-4 w-4 mr-2" />
              Base Layer
            </button>
            <button
              className="w-full flex items-center px-3 py-2 bg-gray-100 text-gray-700 hover:bg-gray-200 rounded-md"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add New Layer
            </button>
          </div>
        </div>

        {/* Import/Export */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center">
            <FileText className="h-4 w-4 mr-2" />
            Data Management
          </h3>
          <div className="space-y-2">
            <label className="block">
              <span className="sr-only">Import File</span>
              <div className="relative">
                <input
                  type="file"
                  className="hidden"
                  accept=".geojson,.shp,.kml,.gpx,.csv,.pdf"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      // Handle import
                    }
                  }}
                />
                <button 
                  onClick={() => document.querySelector('input[type="file"]')?.click()}
                  className="w-full flex items-center justify-center px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Import Data
                </button>
              </div>
            </label>
            <div className="relative group">
              <button
                className="w-full flex items-center justify-center px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </button>
              <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                {supportedFormats.map((format) => (
                  <button
                    key={format.ext}
                    onClick={() => {/* Handle export */}}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    {format.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};