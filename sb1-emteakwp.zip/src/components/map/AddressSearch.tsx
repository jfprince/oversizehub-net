import React, { useState, useEffect } from 'react';
import { Search, MapPin, Crosshair } from 'lucide-react';
import { useDebounce } from 'use-debounce';

interface AddressSearchProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  onCoordinateSelect?: (coords: [number, number]) => void;
}

export const AddressSearch: React.FC<AddressSearchProps> = ({ 
  value, 
  onChange,
  placeholder,
  onCoordinateSelect 
}) => {
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [debouncedValue] = useDebounce(value, 300);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (!debouncedValue || debouncedValue.length < 3) {
        setSuggestions([]);
        return;
      }

      try {
        const response = await fetch(
          `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(debouncedValue)}.json?` +
          `access_token=${import.meta.env.VITE_MAPBOX_TOKEN}&types=address,place`
        );
        const data = await response.json();
        setSuggestions(data.features);
        setShowSuggestions(true);
      } catch (error) {
        console.error('Error fetching suggestions:', error);
      }
    };

    fetchSuggestions();
  }, [debouncedValue]);

  const handleSuggestionClick = (suggestion: any) => {
    onChange(suggestion.place_name);
    if (onCoordinateSelect) {
      onCoordinateSelect(suggestion.center.reverse() as [number, number]);
    }
    setShowSuggestions(false);
  };

  const handleUseCurrentLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        onChange(`${latitude}, ${longitude}`);
        if (onCoordinateSelect) {
          onCoordinateSelect([latitude, longitude]);
        }
      });
    }
  };

  return (
    <div className="relative">
      <div className="relative">
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="block w-full rounded-md border-gray-300 pl-10 pr-12 shadow-sm focus:border-[#ED4235] focus:ring-[#ED4235]"
        />
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <button
          type="button"
          onClick={handleUseCurrentLocation}
          className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-[#ED4235]"
        >
          <Crosshair className="h-5 w-5" />
        </button>
      </div>

      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-10 mt-1 w-full bg-white rounded-md shadow-lg">
          {suggestions.map((suggestion, index) => (
            <button
              key={index}
              onClick={() => handleSuggestionClick(suggestion)}
              className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <MapPin className="h-4 w-4 text-gray-400 mr-2" />
              {suggestion.place_name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};