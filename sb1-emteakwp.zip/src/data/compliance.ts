export interface JurisdictionInfo {
  name: string;
  standardDimensions?: {
    width: string;
    height: string;
    length: {
      single: string;
      combined: string;
    };
  };
  escortRequirements?: {
    width: {
      civil: string;
      police: string;
    };
    length: {
      civil: string;
      police: string;
    };
    height?: {
      civil: string;
      pole: string;
    };
  };
  restrictions?: {
    time: string[];
    holidays: string;
  };
  permitInfo?: {
    site: string;
    cost: string;
    processingTime: string;
    notes: string;
  };
  dataStatus: 'complete' | 'partial' | 'pending';
}

export const canadianProvinces: JurisdictionInfo[] = [
  {
    name: "Alberta",
    dataStatus: "pending"
  },
  {
    name: "British Columbia",
    standardDimensions: {
      width: "2.6 metres",
      height: "4.15 metres",
      length: {
        single: "12.5 metres",
        combined: "23 metres"
      }
    },
    escortRequirements: {
      width: {
        civil: "≥ 3.2 metres",
        police: "≥ 4.4 metres"
      },
      length: {
        civil: "≥ 27.5 metres",
        police: "≥ 35 metres"
      }
    },
    restrictions: {
      time: [
        "Urban area peak hour restrictions",
        "Enhanced visibility required for night moves",
        "Seasonal road restrictions may apply"
      ],
      holidays: "No movement on statutory holidays"
    },
    permitInfo: {
      site: "www2.gov.bc.ca/gov/content/transportation/vehicle-safety-enforcement",
      cost: "$15 per axle for standard permits",
      processingTime: "2-5 business days",
      notes: "Coastal routes may have special requirements"
    },
    dataStatus: "complete"
  },
  {
    name: "Manitoba",
    dataStatus: "pending"
  },
  {
    name: "New Brunswick",
    dataStatus: "pending"
  },
  {
    name: "Newfoundland and Labrador",
    dataStatus: "pending"
  },
  {
    name: "Northwest Territories",
    dataStatus: "pending"
  },
  {
    name: "Nova Scotia",
    dataStatus: "pending"
  },
  {
    name: "Nunavut",
    dataStatus: "pending"
  },
  {
    name: "Ontario",
    standardDimensions: {
      width: "2.6 metres",
      height: "4.15 metres",
      length: {
        single: "12.5 metres",
        combined: "23 metres"
      }
    },
    escortRequirements: {
      width: {
        civil: "≥ 3.7 metres",
        police: "≥ 4.5 metres"
      },
      length: {
        civil: "≥ 30 metres",
        police: "≥ 36.75 metres"
      },
      height: {
        civil: "≥ 4.26 metres",
        pole: "Required"
      }
    },
    restrictions: {
      time: [
        "Restricted during peak hours in urban areas",
        "Night movement requires enhanced lighting",
        "Holiday restrictions apply"
      ],
      holidays: "No movement on statutory holidays"
    },
    permitInfo: {
      site: "ontario.ca/page/oversize-overweight-permits",
      cost: "$35-500 depending on configuration",
      processingTime: "3-5 business days",
      notes: "Local permits may be required"
    },
    dataStatus: "complete"
  },
  {
    name: "Prince Edward Island",
    dataStatus: "pending"
  },
  {
    name: "Québec",
    standardDimensions: {
      width: "2.6 metres",
      height: "4.15 metres",
      length: {
        single: "12.5 metres",
        combined: "23 metres"
      }
    },
    escortRequirements: {
      width: {
        civil: "≥ 3.7 metres",
        police: "≥ 5.3 metres"
      },
      length: {
        civil: "≥ 30 metres",
        police: "≥ 35 metres"
      },
      height: {
        civil: "≥ 4.85 metres",
        pole: "Required with civil escort"
      }
    },
    restrictions: {
      time: [
        "6h-9h and 15h30-18h30 in urban areas for vehicles ≥ 3.7m wide or ≥ 30m long",
        "Night movement requires additional lighting",
        "Weekend restrictions may apply"
      ],
      holidays: "No movement on major holidays and some weekends"
    },
    permitInfo: {
      site: "gpm.transports.gouv.qc.ca",
      cost: "Starting at $50 for basic permits",
      processingTime: "2-3 business days",
      notes: "Montreal requires additional municipal permits"
    },
    dataStatus: "complete"
  },
  {
    name: "Saskatchewan",
    dataStatus: "pending"
  },
  {
    name: "Yukon",
    dataStatus: "pending"
  }
];

export const usStates: JurisdictionInfo[] = [
  { name: "Alabama", dataStatus: "pending" },
  { name: "Alaska", dataStatus: "pending" },
  { name: "Arizona", dataStatus: "pending" },
  { name: "Arkansas", dataStatus: "pending" },
  { name: "California", dataStatus: "pending" },
  { name: "Colorado", dataStatus: "pending" },
  { name: "Connecticut", dataStatus: "pending" },
  { name: "Delaware", dataStatus: "pending" },
  { name: "Florida", dataStatus: "pending" },
  { name: "Georgia", dataStatus: "pending" },
  { name: "Hawaii", dataStatus: "pending" },
  { name: "Idaho", dataStatus: "pending" },
  { name: "Illinois", dataStatus: "pending" },
  { name: "Indiana", dataStatus: "pending" },
  { name: "Iowa", dataStatus: "pending" },
  { name: "Kansas", dataStatus: "pending" },
  { name: "Kentucky", dataStatus: "pending" },
  { name: "Louisiana", dataStatus: "pending" },
  { name: "Maine", dataStatus: "pending" },
  { name: "Maryland", dataStatus: "pending" },
  { name: "Massachusetts", dataStatus: "pending" },
  { name: "Michigan", dataStatus: "pending" },
  { name: "Minnesota", dataStatus: "pending" },
  { name: "Mississippi", dataStatus: "pending" },
  { name: "Missouri", dataStatus: "pending" },
  { name: "Montana", dataStatus: "pending" },
  { name: "Nebraska", dataStatus: "pending" },
  { name: "Nevada", dataStatus: "pending" },
  { name: "New Hampshire", dataStatus: "pending" },
  { name: "New Jersey", dataStatus: "pending" },
  { name: "New Mexico", dataStatus: "pending" },
  { name: "New York", dataStatus: "pending" },
  { name: "North Carolina", dataStatus: "pending" },
  { name: "North Dakota", dataStatus: "pending" },
  { name: "Ohio", dataStatus: "pending" },
  { name: "Oklahoma", dataStatus: "pending" },
  { name: "Oregon", dataStatus: "pending" },
  { name: "Pennsylvania", dataStatus: "pending" },
  { name: "Rhode Island", dataStatus: "pending" },
  { name: "South Carolina", dataStatus: "pending" },
  { name: "South Dakota", dataStatus: "pending" },
  { name: "Tennessee", dataStatus: "pending" },
  { name: "Texas", dataStatus: "pending" },
  { name: "Utah", dataStatus: "pending" },
  { name: "Vermont", dataStatus: "pending" },
  { name: "Virginia", dataStatus: "pending" },
  { name: "Washington", dataStatus: "pending" },
  { name: "West Virginia", dataStatus: "pending" },
  { name: "Wisconsin", dataStatus: "pending" },
  { name: "Wyoming", dataStatus: "pending" }
];