export const generalSafetyInfo = {
  title: "General Safety Guidelines",
  sections: [
    {
      title: "General Securement Requirements",
      items: [
        "Cargo must be secured to prevent shifting, tilting, or falling off the vehicle",
        "Load must not interfere with driver's visibility or control",
        "All cargo must be within legal dimensions",
        "Detailed guidelines provided by each jurisdiction's transportation authority",
        "Regular inspection of securement devices during transport",
        "Compliance with local and federal regulations"
      ]
    },
    {
      title: "Tie-Downs and Equipment",
      items: [
        "High-quality straps with specified Working Load Limit (WLL)",
        "Chains must have proper WLL ratings for heavy loads",
        "Proper tensioners and ratchet devices required",
        "Regular inspection and maintenance of securing devices",
        "Direct and indirect tie-down methods as needed",
        "Appropriate number of tie-downs based on load weight"
      ]
    },
    {
      title: "Operating Procedures",
      items: [
        "Speed restrictions compliance",
        "Safe following distance maintenance",
        "Weather-related protocols",
        "Emergency response procedures",
        "Communication protocols",
        "Regular safety checks during transport"
      ]
    }
  ]
};

export const safetyRequirements = {
  canada: {
    title: "Canadian Safety Requirements",
    provinces: [
      {
        name: "Alberta",
        lastUpdate: "2024-02-15",
        dataStatus: "complete",
        requirements: {
          preTrip: [
            "Daily vehicle inspection report required",
            "Brake adjustment verification",
            "Load securement check",
            "Route survey verification"
          ],
          equipment: [
            "Warning flags on all corners",
            "Oversize load signs front and rear",
            "Minimum 4 warning lights",
            "Height pole when required"
          ],
          documentation: [
            "Valid commercial driver's license",
            "Vehicle registration and insurance",
            "Route survey documentation",
            "Permits and authorizations"
          ]
        }
      },
      {
        name: "British Columbia",
        lastUpdate: "2024-01-20",
        dataStatus: "complete",
        requirements: {
          preTrip: [
            "Pre-trip inspection form completion",
            "Air brake system test",
            "Load measurement verification",
            "Equipment functionality check"
          ],
          equipment: [
            "D-signs when required",
            "Rotating/flashing amber lights",
            "Red flags (45x45cm)",
            "Communication equipment"
          ],
          documentation: [
            "BC commercial driver's license",
            "Oversize permit",
            "Insurance documents",
            "Route maps"
          ]
        }
      },
      { name: "Manitoba", lastUpdate: null, dataStatus: "pending" },
      { name: "New Brunswick", lastUpdate: null, dataStatus: "pending" },
      { name: "Newfoundland and Labrador", lastUpdate: null, dataStatus: "pending" },
      { name: "Northwest Territories", lastUpdate: null, dataStatus: "pending" },
      { name: "Nova Scotia", lastUpdate: null, dataStatus: "pending" },
      { name: "Nunavut", lastUpdate: null, dataStatus: "pending" },
      {
        name: "Ontario",
        lastUpdate: "2024-01-10",
        dataStatus: "complete",
        requirements: {
          preTrip: [
            "CVOR compliance check",
            "Vehicle inspection report",
            "Load securement verification",
            "Route plan confirmation"
          ],
          equipment: [
            "Oversize load signs",
            "Warning lights",
            "Flags on projections",
            "Height measuring devices"
          ],
          documentation: [
            "Ontario Class A license",
            "Annual inspection certificate",
            "Insurance documents",
            "Municipal permits"
          ]
        }
      },
      { name: "Prince Edward Island", lastUpdate: null, dataStatus: "pending" },
      {
        name: "Québec",
        lastUpdate: "2024-02-01",
        dataStatus: "complete",
        requirements: {
          preTrip: [
            "Ronde de sécurité completion",
            "Load measurement verification",
            "Route validation",
            "Equipment check"
          ],
          equipment: [
            "Oversize signs in French/English",
            "Amber warning lights",
            "Red flags",
            "Communication devices"
          ],
          documentation: [
            "Class 1 license",
            "Special permits",
            "Insurance certificates",
            "Route authorization"
          ]
        }
      },
      { name: "Saskatchewan", lastUpdate: null, dataStatus: "pending" },
      { name: "Yukon", lastUpdate: null, dataStatus: "pending" }
    ]
  },
  usa: {
    title: "United States Safety Requirements",
    states: [
      { name: "Alabama", lastUpdate: null, dataStatus: "pending" },
      { name: "Alaska", lastUpdate: null, dataStatus: "pending" },
      { name: "Arizona", lastUpdate: null, dataStatus: "pending" },
      { name: "Arkansas", lastUpdate: null, dataStatus: "pending" },
      {
        name: "California",
        lastUpdate: "2024-01-25",
        dataStatus: "complete",
        requirements: {
          preTrip: [
            "BIT inspection program compliance",
            "Load securement verification",
            "Route survey confirmation",
            "Equipment check"
          ],
          equipment: [
            "MUTCD compliant signs",
            "Class 2 safety vests",
            "Warning flags",
            "Height poles"
          ],
          documentation: [
            "California number",
            "Oversize permits",
            "Insurance documents",
            "Driver qualification file"
          ]
        }
      },
      { name: "Colorado", lastUpdate: null, dataStatus: "pending" },
      { name: "Connecticut", lastUpdate: null, dataStatus: "pending" },
      { name: "Delaware", lastUpdate: null, dataStatus: "pending" },
      { name: "Florida", lastUpdate: null, dataStatus: "pending" },
      { name: "Georgia", lastUpdate: null, dataStatus: "pending" },
      { name: "Hawaii", lastUpdate: null, dataStatus: "pending" },
      { name: "Idaho", lastUpdate: null, dataStatus: "pending" },
      { name: "Illinois", lastUpdate: null, dataStatus: "pending" },
      { name: "Indiana", lastUpdate: null, dataStatus: "pending" },
      { name: "Iowa", lastUpdate: null, dataStatus: "pending" },
      { name: "Kansas", lastUpdate: null, dataStatus: "pending" },
      { name: "Kentucky", lastUpdate: null, dataStatus: "pending" },
      { name: "Louisiana", lastUpdate: null, dataStatus: "pending" },
      { name: "Maine", lastUpdate: null, dataStatus: "pending" },
      { name: "Maryland", lastUpdate: null, dataStatus: "pending" },
      { name: "Massachusetts", lastUpdate: null, dataStatus: "pending" },
      { name: "Michigan", lastUpdate: null, dataStatus: "pending" },
      { name: "Minnesota", lastUpdate: null, dataStatus: "pending" },
      { name: "Mississippi", lastUpdate: null, dataStatus: "pending" },
      { name: "Missouri", lastUpdate: null, dataStatus: "pending" },
      { name: "Montana", lastUpdate: null, dataStatus: "pending" },
      { name: "Nebraska", lastUpdate: null, dataStatus: "pending" },
      { name: "Nevada", lastUpdate: null, dataStatus: "pending" },
      { name: "New Hampshire", lastUpdate: null, dataStatus: "pending" },
      { name: "New Jersey", lastUpdate: null, dataStatus: "pending" },
      { name: "New Mexico", lastUpdate: null, dataStatus: "pending" },
      {
        name: "New York",
        lastUpdate: "2024-01-15",
        dataStatus: "complete",
        requirements: {
          preTrip: [
            "Vehicle inspection report",
            "Load securement check",
            "Route verification",
            "Bridge clearance check"
          ],
          equipment: [
            "OVERSIZE LOAD signs",
            "Warning flags",
            "Flashing lights",
            "Height measuring devices"
          ],
          documentation: [
            "NYS CDL",
            "Special hauling permit",
            "Insurance documentation",
            "Route survey"
          ]
        }
      },
      { name: "North Carolina", lastUpdate: null, dataStatus: "pending" },
      { name: "North Dakota", lastUpdate: null, dataStatus: "pending" },
      { name: "Ohio", lastUpdate: null, dataStatus: "pending" },
      { name: "Oklahoma", lastUpdate: null, dataStatus: "pending" },
      { name: "Oregon", lastUpdate: null, dataStatus: "pending" },
      { name: "Pennsylvania", lastUpdate: null, dataStatus: "pending" },
      { name: "Rhode Island", lastUpdate: null, dataStatus: "pending" },
      { name: "South Carolina", lastUpdate: null, dataStatus: "pending" },
      { name: "South Dakota", lastUpdate: null, dataStatus: "pending" },
      {
        name: "Texas",
        lastUpdate: "2024-02-10",
        dataStatus: "complete",
        requirements: {
          preTrip: [
            "DOT inspection compliance",
            "Load measurement verification",
            "Route validation",
            "Equipment inspection"
          ],
          equipment: [
            "OVERSIZE LOAD signs",
            "Warning flags and lights",
            "Height pole indicators",
            "Communication equipment"
          ],
          documentation: [
            "Texas CDL",
            "OS/OW permits",
            "Insurance verification",
            "Route maps"
          ]
        }
      },
      { name: "Utah", lastUpdate: null, dataStatus: "pending" },
      { name: "Vermont", lastUpdate: null, dataStatus: "pending" },
      { name: "Virginia", lastUpdate: null, dataStatus: "pending" },
      { name: "Washington", lastUpdate: null, dataStatus: "pending" },
      { name: "West Virginia", lastUpdate: null, dataStatus: "pending" },
      { name: "Wisconsin", lastUpdate: null, dataStatus: "pending" },
      { name: "Wyoming", lastUpdate: null, dataStatus: "pending" }
    ]
  }
};

export const securementRequirements = {
  canada: {
    title: "Canadian Securement Requirements",
    requirements: [
      {
        title: "Basic Requirements",
        items: [
          "Cargo must be secured to prevent shifting, tilting, or falling",
          "Load must not interfere with driver's visibility or control",
          "All cargo must be within legal dimensions",
          "Detailed guidelines provided by each province's Ministry of Transportation"
        ]
      },
      {
        title: "Equipment Standards",
        items: [
          "Straps must be made of high-quality materials with specified WLL",
          "Chains must have proper Working Load Limit (WLL) ratings",
          "Proper tensioners and ratchet devices required",
          "Regular inspection and maintenance of securing devices"
        ]
      }
    ],
    tieDownRatios: [
      "Load under 5,000 lbs requires at least 2 tie-downs",
      "Load over 5,000 lbs requires 1 tie-down per 5,000 lbs",
      "Additional requirements specified in permits for oversized loads"
    ]
  },
  usa: {
    title: "United States Securement Requirements",
    requirements: [
      {
        title: "FMCSA Requirements",
        items: [
          "Compliance with CFR 49, Part 393 guidelines",
          "Proper use of tie-downs, chains, or approved devices",
          "Prevention of any cargo movement or shifting",
          "Secure fastening at all attachment points"
        ]
      },
      {
        title: "Equipment Standards",
        items: [
          "Tie-downs must meet minimum strength requirements",
          "Light loads: Straps with 5,000 lbs WLL minimum",
          "Heavy loads: Chains with up to 30,000 lbs WLL",
          "Direct and indirect tie-down methods as needed"
        ]
      }
    ],
    tieDownRatios: [
      "Loads under 10,000 lbs require at least 2 tie-downs",
      "Loads over 10,000 lbs require 1 tie-down per 10,000 lbs",
      "Minimum of 4 tie-downs for larger loads"
    ]
  }
};

export const inspectionRequirements = {
  preTrip: {
    title: "Pre-Trip Inspection Requirements",
    canada: {
      title: "Canada Requirements",
      items: [
        "Mandatory circle check within 24 hours before departure",
        "Inspection report must be completed and signed",
        "Defects must be recorded and repaired before operation",
        "Post-trip inspection required at end of driving day"
      ],
      checklist: [
        "Brakes and air system",
        "Tires and wheels",
        "Lights and reflectors",
        "Cargo securement",
        "Mirrors and windshield",
        "Emergency equipment"
      ]
    },
    usa: {
      title: "United States Requirements",
      items: [
        "FMCSA-mandated daily inspection before operation",
        "Documentation in vehicle inspection report",
        "Immediate repair of any defects found",
        "Electronic logging may be required"
      ],
      checklist: [
        "Brake system inspection",
        "Tire and wheel check",
        "Lighting and markers",
        "Securement verification",
        "Safety equipment check",
        "Documentation review"
      ]
    }
  }
};