import { ServiceProvider } from '../types/services';

export const railServiceProviders: ServiceProvider[] = [
  {
    id: 'RS1',
    name: 'RailTech Solutions',
    company: 'RailTech Solutions Inc.',
    rating: 4.9,
    reviews: 178,
    regions: ['Ontario', 'Quebec', 'New York'],
    services: ['Rail Transport', 'Load Planning', 'Documentation'],
    availability: 'Available Now',
    experience: '20+ years',
    certifications: ['CN Certified', 'CP Rail Approved'],
    description: 'Leading rail transport solutions provider.',
    specialties: ['Heavy Equipment', 'Oversized Loads', 'Cross-border'],
    contactInfo: {
      phone: '+1 (555) 123-4567',
      email: 'info@railtech.com',
      website: 'www.railtech.com'
    },
    location: {
      address: '123 Rail Street, Toronto, ON',
      coordinates: [43.6532, -79.3832]
    },
    operatingHours: {
      'Monday-Friday': '8:00 AM - 6:00 PM'
    }
  }
];

export const bargeServiceProviders: ServiceProvider[] = [
  {
    id: 'BS1',
    name: 'Maritime Transport Solutions',
    company: 'Maritime Transport Inc.',
    rating: 4.8,
    reviews: 156,
    regions: ['Great Lakes', 'St. Lawrence Seaway'],
    services: ['Barge Transport', 'Port Services', 'Load Planning'],
    availability: 'Available Next Week',
    experience: '15+ years',
    certifications: ['Marine Safety Certified', 'Port Authority Approved'],
    description: 'Specialized in water transport solutions.',
    specialties: ['Project Cargo', 'Heavy Lift', 'Port Operations'],
    contactInfo: {
      phone: '+1 (555) 234-5678',
      email: 'info@maritimetransport.com',
      website: 'www.maritimetransport.com'
    },
    location: {
      address: '456 Harbor Drive, Montreal, QC',
      coordinates: [45.5017, -73.5673]
    },
    operatingHours: {
      'Monday-Friday': '7:00 AM - 7:00 PM'
    }
  }
];

export const utilitiesServiceProviders: ServiceProvider[] = [
  {
    id: 'US1',
    name: 'PowerLine Solutions',
    company: 'PowerLine Solutions Ltd.',
    rating: 4.85,
    reviews: 142,
    regions: ['Ontario', 'Quebec'],
    services: ['Line Lifting', 'Utility Coordination', 'Permits'],
    availability: 'Available Now',
    experience: '18+ years',
    certifications: ['Utility Safety Certified', 'High Voltage Specialist'],
    description: 'Expert utility coordination services.',
    specialties: ['Power Lines', 'Communications', 'Emergency Response'],
    contactInfo: {
      phone: '+1 (555) 345-6789',
      email: 'info@powerline.com',
      website: 'www.powerline.com'
    },
    location: {
      address: '789 Power Ave, Ottawa, ON',
      coordinates: [45.4215, -75.6972]
    },
    operatingHours: {
      'Monday-Friday': '24/7'
    }
  }
];

export const technicalServiceProviders: ServiceProvider[] = [
  {
    id: 'TS1',
    name: 'Engineering Excellence',
    company: 'Technical Solutions Inc.',
    rating: 4.9,
    reviews: 189,
    regions: ['All Canada', 'Northeast US'],
    services: ['Engineering Analysis', 'Technical Drawing', 'Consulting'],
    availability: 'Available Now',
    experience: '25+ years',
    certifications: ['Professional Engineers', 'ISO 9001:2015'],
    description: 'Comprehensive technical services provider.',
    specialties: ['Structural Analysis', 'Load Planning', 'Documentation'],
    contactInfo: {
      phone: '+1 (555) 456-7890',
      email: 'info@engexcel.com',
      website: 'www.engexcel.com'
    },
    location: {
      address: '321 Tech Blvd, Vancouver, BC',
      coordinates: [49.2827, -123.1207]
    },
    operatingHours: {
      'Monday-Friday': '8:00 AM - 5:00 PM'
    }
  }
];

export const escortServiceProviders: ServiceProvider[] = [
  {
    id: 'ES1',
    name: 'Elite Escort Services',
    company: 'Elite Transport Safety Inc.',
    rating: 4.8,
    reviews: 167,
    regions: ['Ontario', 'Quebec', 'Maritime Provinces'],
    services: ['Pilot Car', 'Route Survey', 'Safety Coordination'],
    availability: 'Available Now',
    experience: '12+ years',
    certifications: ['DOT Certified', 'Safety Training Certified'],
    description: 'Professional escort and pilot car services.',
    specialties: ['Oversized Loads', 'High Pole', 'Route Planning'],
    contactInfo: {
      phone: '+1 (555) 567-8901',
      email: 'dispatch@eliteescort.com',
      website: 'www.eliteescort.com'
    },
    location: {
      address: '456 Safety Road, Toronto, ON',
      coordinates: [43.6532, -79.3832]
    },
    operatingHours: {
      'Monday-Sunday': '24/7'
    }
  }
];

export const impactRecorderProviders: ServiceProvider[] = [
  {
    id: 'IR1',
    name: 'Impact Analytics Pro',
    company: 'Impact Monitoring Solutions Inc.',
    rating: 4.9,
    reviews: 156,
    regions: ['Ontario', 'Quebec', 'Northeast US'],
    services: ['Impact Recording', 'Data Analysis', 'Equipment Rental', 'Real-time Monitoring'],
    availability: 'Available Now',
    experience: '15+ years',
    certifications: ['ISO Certified', 'Impact Analysis Expert', 'Technical Compliance'],
    description: 'Leading provider of impact recording and analysis solutions.',
    specialties: ['Sensitive Cargo', 'High-Value Equipment', 'Real-time Monitoring'],
    contactInfo: {
      phone: '+1 (555) 234-5678',
      email: 'info@impactanalytics.com',
      website: 'www.impactanalytics.com'
    },
    location: {
      address: '123 Tech Drive, Toronto, ON',
      coordinates: [43.6532, -79.3832]
    },
    operatingHours: {
      'Monday-Friday': '8:00 AM - 6:00 PM',
      'Saturday': 'By Appointment'
    }
  },
  {
    id: 'IR2',
    name: 'ShockWatch Elite',
    company: 'ShockWatch Monitoring Ltd.',
    rating: 4.8,
    reviews: 142,
    regions: ['Quebec', 'Maritime Provinces', 'New England'],
    services: ['Shock Monitoring', 'Vibration Analysis', 'Temperature Tracking'],
    availability: 'Available Next Week',
    experience: '12+ years',
    certifications: ['ShockWatch Certified', 'Quality Assurance ISO 9001'],
    description: 'Specialized in comprehensive shock and vibration monitoring.',
    specialties: ['Temperature Monitoring', 'Vibration Analysis', 'Custom Solutions'],
    contactInfo: {
      phone: '+1 (555) 345-6789',
      email: 'support@shockwatch.com',
      website: 'www.shockwatch.com'
    },
    location: {
      address: '456 Monitor Street, Montreal, QC',
      coordinates: [45.5017, -73.5673]
    },
    operatingHours: {
      'Monday-Friday': '7:00 AM - 7:00 PM'
    }
  }
];

export const lashingWeldingProviders: ServiceProvider[] = [
  {
    id: 'LW1',
    name: 'SecureFast Solutions',
    company: 'SecureFast Lashing & Welding Inc.',
    rating: 4.9,
    reviews: 189,
    regions: ['Ontario', 'Quebec', 'New York'],
    services: ['Mobile Welding', 'Load Securing', 'Custom Fabrication'],
    availability: 'Available Now',
    experience: '20+ years',
    certifications: ['AWS Certified', 'CWB Certified', 'Safety Certified'],
    description: 'Premier provider of mobile welding and cargo securing solutions.',
    specialties: ['Heavy Equipment', 'Custom Solutions', 'Emergency Repairs'],
    contactInfo: {
      phone: '+1 (555) 456-7890',
      email: 'ops@securefast.com',
      website: 'www.securefast.com'
    },
    location: {
      address: '789 Industrial Pkwy, Hamilton, ON',
      coordinates: [43.2557, -79.8711]
    },
    operatingHours: {
      'Monday-Sunday': '24/7 Emergency Service'
    }
  }
];

export const jackSlidesProviders: ServiceProvider[] = [
  {
    id: 'JS1',
    name: 'Precision Lift Solutions',
    company: 'Precision Heavy Equipment Ltd.',
    rating: 4.9,
    reviews: 134,
    regions: ['Ontario', 'Quebec', 'Northeast US'],
    services: ['Jack & Slide Systems', 'Load Movement', 'Equipment Rental'],
    availability: 'Available Now',
    experience: '25+ years',
    certifications: ['LEEA Certified', 'ISO 9001:2015', 'Safety Certified'],
    description: 'Specialized in precision heavy load movement solutions.',
    specialties: ['Heavy Machinery', 'Industrial Equipment', 'Plant Relocation'],
    contactInfo: {
      phone: '+1 (555) 678-9012',
      email: 'operations@precisionlift.com',
      website: 'www.precisionlift.com'
    },
    location: {
      address: '456 Heavy Lift Road, Mississauga, ON',
      coordinates: [43.5890, -79.6441]
    },
    operatingHours: {
      'Monday-Friday': '7:00 AM - 7:00 PM',
      'Saturday': 'By Appointment'
    }
  }
];

export const allServiceProviders = {
  rail: railServiceProviders,
  barge: bargeServiceProviders,
  utilities: utilitiesServiceProviders,
  technical: technicalServiceProviders,
  escort: escortServiceProviders,
  impactRecorder: impactRecorderProviders,
  lashingWelding: lashingWeldingProviders,
  jackSlides: jackSlidesProviders
} as const;