export const translations = {
  en: {
    navigation: {
      home: 'Home',
      features: 'Features',
      pricing: 'Pricing',
      contact: 'Contact',
      map: 'Map',
      profile: 'Profile',
      admin: 'Admin Panel',
      backend: 'Business Dashboard'
    },
    auth: {
      login: 'Sign in',
      logout: 'Sign out',
      signUp: 'Sign up',
      email: 'Email address',
      password: 'Password',
      confirmPassword: 'Confirm password',
      rememberMe: 'Remember me'
    },
    footer: {
      company: 'Company',
      about: 'About Us',
      contact: 'Contact',
      legal: 'Legal',
      privacy: 'Privacy Policy',
      terms: 'Terms of Service',
      support: 'Support',
      help: 'Help Center',
      documentation: 'Documentation',
      status: 'System Status',
      account: 'Account',
      admin: 'Administration'
    }
  },
  fr: {
    navigation: {
      home: 'Accueil',
      features: 'Fonctionnalités',
      pricing: 'Tarifs',
      contact: 'Contact',
      map: 'Carte',
      profile: 'Profil',
      admin: 'Panneau Admin',
      backend: 'Tableau de Bord'
    },
    auth: {
      login: 'Se connecter',
      logout: 'Se déconnecter',
      signUp: 'S\'inscrire',
      email: 'Adresse email',
      password: 'Mot de passe',
      confirmPassword: 'Confirmer le mot de passe',
      rememberMe: 'Se souvenir de moi'
    },
    footer: {
      company: 'Entreprise',
      about: 'À Propos',
      contact: 'Contact',
      legal: 'Légal',
      privacy: 'Confidentialité',
      terms: 'Conditions',
      support: 'Support',
      help: 'Centre d\'Aide',
      documentation: 'Documentation',
      status: 'État du Système',
      account: 'Compte',
      admin: 'Administration'
    }
  }
};