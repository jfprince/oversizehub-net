export interface ServiceProvider {
  id: string;
  name: string;
  company: string;
  rating: number;
  reviews: number;
  regions: string[];
  services: string[];
  availability: string;
  experience: string;
  certifications: string[];
  description: string;
}